--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1 (Debian 14.1-1.pgdg110+1)
-- Dumped by pg_dump version 14.2 (Ubuntu 14.2-1.pgdg20.04+1)

-- Started on 2022-03-16 21:52:38 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- TOC entry 3455 (class 1262 OID 13757)
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3456 (class 0 OID 0)
-- Dependencies: 3455
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- TOC entry 3 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 3457 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 876 (class 1247 OID 16524)
-- Name: gender; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.gender AS ENUM (
    'male',
    'female'
);


ALTER TYPE public.gender OWNER TO postgres;

--
-- TOC entry 873 (class 1247 OID 16521)
-- Name: lang; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.lang AS ENUM (
    'ita'
);


ALTER TYPE public.lang OWNER TO postgres;

--
-- TOC entry 230 (class 1255 OID 16509)
-- Name: array_contains_and_intersects(integer[], integer[], integer[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.array_contains_and_intersects(whole integer[], contained integer[], intersects_with integer[]) RETURNS boolean
    LANGUAGE sql
    AS $$
	select
	  coalesce(whole, array[]::integer[])
    @> coalesce(contained, array[]::integer[])
  and
    array_contains_or_intersects(whole, intersects_with);
$$;


ALTER FUNCTION public.array_contains_and_intersects(whole integer[], contained integer[], intersects_with integer[]) OWNER TO postgres;

--
-- TOC entry 229 (class 1255 OID 16508)
-- Name: array_contains_or_intersects(integer[], integer[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.array_contains_or_intersects(whole integer[], contained_or_intersected integer[]) RETURNS boolean
    LANGUAGE sql
    AS $$
	select
	  coalesce(whole, array[]::integer[])
	  @> coalesce(contained_or_intersected, array[]::integer[])
  or
    coalesce(whole, array[]::integer[])
    && coalesce(contained_or_intersected, array[]::integer[])
  ;
$$;


ALTER FUNCTION public.array_contains_or_intersects(whole integer[], contained_or_intersected integer[]) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 209 (class 1259 OID 16384)
-- Name: _sqlx_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._sqlx_migrations (
    version bigint NOT NULL,
    description text NOT NULL,
    installed_on timestamp with time zone DEFAULT now() NOT NULL,
    success boolean NOT NULL,
    checksum bytea NOT NULL,
    execution_time bigint NOT NULL
);


ALTER TABLE public._sqlx_migrations OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16510)
-- Name: generated_phrase; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generated_phrase (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    content text NOT NULL
);


ALTER TABLE public.generated_phrase OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 16530)
-- Name: generated_phrase_speech; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generated_phrase_speech (
    id integer NOT NULL,
    generated_phrase uuid NOT NULL,
    lang public.lang NOT NULL,
    gender public.gender NOT NULL,
    url text NOT NULL
);


ALTER TABLE public.generated_phrase_speech OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16529)
-- Name: generated_phrase_speech_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.generated_phrase_speech_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.generated_phrase_speech_id_seq OWNER TO postgres;

--
-- TOC entry 3458 (class 0 OID 0)
-- Dependencies: 227
-- Name: generated_phrase_speech_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.generated_phrase_speech_id_seq OWNED BY public.generated_phrase_speech.id;


--
-- TOC entry 217 (class 1259 OID 16430)
-- Name: grammar_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grammar_tag (
    id integer NOT NULL,
    name character varying(32) NOT NULL
);


ALTER TABLE public.grammar_tag OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16429)
-- Name: grammar_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grammar_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grammar_tag_id_seq OWNER TO postgres;

--
-- TOC entry 3459 (class 0 OID 0)
-- Dependencies: 216
-- Name: grammar_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grammar_tag_id_seq OWNED BY public.grammar_tag.id;


--
-- TOC entry 211 (class 1259 OID 16393)
-- Name: non_terminal_symbol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.non_terminal_symbol (
    id integer NOT NULL,
    name character varying(8) NOT NULL
);


ALTER TABLE public.non_terminal_symbol OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 16392)
-- Name: non_terminal_symbol_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.non_terminal_symbol_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.non_terminal_symbol_id_seq OWNER TO postgres;

--
-- TOC entry 3460 (class 0 OID 0)
-- Dependencies: 210
-- Name: non_terminal_symbol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.non_terminal_symbol_id_seq OWNED BY public.non_terminal_symbol.id;


--
-- TOC entry 213 (class 1259 OID 16402)
-- Name: production; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production (
    id integer NOT NULL,
    non_terminal_symbol integer NOT NULL,
    production character varying(1024) NOT NULL,
    nts_amount integer GENERATED ALWAYS AS ((character_length((production)::text) - character_length(replace((production)::text, '{'::text, ''::text)))) STORED NOT NULL
);


ALTER TABLE public.production OWNER TO postgres;

--
-- TOC entry 212 (class 1259 OID 16401)
-- Name: production_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.production_id_seq OWNER TO postgres;

--
-- TOC entry 3461 (class 0 OID 0)
-- Dependencies: 212
-- Name: production_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_id_seq OWNED BY public.production.id;


--
-- TOC entry 219 (class 1259 OID 16439)
-- Name: semantic_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.semantic_tag (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    sticky boolean DEFAULT true NOT NULL
);


ALTER TABLE public.semantic_tag OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16438)
-- Name: semantic_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.semantic_tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.semantic_tag_id_seq OWNER TO postgres;

--
-- TOC entry 3462 (class 0 OID 0)
-- Dependencies: 218
-- Name: semantic_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.semantic_tag_id_seq OWNED BY public.semantic_tag.id;


--
-- TOC entry 215 (class 1259 OID 16419)
-- Name: word; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.word (
    id integer NOT NULL,
    content character varying(64) NOT NULL,
    non_repeatable boolean DEFAULT true NOT NULL
);


ALTER TABLE public.word OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16469)
-- Name: word_grammar_compatibility; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.word_grammar_compatibility (
    id integer NOT NULL,
    word integer NOT NULL,
    grammar_tag integer NOT NULL
);


ALTER TABLE public.word_grammar_compatibility OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16468)
-- Name: word_grammar_compatibility_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.word_grammar_compatibility_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.word_grammar_compatibility_id_seq OWNER TO postgres;

--
-- TOC entry 3463 (class 0 OID 0)
-- Dependencies: 222
-- Name: word_grammar_compatibility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.word_grammar_compatibility_id_seq OWNED BY public.word_grammar_compatibility.id;


--
-- TOC entry 225 (class 1259 OID 16489)
-- Name: word_grammar_requirements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.word_grammar_requirements (
    id integer NOT NULL,
    word integer NOT NULL,
    grammar_tag integer NOT NULL
);


ALTER TABLE public.word_grammar_requirements OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16488)
-- Name: word_grammar_requirements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.word_grammar_requirements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.word_grammar_requirements_id_seq OWNER TO postgres;

--
-- TOC entry 3464 (class 0 OID 0)
-- Dependencies: 224
-- Name: word_grammar_requirements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.word_grammar_requirements_id_seq OWNED BY public.word_grammar_requirements.id;


--
-- TOC entry 214 (class 1259 OID 16418)
-- Name: word_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.word_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.word_id_seq OWNER TO postgres;

--
-- TOC entry 3465 (class 0 OID 0)
-- Dependencies: 214
-- Name: word_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.word_id_seq OWNED BY public.word.id;


--
-- TOC entry 221 (class 1259 OID 16449)
-- Name: word_semantic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.word_semantic (
    id integer NOT NULL,
    word integer NOT NULL,
    semantic_tag integer NOT NULL
);


ALTER TABLE public.word_semantic OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16448)
-- Name: word_semantic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.word_semantic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.word_semantic_id_seq OWNER TO postgres;

--
-- TOC entry 3466 (class 0 OID 0)
-- Dependencies: 220
-- Name: word_semantic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.word_semantic_id_seq OWNED BY public.word_semantic.id;


--
-- TOC entry 3236 (class 2604 OID 16545)
-- Name: generated_phrase_speech id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_phrase_speech ALTER COLUMN id SET DEFAULT nextval('public.generated_phrase_speech_id_seq'::regclass);


--
-- TOC entry 3229 (class 2604 OID 16546)
-- Name: grammar_tag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grammar_tag ALTER COLUMN id SET DEFAULT nextval('public.grammar_tag_id_seq'::regclass);


--
-- TOC entry 3224 (class 2604 OID 16547)
-- Name: non_terminal_symbol id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.non_terminal_symbol ALTER COLUMN id SET DEFAULT nextval('public.non_terminal_symbol_id_seq'::regclass);


--
-- TOC entry 3226 (class 2604 OID 16548)
-- Name: production id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production ALTER COLUMN id SET DEFAULT nextval('public.production_id_seq'::regclass);


--
-- TOC entry 3231 (class 2604 OID 16549)
-- Name: semantic_tag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semantic_tag ALTER COLUMN id SET DEFAULT nextval('public.semantic_tag_id_seq'::regclass);


--
-- TOC entry 3228 (class 2604 OID 16550)
-- Name: word id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word ALTER COLUMN id SET DEFAULT nextval('public.word_id_seq'::regclass);


--
-- TOC entry 3233 (class 2604 OID 16551)
-- Name: word_grammar_compatibility id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_compatibility ALTER COLUMN id SET DEFAULT nextval('public.word_grammar_compatibility_id_seq'::regclass);


--
-- TOC entry 3234 (class 2604 OID 16552)
-- Name: word_grammar_requirements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_requirements ALTER COLUMN id SET DEFAULT nextval('public.word_grammar_requirements_id_seq'::regclass);


--
-- TOC entry 3232 (class 2604 OID 16553)
-- Name: word_semantic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_semantic ALTER COLUMN id SET DEFAULT nextval('public.word_semantic_id_seq'::regclass);


--
-- TOC entry 3430 (class 0 OID 16384)
-- Dependencies: 209
-- Data for Name: _sqlx_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public._sqlx_migrations VALUES (20211225223734, 'bnf basics', '2022-03-16 20:35:39.01066+00', true, '\xa1ea686e57c3a5cd483518b49baabeffee15758cc9181c4608231edcc374fed65189c32214e71e35c25e068e36f1f29b', 168151264);
INSERT INTO public._sqlx_migrations VALUES (20220101000000, 'sequences fix', '2022-03-16 20:35:39.022166+00', true, '\xfebab0d251488866596e69adc703f23edfab59c4697e35d90a8d3b4dd0fc43d985dd3ff254b5d9a4d33c23d5de7d8547', 9199850);
INSERT INTO public._sqlx_migrations VALUES (20220202225415, 'generation result storage', '2022-03-16 20:35:39.079967+00', true, '\xfa406b0fb6f9799b5cb347ea304ac6540f15c197bf8fb72865456845d97e4feeab114c3b7a6e81fbdc1cd36fff2f81a5', 56096922);


--
-- TOC entry 3447 (class 0 OID 16510)
-- Dependencies: 226
-- Data for Name: generated_phrase; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.generated_phrase VALUES ('170cca30-bfd6-4f94-96aa-ddb9b0a1f0f3', 'mannaggia agli Angeli ebrei pestati da Maria Teresa di Calcutta zingara stuprata dal Buddha stupido arso dai Chirichetti cretini');
INSERT INTO public.generated_phrase VALUES ('6b8ded7c-0d51-4665-add8-b86e5199366f', 'Cristo larva pugnalata dalla Madonna aguzzina impalata da San Giuseppe orbo');
INSERT INTO public.generated_phrase VALUES ('46dfb726-279e-4de0-ac9a-061824e0794d', 'schiattassero gli Apostoli rugginosi');
INSERT INTO public.generated_phrase VALUES ('ddf47304-d1d5-4f01-a183-f9d0c8949684', 'accidenti a San Tommaso necrofilo');
INSERT INTO public.generated_phrase VALUES ('26bc6969-9c16-4a87-a941-5ebd4e64ff32', 'accidenti a Sant''Eustacchio terrone');
INSERT INTO public.generated_phrase VALUES ('cbdba902-2668-4afa-a388-3bac0253c336', 'accidenti a Maometto tubercoloso');
INSERT INTO public.generated_phrase VALUES ('db15d6c5-bc88-4613-80f2-c2d497a8856c', 'Nostro Signore rugginoso inculato dagli Arcangeli vespe');
INSERT INTO public.generated_phrase VALUES ('79fdcf46-823b-41d1-ba14-db27d310df3c', 'San Francesco molestato');
INSERT INTO public.generated_phrase VALUES ('bcc2832b-f2b8-4f53-a842-1b8e6bd949a7', 'mannaggia agli Arcangeli ridicoli pestati da San Giuseppe deturpato');
INSERT INTO public.generated_phrase VALUES ('6c81a37d-7342-4d48-a298-930d789e4318', 'Preti dendrofili pestati da Sant''Egidio biscia');
INSERT INTO public.generated_phrase VALUES ('04820927-a039-405d-b41c-c4cfbb4ac907', 'mannaggia alla Madonna drago trucidato dal Buddha pompinaro');
INSERT INTO public.generated_phrase VALUES ('e485c059-93a2-4d6a-b76a-c74e54a2516d', 'mannaggia a Maria sudicia');
INSERT INTO public.generated_phrase VALUES ('d0c91182-379d-4915-b8e6-a6ecfa87ccb0', 'accidenti al Papa crotalo violentato dal Buddha pipistrello accoltellato dagli Apostoli brufolosi fucilati dai Chirichetti merdosi inceneriti da Dio impallinato incenerito dagli Angeli serpi');
INSERT INTO public.generated_phrase VALUES ('52fd9291-819a-4008-9b57-2f62476d5e47', 'accidenti a San Tommaso babbuino inchiappettato dal Buddha sporco');
INSERT INTO public.generated_phrase VALUES ('29ce95b3-8ab1-48e6-84e4-76bdaf64cd66', 'mannaggia a Dio molestato');
INSERT INTO public.generated_phrase VALUES ('108ad62c-199f-4a2f-a802-dc49de221a37', 'accidenti agli Arcangeli scolopendre inchiappettate da Sant''Egidio infoiato');
INSERT INTO public.generated_phrase VALUES ('7aeb5d5c-1e75-43c5-926a-65fa5d1c3f27', 'morisse San Tommaso infame inchiappettato da Maria scrofa inchiodata da Sant''Egidio bocchinaro inculato da Gesù spacciatore');
INSERT INTO public.generated_phrase VALUES ('c563717d-92fa-443d-a877-56708690e9a1', 'Sant''Antonio putrefatto');
INSERT INTO public.generated_phrase VALUES ('6b9fd8cc-3b92-45de-9511-4d22f7a8adc0', 'morisse Cristo larva');
INSERT INTO public.generated_phrase VALUES ('66da924c-0b02-4b9f-be90-7c242751ad45', 'mannaggia ai Chirichetti allupati mazzuolati da San Tommaso squartato accoltellato da San Francesco gargoyle mazzuolato da Santa Caterina maiale');
INSERT INTO public.generated_phrase VALUES ('7be4598a-e8cc-4cef-b3b3-125201221484', 'Suore stuprate arse da Sant''Ermete pustoloso');
INSERT INTO public.generated_phrase VALUES ('41bcda1a-bc86-4866-87ba-501f12f93ea4', 'morisse Sant''Ermete pipistrello sbranato da Gesù inchiappettato impallinato da Dio piattola impalata dal Papa stuprato incenerito dai Chirichetti impalati');
INSERT INTO public.generated_phrase VALUES ('a807547e-0d35-4ff7-a9f9-ddf460637022', 'Sant''Eustacchio crotalo');
INSERT INTO public.generated_phrase VALUES ('d5e1c501-a823-4d85-94a7-03f97b13e1a2', 'accidenti alle Suore arrugginite');
INSERT INTO public.generated_phrase VALUES ('9f7d59f6-3198-4ad3-b88c-7fb4f3a0659b', 'accidenti a Cristo incenerito impalato da San Pietro tubercoloso');
INSERT INTO public.generated_phrase VALUES ('4c3224b6-9dd0-447b-8437-5b8319ba814e', 'crepasse Dio pedofilo arso dai Preti serpi');
INSERT INTO public.generated_phrase VALUES ('53fb875f-abc0-4171-89d7-40a57d401fc7', 'accidenti a Maria Teresa di Calcutta violentata inculata da Sant''Eustacchio tacchino');
INSERT INTO public.generated_phrase VALUES ('171febf7-b2a6-4039-a0c7-cef06151782f', 'Sant''Ermete gerontofilo violentato da Dio avvoltoio impallinato dagli Apostoli viscidi');
INSERT INTO public.generated_phrase VALUES ('a06158c0-9e9b-47ca-a708-78c7f84250f6', 'Dio vespa fucilata da San Giuseppe coprofilo');
INSERT INTO public.generated_phrase VALUES ('171b270f-9c06-4825-b9cd-885f704437bb', 'morisse Sant''Egidio spacciatore impallinato da Sant''Antonio incenerito');
INSERT INTO public.generated_phrase VALUES ('e47a2a69-4532-4656-9a86-30994df73f33', 'crepassero gli Arcangeli tarme pestate da San Tommaso squartato');
INSERT INTO public.generated_phrase VALUES ('2d49167c-fb43-4f2c-bff5-214c53a101f6', 'schiattasse la Madonna malvagia');
INSERT INTO public.generated_phrase VALUES ('5031e0ed-9154-4a32-932f-8d1fff583604', 'San Tommaso brutto');
INSERT INTO public.generated_phrase VALUES ('0fc87804-7793-418f-b029-61abeb0963f6', 'Preti ritardati');
INSERT INTO public.generated_phrase VALUES ('2b2e87c9-9162-4547-bb44-96b1073a555c', 'schiattassero gli Arcangeli ladri inchiappettati dalla Madonna malvagia incenerita da Cristo scolopendra');
INSERT INTO public.generated_phrase VALUES ('c80def21-5c73-4efd-b7e2-10bf0bab2cab', 'Nostro Signore arso inchiappettato da San Pietro balena');
INSERT INTO public.generated_phrase VALUES ('b34e0679-898f-4116-b54a-ca5fde9b76b3', 'San Giuseppe cane');
INSERT INTO public.generated_phrase VALUES ('0b9906d4-9679-4748-8631-0e34f0e90cb5', 'crepasse il Buddha macchiato impallinato dagli Arcangeli cobra sbranati da Maria Teresa di Calcutta perfida');
INSERT INTO public.generated_phrase VALUES ('658a90ff-50ad-478c-a44d-75aa4b701486', 'mannaggia a Sant''Ermete disgustoso inchiappettato dai Preti piattole');
INSERT INTO public.generated_phrase VALUES ('597dbad8-412f-4c42-9b65-7a8035c82124', 'accidenti a Maometto pollo');
INSERT INTO public.generated_phrase VALUES ('9f04b21d-90ad-4999-b9a4-a3f855670cd1', 'accidenti agli Arcangeli cannati');
INSERT INTO public.generated_phrase VALUES ('0bbd7441-3bb4-4115-8f7f-f4efb5a4cc9c', 'crepasse Sant''Eustacchio incenerito');
INSERT INTO public.generated_phrase VALUES ('c6cadae2-fa16-4e60-af43-4052af5335d3', 'schiattasse la Madonna orco fucilato dagli Apostoli bocchinari arsi dai Chirichetti zoofili');
INSERT INTO public.generated_phrase VALUES ('9d0a04bc-9ad1-439e-ac8c-9f8997f1700d', 'Apostoli assassini sbranati dalla Madonna upupa molestata da Gesù muflone squartato da Sant''Ermete brufoloso inchiappettato da Dio cimice violentata da San Francesco babbuino');


--
-- TOC entry 3449 (class 0 OID 16530)
-- Dependencies: 228
-- Data for Name: generated_phrase_speech; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.generated_phrase_speech VALUES (259, '170cca30-bfd6-4f94-96aa-ddb9b0a1f0f3', 'ita', 'male', 'http://localhost/speak/D548454B3C12DD564FC27B04B342D27C9D9977F7A27BA5C6E2D2CE19F2CFA79F');
INSERT INTO public.generated_phrase_speech VALUES (260, '6b8ded7c-0d51-4665-add8-b86e5199366f', 'ita', 'male', 'http://localhost/speak/2A09827BAE364BBA899E897D1288102C68DBCE88F6E5CDFED3575645B44D52AD');
INSERT INTO public.generated_phrase_speech VALUES (261, '46dfb726-279e-4de0-ac9a-061824e0794d', 'ita', 'male', 'http://localhost/speak/811E2CBD63BEDAEA737408F3AC1A1BC6AC05889DD5720465932D4BD17D5E7E69');
INSERT INTO public.generated_phrase_speech VALUES (262, 'ddf47304-d1d5-4f01-a183-f9d0c8949684', 'ita', 'male', 'http://localhost/speak/255326F5AF8D06C15B7EFDA24DB3A75A642C0DD53C93E7A7D88B15704675930B');
INSERT INTO public.generated_phrase_speech VALUES (263, '26bc6969-9c16-4a87-a941-5ebd4e64ff32', 'ita', 'male', 'http://localhost/speak/EF153EBF6C1D2E30974211C5585BB637619D9E5BAF0977C6382A0843896AB54B');
INSERT INTO public.generated_phrase_speech VALUES (264, 'cbdba902-2668-4afa-a388-3bac0253c336', 'ita', 'male', 'http://localhost/speak/93A56CCD8003EE08FF121708366B2760EF3F2EA527E1463E24A566C3B4840EAD');
INSERT INTO public.generated_phrase_speech VALUES (265, 'db15d6c5-bc88-4613-80f2-c2d497a8856c', 'ita', 'male', 'http://localhost/speak/73E39647082BA529178134D4C38E9DECE4B47C7A304F287CED0E90C7CDA8A3FF');
INSERT INTO public.generated_phrase_speech VALUES (266, '79fdcf46-823b-41d1-ba14-db27d310df3c', 'ita', 'male', 'http://localhost/speak/4082E8E1F6FD2EE01DB1EE1D457EBD9BADB0D850FA6A4B2DBC8E4BBE1716E9E9');
INSERT INTO public.generated_phrase_speech VALUES (267, 'bcc2832b-f2b8-4f53-a842-1b8e6bd949a7', 'ita', 'male', 'http://localhost/speak/7476B692E006D9CFD82824ED9E301473A09E7E8413837421B786BAB6D8583A27');
INSERT INTO public.generated_phrase_speech VALUES (268, '6c81a37d-7342-4d48-a298-930d789e4318', 'ita', 'male', 'http://localhost/speak/A47CD6A72EE6338A4CC345640574A7F08755FE8BB285F7CAC8EAE98A2F4DCFB7');
INSERT INTO public.generated_phrase_speech VALUES (269, '04820927-a039-405d-b41c-c4cfbb4ac907', 'ita', 'male', 'http://localhost/speak/998D0989A340CD546895CEC7198C69C11D749F5FD6E2ABA8749DF2D5808F7530');
INSERT INTO public.generated_phrase_speech VALUES (270, 'e485c059-93a2-4d6a-b76a-c74e54a2516d', 'ita', 'male', 'http://localhost/speak/B5C8E866810A64821AF8837FD69049E0CB2192AAFC94344BA72398C1A924B03D');
INSERT INTO public.generated_phrase_speech VALUES (271, 'd0c91182-379d-4915-b8e6-a6ecfa87ccb0', 'ita', 'male', 'http://localhost/speak/C6D4AFCFF72E521D1E9C34F046E25957375919C816BCB772008CE9C04877A6A1');
INSERT INTO public.generated_phrase_speech VALUES (272, '52fd9291-819a-4008-9b57-2f62476d5e47', 'ita', 'male', 'http://localhost/speak/7A9DCCAC586FCBFE72BB49F7000DDB7D3D6D2EF9E709B58A4C57DBDD24E07541');
INSERT INTO public.generated_phrase_speech VALUES (273, '29ce95b3-8ab1-48e6-84e4-76bdaf64cd66', 'ita', 'male', 'http://localhost/speak/7AF0C3F18C99B188DB16FD42D48A47C045D2905A868763E30A780EF3444CA838');
INSERT INTO public.generated_phrase_speech VALUES (274, '108ad62c-199f-4a2f-a802-dc49de221a37', 'ita', 'male', 'http://localhost/speak/CA5880D78384437A604DCE9FF37177380EF35084EA404529EC1A12CE29FBE1F1');
INSERT INTO public.generated_phrase_speech VALUES (275, '7aeb5d5c-1e75-43c5-926a-65fa5d1c3f27', 'ita', 'male', 'http://localhost/speak/3FE9F96A6EC882B137035C2D712F7C14ACBB6EA13FF3514F7E573FC0B60CD105');
INSERT INTO public.generated_phrase_speech VALUES (276, 'c563717d-92fa-443d-a877-56708690e9a1', 'ita', 'male', 'http://localhost/speak/6C576954D96C7E72835F0043C9406588577E8884E93ECBAE5C5AAB35E6B08AE3');
INSERT INTO public.generated_phrase_speech VALUES (277, '6b9fd8cc-3b92-45de-9511-4d22f7a8adc0', 'ita', 'male', 'http://localhost/speak/7C507B1A302472B4C4EFFE54D79F9CB75A32719CF99EAB2E90EF31E4306FF3A1');
INSERT INTO public.generated_phrase_speech VALUES (278, '66da924c-0b02-4b9f-be90-7c242751ad45', 'ita', 'male', 'http://localhost/speak/EA6D2FFA1D414A636F03496CFF3394304235F3DD5BD09304039BE7881F0701B2');
INSERT INTO public.generated_phrase_speech VALUES (279, '7be4598a-e8cc-4cef-b3b3-125201221484', 'ita', 'male', 'http://localhost/speak/AC32FA2DC2C78F4E7326B94E2078D4E46F0178AC4E5B8A50E585FC53E3E99FA3');
INSERT INTO public.generated_phrase_speech VALUES (280, '41bcda1a-bc86-4866-87ba-501f12f93ea4', 'ita', 'male', 'http://localhost/speak/6EFFD54C7B447BCA05AA5D225CAD468CC8BD7023185D815CE71E2D8297B3FC8B');
INSERT INTO public.generated_phrase_speech VALUES (281, 'a807547e-0d35-4ff7-a9f9-ddf460637022', 'ita', 'male', 'http://localhost/speak/C2F3E08EDA37FBF44C540B7B252DFE59833EF17396B416A71F48D65884EFED1D');
INSERT INTO public.generated_phrase_speech VALUES (282, 'd5e1c501-a823-4d85-94a7-03f97b13e1a2', 'ita', 'male', 'http://localhost/speak/9794DD4AFE3E6E49A6830E56390C25B1D3D9473A2C08A4F2F21F40685DB74143');
INSERT INTO public.generated_phrase_speech VALUES (283, '9f7d59f6-3198-4ad3-b88c-7fb4f3a0659b', 'ita', 'male', 'http://localhost/speak/0CC266066AFDFC0A9C364A3AF8FCAB10B86AF0A2AB5E6490ACFDD1C7D06DD4C8');
INSERT INTO public.generated_phrase_speech VALUES (284, '4c3224b6-9dd0-447b-8437-5b8319ba814e', 'ita', 'male', 'http://localhost/speak/CB2AF7F52437F9DC98EF1EF90995B915A4FC7C79992C5B02AA80FE7F23D8FAD4');
INSERT INTO public.generated_phrase_speech VALUES (285, '53fb875f-abc0-4171-89d7-40a57d401fc7', 'ita', 'male', 'http://localhost/speak/16377B1F0AC929D645CE21F4931159C3597B7A90ED51C0E6F30D96215D185F98');
INSERT INTO public.generated_phrase_speech VALUES (286, '171febf7-b2a6-4039-a0c7-cef06151782f', 'ita', 'male', 'http://localhost/speak/A126713D8E3C06359839E12F60677FAC4FB50CB5E1F75D2BA0FA98C6FB71C9CF');
INSERT INTO public.generated_phrase_speech VALUES (287, 'a06158c0-9e9b-47ca-a708-78c7f84250f6', 'ita', 'female', 'http://localhost/speak/2860C98D6ED0417373C37CB7947DEAE86C119BD2E76A38CAAB745EF1BEFF439E');
INSERT INTO public.generated_phrase_speech VALUES (288, '171b270f-9c06-4825-b9cd-885f704437bb', 'ita', 'female', 'http://localhost/speak/376082CAA93404D9A33090092DB8FC2452E33F88EC016E5CC52617786815B9D7');
INSERT INTO public.generated_phrase_speech VALUES (289, 'e47a2a69-4532-4656-9a86-30994df73f33', 'ita', 'female', 'http://localhost/speak/B6EBC7C0EC5FCCE43D6B633EF2DBE607222F5C6504E0320B9481804108616FEB');
INSERT INTO public.generated_phrase_speech VALUES (290, '2d49167c-fb43-4f2c-bff5-214c53a101f6', 'ita', 'female', 'http://localhost/speak/F34F27715B73139AE542662BDF001D9581E18E2C03E1BD2F612BFD11CCB17B9E');
INSERT INTO public.generated_phrase_speech VALUES (291, '5031e0ed-9154-4a32-932f-8d1fff583604', 'ita', 'female', 'http://localhost/speak/9AB046C10063063C819187664C5743F98C63DF16BFC3AFB2BE64DF30D1A5BB6E');
INSERT INTO public.generated_phrase_speech VALUES (292, '0fc87804-7793-418f-b029-61abeb0963f6', 'ita', 'female', 'http://localhost/speak/4590DAADD01E60319708C97B9BE48BD0F006923EAFEEEEF915D47F08B8F3014C');
INSERT INTO public.generated_phrase_speech VALUES (293, '2b2e87c9-9162-4547-bb44-96b1073a555c', 'ita', 'female', 'http://localhost/speak/78C04E0C94AAD7CE274637628152E0CF3365FE6E9FD29CA962A3D60993AB5396');
INSERT INTO public.generated_phrase_speech VALUES (294, 'c80def21-5c73-4efd-b7e2-10bf0bab2cab', 'ita', 'female', 'http://localhost/speak/304C617781842CFC9127E7CBD7407B5D07F2D396D7A720F8BA85FE2ED8B485B9');
INSERT INTO public.generated_phrase_speech VALUES (295, 'b34e0679-898f-4116-b54a-ca5fde9b76b3', 'ita', 'female', 'http://localhost/speak/05818C38CC8F2794DC246F28B3EFF137ECDD28FA6FD4A79B3D1F91DF0BBF6276');
INSERT INTO public.generated_phrase_speech VALUES (296, '0b9906d4-9679-4748-8631-0e34f0e90cb5', 'ita', 'female', 'http://localhost/speak/52E2F8327ED25DE4A8C9BA4B54E8131A13DF11AC69A846E49F3640443F5866C6');
INSERT INTO public.generated_phrase_speech VALUES (297, '658a90ff-50ad-478c-a44d-75aa4b701486', 'ita', 'female', 'http://localhost/speak/BDC0BB646DC7B6A1A243F43E08E2AE6880C27E8941788D21312C0E3386AF8046');
INSERT INTO public.generated_phrase_speech VALUES (298, '597dbad8-412f-4c42-9b65-7a8035c82124', 'ita', 'female', 'http://localhost/speak/94AB324DDDAF4010CD0F0629909DC5B5DEFF5EB80E3994ABF6AEB5221DCCB32B');
INSERT INTO public.generated_phrase_speech VALUES (299, '9f04b21d-90ad-4999-b9a4-a3f855670cd1', 'ita', 'female', 'http://localhost/speak/751AA4E5274B638E99F187D65171043B44CE21271B8378ACB348C8A66509175C');
INSERT INTO public.generated_phrase_speech VALUES (300, '0bbd7441-3bb4-4115-8f7f-f4efb5a4cc9c', 'ita', 'female', 'http://localhost/speak/EDC2F895A3157860CD5AC663CB83DF32DC416A9AE41A8C83B549584FCFC8D6DD');
INSERT INTO public.generated_phrase_speech VALUES (301, 'c6cadae2-fa16-4e60-af43-4052af5335d3', 'ita', 'female', 'http://localhost/speak/2F2D7C5F1163F47A6A6244770E82140356F746F076B1A1E680295224CE6D60FA');
INSERT INTO public.generated_phrase_speech VALUES (302, '9d0a04bc-9ad1-439e-ac8c-9f8997f1700d', 'ita', 'female', 'http://localhost/speak/A0592CAC8742E4654A6EB1420BD3856CE5D1976EB59F9B8EF4C5FFF603CA1CD3');


--
-- TOC entry 3438 (class 0 OID 16430)
-- Dependencies: 217
-- Data for Name: grammar_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.grammar_tag VALUES (1, 'ms1');
INSERT INTO public.grammar_tag VALUES (2, 'ms2');
INSERT INTO public.grammar_tag VALUES (3, 'ms3');
INSERT INTO public.grammar_tag VALUES (4, 'ms0');
INSERT INTO public.grammar_tag VALUES (5, 'fs1');
INSERT INTO public.grammar_tag VALUES (6, 'fs2');
INSERT INTO public.grammar_tag VALUES (7, 'fs0');
INSERT INTO public.grammar_tag VALUES (8, 'mp1');
INSERT INTO public.grammar_tag VALUES (9, 'mp2');
INSERT INTO public.grammar_tag VALUES (10, 'fp1');
INSERT INTO public.grammar_tag VALUES (11, 'fp2');
INSERT INTO public.grammar_tag VALUES (12, 'mp0');
INSERT INTO public.grammar_tag VALUES (13, 'fp0');
INSERT INTO public.grammar_tag VALUES (14, '_');


--
-- TOC entry 3432 (class 0 OID 16393)
-- Dependencies: 211
-- Data for Name: non_terminal_symbol; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.non_terminal_symbol VALUES (1, 'Start');
INSERT INTO public.non_terminal_symbol VALUES (2, 'Atom');


--
-- TOC entry 3434 (class 0 OID 16402)
-- Dependencies: 213
-- Data for Name: production; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.production VALUES (1, 1, '{0:N:F:N:F:Atom}', DEFAULT);
INSERT INTO public.production VALUES (2, 1, '<2:N:F:N:F:accidente_a> <1:O(0):F:N:F:a> {0:N:T:N:F:Atom}', DEFAULT);
INSERT INTO public.production VALUES (3, 1, '<2:O(0):F:N:F:accidente_il> <1:O(0):F:N:F:determinativo> {0:N:T:N:F:Atom}', DEFAULT);
INSERT INTO public.production VALUES (4, 2, '<0:N:T:N:F:santo> <1:O(0):F:N:F:malaparola>', DEFAULT);
INSERT INTO public.production VALUES (5, 2, '<0:N:T:N:F:santo> <1:O(0):F:N:F:malaparola> <2:O(1):F:N:F:participio> <3:O(4):F:N:F:da> {4:N:T:N:F:Atom}', DEFAULT);


--
-- TOC entry 3440 (class 0 OID 16439)
-- Dependencies: 219
-- Data for Name: semantic_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.semantic_tag VALUES (1, 'santo', false);
INSERT INTO public.semantic_tag VALUES (2, 'nome', false);
INSERT INTO public.semantic_tag VALUES (3, 'singolo', false);
INSERT INTO public.semantic_tag VALUES (4, 'soggetto', false);
INSERT INTO public.semantic_tag VALUES (5, 'persona', true);
INSERT INTO public.semantic_tag VALUES (6, 'gruppo', false);
INSERT INTO public.semantic_tag VALUES (7, 'sostantivo', false);
INSERT INTO public.semantic_tag VALUES (8, 'malaparola', false);
INSERT INTO public.semantic_tag VALUES (9, 'animale', true);
INSERT INTO public.semantic_tag VALUES (10, 'pelliccia', true);
INSERT INTO public.semantic_tag VALUES (11, 'pelle', true);
INSERT INTO public.semantic_tag VALUES (12, 'mammifero', true);
INSERT INTO public.semantic_tag VALUES (13, 'zampe', true);
INSERT INTO public.semantic_tag VALUES (14, 'medio', true);
INSERT INTO public.semantic_tag VALUES (15, 'vertebrato', true);
INSERT INTO public.semantic_tag VALUES (16, 'porno', true);
INSERT INTO public.semantic_tag VALUES (17, 'grosso', true);
INSERT INTO public.semantic_tag VALUES (18, 'corna', true);
INSERT INTO public.semantic_tag VALUES (19, 'zanne', true);
INSERT INTO public.semantic_tag VALUES (20, 'piccolo', true);
INSERT INTO public.semantic_tag VALUES (21, 'nuota', true);
INSERT INTO public.semantic_tag VALUES (22, 'pinne', true);
INSERT INTO public.semantic_tag VALUES (23, 'rettile', true);
INSERT INTO public.semantic_tag VALUES (24, 'striscia', true);
INSERT INTO public.semantic_tag VALUES (25, 'piume', true);
INSERT INTO public.semantic_tag VALUES (26, 'volatile', true);
INSERT INTO public.semantic_tag VALUES (27, 'vola', true);
INSERT INTO public.semantic_tag VALUES (28, 'insetto', true);
INSERT INTO public.semantic_tag VALUES (29, 'invertebrato', true);
INSERT INTO public.semantic_tag VALUES (30, 'bestia', true);
INSERT INTO public.semantic_tag VALUES (31, 'succhia', true);
INSERT INTO public.semantic_tag VALUES (32, 'illegale', true);
INSERT INTO public.semantic_tag VALUES (33, 'brutto', true);
INSERT INTO public.semantic_tag VALUES (34, 'malattia', true);
INSERT INTO public.semantic_tag VALUES (35, 'sporco', true);
INSERT INTO public.semantic_tag VALUES (36, 'aggettivo', false);
INSERT INTO public.semantic_tag VALUES (37, 'maledizione', true);
INSERT INTO public.semantic_tag VALUES (38, 'handicap', true);
INSERT INTO public.semantic_tag VALUES (39, 'coperto_di', true);
INSERT INTO public.semantic_tag VALUES (40, 'unto_di', true);
INSERT INTO public.semantic_tag VALUES (41, 'occhi', true);
INSERT INTO public.semantic_tag VALUES (42, 'schifo', true);
INSERT INTO public.semantic_tag VALUES (43, 'sguscia', true);
INSERT INTO public.semantic_tag VALUES (44, 'deturpato', true);
INSERT INTO public.semantic_tag VALUES (45, 'polmoni', true);
INSERT INTO public.semantic_tag VALUES (46, 'carne', true);
INSERT INTO public.semantic_tag VALUES (47, 'umido', true);
INSERT INTO public.semantic_tag VALUES (48, 'oggetto', true);
INSERT INTO public.semantic_tag VALUES (49, 'metallo', true);
INSERT INTO public.semantic_tag VALUES (50, 'participio', false);
INSERT INTO public.semantic_tag VALUES (51, 'accidente_a', false);
INSERT INTO public.semantic_tag VALUES (52, '_', true);
INSERT INTO public.semantic_tag VALUES (53, 'accidente_il', false);
INSERT INTO public.semantic_tag VALUES (54, 'articolo', false);
INSERT INTO public.semantic_tag VALUES (55, 'determinativo', false);
INSERT INTO public.semantic_tag VALUES (56, 'indeterminativo', false);
INSERT INTO public.semantic_tag VALUES (57, 'quel', false);
INSERT INTO public.semantic_tag VALUES (58, 'questo', false);
INSERT INTO public.semantic_tag VALUES (59, 'di', false);
INSERT INTO public.semantic_tag VALUES (60, 'a', false);
INSERT INTO public.semantic_tag VALUES (61, 'da', false);
INSERT INTO public.semantic_tag VALUES (62, 'in', false);
INSERT INTO public.semantic_tag VALUES (63, 'su', false);
INSERT INTO public.semantic_tag VALUES (64, 'con', false);
INSERT INTO public.semantic_tag VALUES (65, 'per', false);
INSERT INTO public.semantic_tag VALUES (66, 'tra', false);
INSERT INTO public.semantic_tag VALUES (67, 'fra', false);
INSERT INTO public.semantic_tag VALUES (68, 'come', false);
INSERT INTO public.semantic_tag VALUES (69, 'tutto', false);


--
-- TOC entry 3436 (class 0 OID 16419)
-- Dependencies: 215
-- Data for Name: word; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.word VALUES (1, 'Dio', true);
INSERT INTO public.word VALUES (2, 'Gesù', true);
INSERT INTO public.word VALUES (3, 'Madonna', true);
INSERT INTO public.word VALUES (4, 'Cristo', true);
INSERT INTO public.word VALUES (5, 'Papa', true);
INSERT INTO public.word VALUES (6, 'Angeli', true);
INSERT INTO public.word VALUES (7, 'Apostoli', true);
INSERT INTO public.word VALUES (8, 'Arcangeli', true);
INSERT INTO public.word VALUES (9, 'San Giuseppe', true);
INSERT INTO public.word VALUES (10, 'Maria', true);
INSERT INTO public.word VALUES (11, 'San Pietro', true);
INSERT INTO public.word VALUES (12, 'Sant''Antonio', true);
INSERT INTO public.word VALUES (13, 'Buddha', true);
INSERT INTO public.word VALUES (14, 'Maometto', true);
INSERT INTO public.word VALUES (15, 'Preti', true);
INSERT INTO public.word VALUES (16, 'Chirichetti', true);
INSERT INTO public.word VALUES (17, 'Suore', true);
INSERT INTO public.word VALUES (18, 'Nostro Signore', true);
INSERT INTO public.word VALUES (19, 'Sant''Egidio', true);
INSERT INTO public.word VALUES (20, 'Sant''Eustacchio', true);
INSERT INTO public.word VALUES (21, 'Sant''Ermete', true);
INSERT INTO public.word VALUES (22, 'San Tommaso', true);
INSERT INTO public.word VALUES (23, 'San Francesco', true);
INSERT INTO public.word VALUES (24, 'Santa Caterina', true);
INSERT INTO public.word VALUES (25, 'Maria Teresa di Calcutta', true);
INSERT INTO public.word VALUES (26, 'cane', true);
INSERT INTO public.word VALUES (27, 'cagna', true);
INSERT INTO public.word VALUES (28, 'cani', true);
INSERT INTO public.word VALUES (29, 'cagne', true);
INSERT INTO public.word VALUES (30, 'maiale', true);
INSERT INTO public.word VALUES (31, 'maiali', true);
INSERT INTO public.word VALUES (32, 'babbuino', true);
INSERT INTO public.word VALUES (33, 'babbuini', true);
INSERT INTO public.word VALUES (34, 'scrofa', true);
INSERT INTO public.word VALUES (35, 'scrofe', true);
INSERT INTO public.word VALUES (36, 'vacca', true);
INSERT INTO public.word VALUES (37, 'vacche', true);
INSERT INTO public.word VALUES (38, 'orso', true);
INSERT INTO public.word VALUES (39, 'orsa', true);
INSERT INTO public.word VALUES (40, 'orsi', true);
INSERT INTO public.word VALUES (41, 'orse', true);
INSERT INTO public.word VALUES (42, 'toro', true);
INSERT INTO public.word VALUES (43, 'tori', true);
INSERT INTO public.word VALUES (44, 'bue', true);
INSERT INTO public.word VALUES (45, 'buoi', true);
INSERT INTO public.word VALUES (46, 'bufalo', true);
INSERT INTO public.word VALUES (47, 'bufali', true);
INSERT INTO public.word VALUES (48, 'muflone', true);
INSERT INTO public.word VALUES (49, 'mufloni', true);
INSERT INTO public.word VALUES (50, 'cinghiale', true);
INSERT INTO public.word VALUES (51, 'cinghiali', true);
INSERT INTO public.word VALUES (52, 'ratto', true);
INSERT INTO public.word VALUES (53, 'ratti', true);
INSERT INTO public.word VALUES (54, 'topo', true);
INSERT INTO public.word VALUES (55, 'topi', true);
INSERT INTO public.word VALUES (56, 'criceto', true);
INSERT INTO public.word VALUES (57, 'criceti', true);
INSERT INTO public.word VALUES (58, 'pipistrello', true);
INSERT INTO public.word VALUES (59, 'pipistrelli', true);
INSERT INTO public.word VALUES (60, 'scimmia', true);
INSERT INTO public.word VALUES (61, 'scimmie', true);
INSERT INTO public.word VALUES (62, 'megattera', true);
INSERT INTO public.word VALUES (63, 'megattere', true);
INSERT INTO public.word VALUES (64, 'balena', true);
INSERT INTO public.word VALUES (65, 'balene', true);
INSERT INTO public.word VALUES (66, 'vipera', true);
INSERT INTO public.word VALUES (67, 'vipere', true);
INSERT INTO public.word VALUES (68, 'upupa', true);
INSERT INTO public.word VALUES (69, 'upupe', true);
INSERT INTO public.word VALUES (70, 'avvoltoio', true);
INSERT INTO public.word VALUES (71, 'avvoltoi', true);
INSERT INTO public.word VALUES (72, 'condor', true);
INSERT INTO public.word VALUES (73, 'condor-', true);
INSERT INTO public.word VALUES (74, 'tacchino', true);
INSERT INTO public.word VALUES (75, 'tacchini', true);
INSERT INTO public.word VALUES (76, 'pollo', true);
INSERT INTO public.word VALUES (77, 'polli', true);
INSERT INTO public.word VALUES (78, 'pinguino', true);
INSERT INTO public.word VALUES (79, 'pinguini', true);
INSERT INTO public.word VALUES (80, 'serpe', true);
INSERT INTO public.word VALUES (81, 'serpi', true);
INSERT INTO public.word VALUES (82, 'biscia', true);
INSERT INTO public.word VALUES (83, 'bisce', true);
INSERT INTO public.word VALUES (84, 'cobra', true);
INSERT INTO public.word VALUES (85, 'cobra-', true);
INSERT INTO public.word VALUES (86, 'crotalo', true);
INSERT INTO public.word VALUES (87, 'crotali', true);
INSERT INTO public.word VALUES (88, 'biacco', true);
INSERT INTO public.word VALUES (89, 'biacchi', true);
INSERT INTO public.word VALUES (90, 'boa', true);
INSERT INTO public.word VALUES (91, 'boa-', true);
INSERT INTO public.word VALUES (92, 'verme', true);
INSERT INTO public.word VALUES (93, 'vermi', true);
INSERT INTO public.word VALUES (94, 'bruco', true);
INSERT INTO public.word VALUES (95, 'bruchi', true);
INSERT INTO public.word VALUES (96, 'scarafaggio', true);
INSERT INTO public.word VALUES (97, 'scarafaggi', true);
INSERT INTO public.word VALUES (98, 'ragno', true);
INSERT INTO public.word VALUES (99, 'ragni', true);
INSERT INTO public.word VALUES (100, 'mostro', true);
INSERT INTO public.word VALUES (101, 'mostri', true);
INSERT INTO public.word VALUES (102, 'gargoyle', true);
INSERT INTO public.word VALUES (103, 'gargoyle-', true);
INSERT INTO public.word VALUES (104, 'drago', true);
INSERT INTO public.word VALUES (105, 'draghi', true);
INSERT INTO public.word VALUES (106, 'bestia', true);
INSERT INTO public.word VALUES (107, 'bestie', true);
INSERT INTO public.word VALUES (108, 'orco', true);
INSERT INTO public.word VALUES (109, 'orchi', true);
INSERT INTO public.word VALUES (110, 'tafano', true);
INSERT INTO public.word VALUES (111, 'tafani', true);
INSERT INTO public.word VALUES (112, 'tarlo', true);
INSERT INTO public.word VALUES (113, 'tarli', true);
INSERT INTO public.word VALUES (114, 'vespa', true);
INSERT INTO public.word VALUES (115, 'vespe', true);
INSERT INTO public.word VALUES (116, 'locusta', true);
INSERT INTO public.word VALUES (117, 'locuste', true);
INSERT INTO public.word VALUES (118, 'malmignatta', true);
INSERT INTO public.word VALUES (119, 'malmignatte', true);
INSERT INTO public.word VALUES (120, 'pulce', true);
INSERT INTO public.word VALUES (121, 'pulci', true);
INSERT INTO public.word VALUES (122, 'tarantola', true);
INSERT INTO public.word VALUES (123, 'tarantole', true);
INSERT INTO public.word VALUES (124, 'larva', true);
INSERT INTO public.word VALUES (125, 'larve', true);
INSERT INTO public.word VALUES (126, 'piattola', true);
INSERT INTO public.word VALUES (127, 'piattole', true);
INSERT INTO public.word VALUES (128, 'sanguisuga', true);
INSERT INTO public.word VALUES (129, 'sanguisughe', true);
INSERT INTO public.word VALUES (130, 'scolopendra', true);
INSERT INTO public.word VALUES (131, 'scolopendre', true);
INSERT INTO public.word VALUES (132, 'mosca', true);
INSERT INTO public.word VALUES (133, 'mosche', true);
INSERT INTO public.word VALUES (134, 'tarma', true);
INSERT INTO public.word VALUES (135, 'tarme', true);
INSERT INTO public.word VALUES (136, 'cimice', true);
INSERT INTO public.word VALUES (137, 'cimici', true);
INSERT INTO public.word VALUES (138, 'zanzara', true);
INSERT INTO public.word VALUES (139, 'zanzare', true);
INSERT INTO public.word VALUES (140, 'boia', true);
INSERT INTO public.word VALUES (141, 'boia-', true);
INSERT INTO public.word VALUES (142, 'roito', true);
INSERT INTO public.word VALUES (143, 'roiti', true);
INSERT INTO public.word VALUES (144, 'ladro', true);
INSERT INTO public.word VALUES (145, 'ladra', true);
INSERT INTO public.word VALUES (146, 'ladri', true);
INSERT INTO public.word VALUES (147, 'ladre', true);
INSERT INTO public.word VALUES (148, 'maniaco', true);
INSERT INTO public.word VALUES (149, 'maniaca', true);
INSERT INTO public.word VALUES (150, 'maniaci', true);
INSERT INTO public.word VALUES (151, 'maniache', true);
INSERT INTO public.word VALUES (152, 'pedofilo', true);
INSERT INTO public.word VALUES (153, 'pedofila', true);
INSERT INTO public.word VALUES (154, 'pedofili', true);
INSERT INTO public.word VALUES (155, 'pedofile', true);
INSERT INTO public.word VALUES (156, 'necrofilo', true);
INSERT INTO public.word VALUES (157, 'necrofila', true);
INSERT INTO public.word VALUES (158, 'necrofili', true);
INSERT INTO public.word VALUES (159, 'necrofile', true);
INSERT INTO public.word VALUES (160, 'coprofilo', true);
INSERT INTO public.word VALUES (161, 'coprofila', true);
INSERT INTO public.word VALUES (162, 'coprofili', true);
INSERT INTO public.word VALUES (163, 'coprofile', true);
INSERT INTO public.word VALUES (164, 'gerontofilo', true);
INSERT INTO public.word VALUES (165, 'gerontofila', true);
INSERT INTO public.word VALUES (166, 'gerontofili', true);
INSERT INTO public.word VALUES (167, 'gerontofile', true);
INSERT INTO public.word VALUES (172, 'zoofilo', true);
INSERT INTO public.word VALUES (173, 'zoofila', true);
INSERT INTO public.word VALUES (174, 'zoofili', true);
INSERT INTO public.word VALUES (175, 'zoofile', true);
INSERT INTO public.word VALUES (176, 'stupratore', true);
INSERT INTO public.word VALUES (177, 'stupratrice', true);
INSERT INTO public.word VALUES (178, 'stupratori', true);
INSERT INTO public.word VALUES (179, 'stupratrici', true);
INSERT INTO public.word VALUES (180, 'assassino', true);
INSERT INTO public.word VALUES (169, 'dendrofila', true);
INSERT INTO public.word VALUES (170, 'dendrofili', true);
INSERT INTO public.word VALUES (171, 'dendrofile', true);
INSERT INTO public.word VALUES (181, 'assassina', true);
INSERT INTO public.word VALUES (182, 'assassini', true);
INSERT INTO public.word VALUES (183, 'assassine', true);
INSERT INTO public.word VALUES (184, 'aguzzino', true);
INSERT INTO public.word VALUES (185, 'aguzzina', true);
INSERT INTO public.word VALUES (186, 'aguzzini', true);
INSERT INTO public.word VALUES (187, 'aguzzine', true);
INSERT INTO public.word VALUES (188, 'spacciatore', true);
INSERT INTO public.word VALUES (189, 'spacciatrice', true);
INSERT INTO public.word VALUES (190, 'spacciatori', true);
INSERT INTO public.word VALUES (191, 'spacciatrici', true);
INSERT INTO public.word VALUES (192, 'zingaro', true);
INSERT INTO public.word VALUES (193, 'zingara', true);
INSERT INTO public.word VALUES (194, 'zingari', true);
INSERT INTO public.word VALUES (195, 'zingare', true);
INSERT INTO public.word VALUES (196, 'puttana', true);
INSERT INTO public.word VALUES (197, 'puttane', true);
INSERT INTO public.word VALUES (198, 'troia', true);
INSERT INTO public.word VALUES (199, 'troie', true);
INSERT INTO public.word VALUES (200, 'prostituta', true);
INSERT INTO public.word VALUES (201, 'prostitute', true);
INSERT INTO public.word VALUES (202, 'zoccola', true);
INSERT INTO public.word VALUES (203, 'zoccole', true);
INSERT INTO public.word VALUES (204, 'mignotta', true);
INSERT INTO public.word VALUES (205, 'mignotte', true);
INSERT INTO public.word VALUES (206, 'meretrice', true);
INSERT INTO public.word VALUES (207, 'meretrici', true);
INSERT INTO public.word VALUES (208, 'androcchia', true);
INSERT INTO public.word VALUES (209, 'androcchie', true);
INSERT INTO public.word VALUES (210, 'pompinaro', true);
INSERT INTO public.word VALUES (211, 'pompinara', true);
INSERT INTO public.word VALUES (212, 'pompinari', true);
INSERT INTO public.word VALUES (213, 'pompinare', true);
INSERT INTO public.word VALUES (214, 'bocchinaro', true);
INSERT INTO public.word VALUES (215, 'bocchinara', true);
INSERT INTO public.word VALUES (216, 'bocchinari', true);
INSERT INTO public.word VALUES (217, 'bocchinare', true);
INSERT INTO public.word VALUES (218, 'segaiolo', true);
INSERT INTO public.word VALUES (219, 'segaiola', true);
INSERT INTO public.word VALUES (220, 'segaioli', true);
INSERT INTO public.word VALUES (221, 'segaiole', true);
INSERT INTO public.word VALUES (222, 'maledetto', true);
INSERT INTO public.word VALUES (223, 'maledetta', true);
INSERT INTO public.word VALUES (224, 'maledetti', true);
INSERT INTO public.word VALUES (225, 'maledette', true);
INSERT INTO public.word VALUES (226, 'spastico', true);
INSERT INTO public.word VALUES (227, 'spastica', true);
INSERT INTO public.word VALUES (228, 'spastici', true);
INSERT INTO public.word VALUES (229, 'spastiche', true);
INSERT INTO public.word VALUES (230, 'sudicio', true);
INSERT INTO public.word VALUES (231, 'sudicia', true);
INSERT INTO public.word VALUES (232, 'sudici', true);
INSERT INTO public.word VALUES (233, 'sudicie', true);
INSERT INTO public.word VALUES (234, 'lezzo', true);
INSERT INTO public.word VALUES (235, 'lezza', true);
INSERT INTO public.word VALUES (236, 'lezzi', true);
INSERT INTO public.word VALUES (237, 'lezze', true);
INSERT INTO public.word VALUES (238, 'sporco', true);
INSERT INTO public.word VALUES (239, 'sporca', true);
INSERT INTO public.word VALUES (240, 'sporchi', true);
INSERT INTO public.word VALUES (241, 'sporche', true);
INSERT INTO public.word VALUES (242, 'unto', true);
INSERT INTO public.word VALUES (243, 'unta', true);
INSERT INTO public.word VALUES (244, 'unti', true);
INSERT INTO public.word VALUES (245, 'unte', true);
INSERT INTO public.word VALUES (246, 'fradicio', true);
INSERT INTO public.word VALUES (247, 'fradicia', true);
INSERT INTO public.word VALUES (248, 'fradici', true);
INSERT INTO public.word VALUES (249, 'fradicie', true);
INSERT INTO public.word VALUES (250, 'macchiato', true);
INSERT INTO public.word VALUES (251, 'macchiata', true);
INSERT INTO public.word VALUES (252, 'macchiati', true);
INSERT INTO public.word VALUES (253, 'macchiate', true);
INSERT INTO public.word VALUES (254, 'stronzo', true);
INSERT INTO public.word VALUES (255, 'stronza', true);
INSERT INTO public.word VALUES (256, 'stronzi', true);
INSERT INTO public.word VALUES (257, 'stronze', true);
INSERT INTO public.word VALUES (258, 'brutto', true);
INSERT INTO public.word VALUES (259, 'brutta', true);
INSERT INTO public.word VALUES (260, 'brutti', true);
INSERT INTO public.word VALUES (261, 'brutte', true);
INSERT INTO public.word VALUES (262, 'orbo', true);
INSERT INTO public.word VALUES (263, 'orba', true);
INSERT INTO public.word VALUES (264, 'orbi', true);
INSERT INTO public.word VALUES (265, 'orbe', true);
INSERT INTO public.word VALUES (266, 'zoppo', true);
INSERT INTO public.word VALUES (267, 'zoppa', true);
INSERT INTO public.word VALUES (268, 'zoppi', true);
INSERT INTO public.word VALUES (269, 'zoppe', true);
INSERT INTO public.word VALUES (270, 'perfido', true);
INSERT INTO public.word VALUES (271, 'perfida', true);
INSERT INTO public.word VALUES (272, 'perfidi', true);
INSERT INTO public.word VALUES (273, 'perfide', true);
INSERT INTO public.word VALUES (274, 'inetto', true);
INSERT INTO public.word VALUES (275, 'inetta', true);
INSERT INTO public.word VALUES (276, 'inetti', true);
INSERT INTO public.word VALUES (277, 'inette', true);
INSERT INTO public.word VALUES (278, 'tonto', true);
INSERT INTO public.word VALUES (279, 'tonta', true);
INSERT INTO public.word VALUES (280, 'tonti', true);
INSERT INTO public.word VALUES (281, 'tonte', true);
INSERT INTO public.word VALUES (282, 'subdolo', true);
INSERT INTO public.word VALUES (283, 'subdola', true);
INSERT INTO public.word VALUES (284, 'subdoli', true);
INSERT INTO public.word VALUES (285, 'subdole', true);
INSERT INTO public.word VALUES (286, 'povero', true);
INSERT INTO public.word VALUES (287, 'povera', true);
INSERT INTO public.word VALUES (288, 'poveri', true);
INSERT INTO public.word VALUES (289, 'povere', true);
INSERT INTO public.word VALUES (290, 'plebeo', true);
INSERT INTO public.word VALUES (291, 'plebea', true);
INSERT INTO public.word VALUES (292, 'plebei', true);
INSERT INTO public.word VALUES (293, 'plebee', true);
INSERT INTO public.word VALUES (294, 'mentecatto', true);
INSERT INTO public.word VALUES (295, 'mentecatta', true);
INSERT INTO public.word VALUES (296, 'mentecatti', true);
INSERT INTO public.word VALUES (297, 'mentecatte', true);
INSERT INTO public.word VALUES (298, 'malvagio', true);
INSERT INTO public.word VALUES (299, 'malvagia', true);
INSERT INTO public.word VALUES (300, 'malvagi', true);
INSERT INTO public.word VALUES (301, 'malvagie', true);
INSERT INTO public.word VALUES (302, 'schifoso', true);
INSERT INTO public.word VALUES (303, 'schifosa', true);
INSERT INTO public.word VALUES (304, 'schifosi', true);
INSERT INTO public.word VALUES (305, 'schifose', true);
INSERT INTO public.word VALUES (306, 'disgustoso', true);
INSERT INTO public.word VALUES (307, 'disgustosa', true);
INSERT INTO public.word VALUES (308, 'disgustosi', true);
INSERT INTO public.word VALUES (309, 'disgustose', true);
INSERT INTO public.word VALUES (310, 'viscido', true);
INSERT INTO public.word VALUES (311, 'viscida', true);
INSERT INTO public.word VALUES (312, 'viscidi', true);
INSERT INTO public.word VALUES (313, 'viscide', true);
INSERT INTO public.word VALUES (314, 'fetido', true);
INSERT INTO public.word VALUES (315, 'fetida', true);
INSERT INTO public.word VALUES (316, 'fetidi', true);
INSERT INTO public.word VALUES (317, 'fetide', true);
INSERT INTO public.word VALUES (318, 'cretino', true);
INSERT INTO public.word VALUES (319, 'cretina', true);
INSERT INTO public.word VALUES (320, 'cretini', true);
INSERT INTO public.word VALUES (321, 'cretine', true);
INSERT INTO public.word VALUES (322, 'stupido', true);
INSERT INTO public.word VALUES (323, 'stupida', true);
INSERT INTO public.word VALUES (324, 'stupidi', true);
INSERT INTO public.word VALUES (325, 'stupide', true);
INSERT INTO public.word VALUES (326, 'ritardato', true);
INSERT INTO public.word VALUES (327, 'ritardata', true);
INSERT INTO public.word VALUES (328, 'ritardati', true);
INSERT INTO public.word VALUES (329, 'ritardate', true);
INSERT INTO public.word VALUES (330, 'autistico', true);
INSERT INTO public.word VALUES (331, 'autistica', true);
INSERT INTO public.word VALUES (332, 'autistici', true);
INSERT INTO public.word VALUES (333, 'autistiche', true);
INSERT INTO public.word VALUES (334, 'scemo', true);
INSERT INTO public.word VALUES (335, 'scema', true);
INSERT INTO public.word VALUES (336, 'scemi', true);
INSERT INTO public.word VALUES (337, 'sceme', true);
INSERT INTO public.word VALUES (338, 'porco', true);
INSERT INTO public.word VALUES (339, 'porca', true);
INSERT INTO public.word VALUES (340, 'porci', true);
INSERT INTO public.word VALUES (341, 'porche', true);
INSERT INTO public.word VALUES (342, 'allupato', true);
INSERT INTO public.word VALUES (343, 'allupata', true);
INSERT INTO public.word VALUES (344, 'allupati', true);
INSERT INTO public.word VALUES (345, 'allupate', true);
INSERT INTO public.word VALUES (346, 'arrapato', true);
INSERT INTO public.word VALUES (347, 'arrapata', true);
INSERT INTO public.word VALUES (348, 'arrapati', true);
INSERT INTO public.word VALUES (349, 'arrapate', true);
INSERT INTO public.word VALUES (350, 'infoiato', true);
INSERT INTO public.word VALUES (351, 'infoiata', true);
INSERT INTO public.word VALUES (352, 'infoiati', true);
INSERT INTO public.word VALUES (353, 'infoiate', true);
INSERT INTO public.word VALUES (354, 'malato', true);
INSERT INTO public.word VALUES (355, 'malata', true);
INSERT INTO public.word VALUES (356, 'malati', true);
INSERT INTO public.word VALUES (357, 'malate', true);
INSERT INTO public.word VALUES (358, 'monco', true);
INSERT INTO public.word VALUES (359, 'monca', true);
INSERT INTO public.word VALUES (360, 'monchi', true);
INSERT INTO public.word VALUES (361, 'monche', true);
INSERT INTO public.word VALUES (362, 'deturpato', true);
INSERT INTO public.word VALUES (363, 'deturpata', true);
INSERT INTO public.word VALUES (364, 'deturpati', true);
INSERT INTO public.word VALUES (365, 'deturpate', true);
INSERT INTO public.word VALUES (366, 'smembrato', true);
INSERT INTO public.word VALUES (367, 'smembrata', true);
INSERT INTO public.word VALUES (368, 'smembrati', true);
INSERT INTO public.word VALUES (369, 'smembrate', true);
INSERT INTO public.word VALUES (370, 'bastardo', true);
INSERT INTO public.word VALUES (371, 'bastarda', true);
INSERT INTO public.word VALUES (372, 'bastardi', true);
INSERT INTO public.word VALUES (373, 'bastarde', true);
INSERT INTO public.word VALUES (374, 'misero', true);
INSERT INTO public.word VALUES (375, 'misera', true);
INSERT INTO public.word VALUES (376, 'miseri', true);
INSERT INTO public.word VALUES (377, 'misere', true);
INSERT INTO public.word VALUES (378, 'ridicolo', true);
INSERT INTO public.word VALUES (379, 'ridicola', true);
INSERT INTO public.word VALUES (380, 'ridicoli', true);
INSERT INTO public.word VALUES (381, 'ridicole', true);
INSERT INTO public.word VALUES (382, 'drogato', true);
INSERT INTO public.word VALUES (383, 'drogata', true);
INSERT INTO public.word VALUES (384, 'drogati', true);
INSERT INTO public.word VALUES (385, 'drogate', true);
INSERT INTO public.word VALUES (386, 'impasticcato', true);
INSERT INTO public.word VALUES (387, 'impasticcata', true);
INSERT INTO public.word VALUES (388, 'impasticcati', true);
INSERT INTO public.word VALUES (389, 'impasticcate', true);
INSERT INTO public.word VALUES (390, 'cannato', true);
INSERT INTO public.word VALUES (391, 'cannata', true);
INSERT INTO public.word VALUES (392, 'cannati', true);
INSERT INTO public.word VALUES (393, 'cannate', true);
INSERT INTO public.word VALUES (394, 'tubercoloso', true);
INSERT INTO public.word VALUES (395, 'tubercolosa', true);
INSERT INTO public.word VALUES (396, 'tubercolosi', true);
INSERT INTO public.word VALUES (397, 'tubercolose', true);
INSERT INTO public.word VALUES (398, 'pustoloso', true);
INSERT INTO public.word VALUES (399, 'pustolosa', true);
INSERT INTO public.word VALUES (400, 'pustolosi', true);
INSERT INTO public.word VALUES (401, 'pustolose', true);
INSERT INTO public.word VALUES (402, 'rugoso', true);
INSERT INTO public.word VALUES (403, 'rugosa', true);
INSERT INTO public.word VALUES (404, 'rugosi', true);
INSERT INTO public.word VALUES (405, 'rugose', true);
INSERT INTO public.word VALUES (406, 'ammuffito', true);
INSERT INTO public.word VALUES (407, 'ammuffita', true);
INSERT INTO public.word VALUES (408, 'ammuffiti', true);
INSERT INTO public.word VALUES (409, 'ammuffite', true);
INSERT INTO public.word VALUES (410, 'brufoloso', true);
INSERT INTO public.word VALUES (411, 'brufolosa', true);
INSERT INTO public.word VALUES (412, 'brufolosi', true);
INSERT INTO public.word VALUES (413, 'brufolose', true);
INSERT INTO public.word VALUES (414, 'merdoso', true);
INSERT INTO public.word VALUES (415, 'merdosa', true);
INSERT INTO public.word VALUES (416, 'merdosi', true);
INSERT INTO public.word VALUES (417, 'merdose', true);
INSERT INTO public.word VALUES (418, 'pulcioso', true);
INSERT INTO public.word VALUES (419, 'pulciosa', true);
INSERT INTO public.word VALUES (420, 'pulciosi', true);
INSERT INTO public.word VALUES (421, 'pulciose', true);
INSERT INTO public.word VALUES (422, 'piattoloso', true);
INSERT INTO public.word VALUES (423, 'piattolosa', true);
INSERT INTO public.word VALUES (424, 'piattolosi', true);
INSERT INTO public.word VALUES (425, 'piattolose', true);
INSERT INTO public.word VALUES (426, 'morcoso', true);
INSERT INTO public.word VALUES (427, 'morcosa', true);
INSERT INTO public.word VALUES (428, 'morcosi', true);
INSERT INTO public.word VALUES (429, 'morcose', true);
INSERT INTO public.word VALUES (430, 'incrostato', true);
INSERT INTO public.word VALUES (431, 'incrostata', true);
INSERT INTO public.word VALUES (432, 'incrostati', true);
INSERT INTO public.word VALUES (433, 'incrostate', true);
INSERT INTO public.word VALUES (434, 'rugginoso', true);
INSERT INTO public.word VALUES (435, 'rugginosa', true);
INSERT INTO public.word VALUES (436, 'rugginosi', true);
INSERT INTO public.word VALUES (437, 'rugginose', true);
INSERT INTO public.word VALUES (438, 'grommoso', true);
INSERT INTO public.word VALUES (439, 'grommosa', true);
INSERT INTO public.word VALUES (440, 'grommosi', true);
INSERT INTO public.word VALUES (441, 'grommose', true);
INSERT INTO public.word VALUES (442, 'fangoso', true);
INSERT INTO public.word VALUES (443, 'fangosa', true);
INSERT INTO public.word VALUES (444, 'fangosi', true);
INSERT INTO public.word VALUES (445, 'fangose', true);
INSERT INTO public.word VALUES (446, 'polveroso', true);
INSERT INTO public.word VALUES (447, 'polverosa', true);
INSERT INTO public.word VALUES (448, 'polverosi', true);
INSERT INTO public.word VALUES (449, 'polverose', true);
INSERT INTO public.word VALUES (450, 'lercio', true);
INSERT INTO public.word VALUES (451, 'lercia', true);
INSERT INTO public.word VALUES (452, 'lerci', true);
INSERT INTO public.word VALUES (453, 'lerce', true);
INSERT INTO public.word VALUES (454, 'putrido', true);
INSERT INTO public.word VALUES (455, 'putrida', true);
INSERT INTO public.word VALUES (456, 'putridi', true);
INSERT INTO public.word VALUES (457, 'putride', true);
INSERT INTO public.word VALUES (458, 'lurido', true);
INSERT INTO public.word VALUES (459, 'lurida', true);
INSERT INTO public.word VALUES (460, 'luridi', true);
INSERT INTO public.word VALUES (461, 'luride', true);
INSERT INTO public.word VALUES (462, 'putrefatto', true);
INSERT INTO public.word VALUES (463, 'putrefatta', true);
INSERT INTO public.word VALUES (464, 'putrefatti', true);
INSERT INTO public.word VALUES (465, 'putrefatte', true);
INSERT INTO public.word VALUES (466, 'arrugginito', true);
INSERT INTO public.word VALUES (467, 'arrugginita', true);
INSERT INTO public.word VALUES (468, 'arrugginiti', true);
INSERT INTO public.word VALUES (469, 'arrugginite', true);
INSERT INTO public.word VALUES (470, 'terrone-', true);
INSERT INTO public.word VALUES (471, 'terrona', true);
INSERT INTO public.word VALUES (472, 'terroni', true);
INSERT INTO public.word VALUES (473, 'terrone', true);
INSERT INTO public.word VALUES (474, 'polentone-', true);
INSERT INTO public.word VALUES (475, 'polentona', true);
INSERT INTO public.word VALUES (476, 'polentoni', true);
INSERT INTO public.word VALUES (477, 'polentone', true);
INSERT INTO public.word VALUES (478, 'negro', true);
INSERT INTO public.word VALUES (479, 'negra', true);
INSERT INTO public.word VALUES (480, 'negri', true);
INSERT INTO public.word VALUES (481, 'negre', true);
INSERT INTO public.word VALUES (482, 'rumeno', true);
INSERT INTO public.word VALUES (483, 'rumena', true);
INSERT INTO public.word VALUES (484, 'rumeni', true);
INSERT INTO public.word VALUES (485, 'rumene', true);
INSERT INTO public.word VALUES (486, 'ebreo', true);
INSERT INTO public.word VALUES (487, 'ebrea', true);
INSERT INTO public.word VALUES (488, 'ebrei', true);
INSERT INTO public.word VALUES (489, 'ebree', true);
INSERT INTO public.word VALUES (490, 'demente', true);
INSERT INTO public.word VALUES (491, 'demente-', true);
INSERT INTO public.word VALUES (492, 'dementi', true);
INSERT INTO public.word VALUES (493, 'dementi-', true);
INSERT INTO public.word VALUES (494, 'idiota-', true);
INSERT INTO public.word VALUES (495, 'idiota', true);
INSERT INTO public.word VALUES (496, 'idioti', true);
INSERT INTO public.word VALUES (497, 'idiote', true);
INSERT INTO public.word VALUES (498, 'infame-', true);
INSERT INTO public.word VALUES (499, 'infame', true);
INSERT INTO public.word VALUES (500, 'infami', true);
INSERT INTO public.word VALUES (501, 'infami-', true);
INSERT INTO public.word VALUES (502, 'inculato', true);
INSERT INTO public.word VALUES (503, 'inculata', true);
INSERT INTO public.word VALUES (504, 'inculati', true);
INSERT INTO public.word VALUES (505, 'inculate', true);
INSERT INTO public.word VALUES (506, 'inchiappettato', true);
INSERT INTO public.word VALUES (507, 'inchiappettata', true);
INSERT INTO public.word VALUES (508, 'inchiappettati', true);
INSERT INTO public.word VALUES (509, 'inchiappettate', true);
INSERT INTO public.word VALUES (510, 'violentato', true);
INSERT INTO public.word VALUES (511, 'violentata', true);
INSERT INTO public.word VALUES (512, 'violentati', true);
INSERT INTO public.word VALUES (513, 'violentate', true);
INSERT INTO public.word VALUES (514, 'molestato', true);
INSERT INTO public.word VALUES (515, 'molestata', true);
INSERT INTO public.word VALUES (516, 'molestati', true);
INSERT INTO public.word VALUES (517, 'molestate', true);
INSERT INTO public.word VALUES (518, 'stuprato', true);
INSERT INTO public.word VALUES (519, 'stuprata', true);
INSERT INTO public.word VALUES (520, 'stuprati', true);
INSERT INTO public.word VALUES (521, 'stuprate', true);
INSERT INTO public.word VALUES (522, 'pestato', true);
INSERT INTO public.word VALUES (523, 'pestata', true);
INSERT INTO public.word VALUES (524, 'pestati', true);
INSERT INTO public.word VALUES (525, 'pestate', true);
INSERT INTO public.word VALUES (526, 'trucidato', true);
INSERT INTO public.word VALUES (527, 'trucidata', true);
INSERT INTO public.word VALUES (528, 'trucidati', true);
INSERT INTO public.word VALUES (529, 'trucidate', true);
INSERT INTO public.word VALUES (530, 'mazzuolato', true);
INSERT INTO public.word VALUES (531, 'mazzuolata', true);
INSERT INTO public.word VALUES (532, 'mazzuolati', true);
INSERT INTO public.word VALUES (533, 'mazzuolate', true);
INSERT INTO public.word VALUES (534, 'pugnalato', true);
INSERT INTO public.word VALUES (535, 'pugnalata', true);
INSERT INTO public.word VALUES (536, 'pugnalati', true);
INSERT INTO public.word VALUES (537, 'pugnalate', true);
INSERT INTO public.word VALUES (538, 'squartato', true);
INSERT INTO public.word VALUES (539, 'squartata', true);
INSERT INTO public.word VALUES (540, 'squartati', true);
INSERT INTO public.word VALUES (541, 'squartate', true);
INSERT INTO public.word VALUES (542, 'sbranato', true);
INSERT INTO public.word VALUES (543, 'sbranata', true);
INSERT INTO public.word VALUES (544, 'sbranati', true);
INSERT INTO public.word VALUES (545, 'sbranate', true);
INSERT INTO public.word VALUES (546, 'fucilato', true);
INSERT INTO public.word VALUES (547, 'fucilata', true);
INSERT INTO public.word VALUES (548, 'fucilati', true);
INSERT INTO public.word VALUES (549, 'fucilate', true);
INSERT INTO public.word VALUES (550, 'inchiodato', true);
INSERT INTO public.word VALUES (551, 'inchiodata', true);
INSERT INTO public.word VALUES (552, 'inchiodati', true);
INSERT INTO public.word VALUES (553, 'inchiodate', true);
INSERT INTO public.word VALUES (554, 'incenerito', true);
INSERT INTO public.word VALUES (555, 'incenerita', true);
INSERT INTO public.word VALUES (556, 'inceneriti', true);
INSERT INTO public.word VALUES (557, 'incenerite', true);
INSERT INTO public.word VALUES (558, 'impalato', true);
INSERT INTO public.word VALUES (559, 'impalata', true);
INSERT INTO public.word VALUES (560, 'impalati', true);
INSERT INTO public.word VALUES (561, 'impalate', true);
INSERT INTO public.word VALUES (562, 'impallinato', true);
INSERT INTO public.word VALUES (563, 'impallinata', true);
INSERT INTO public.word VALUES (564, 'impallinati', true);
INSERT INTO public.word VALUES (565, 'impallinate', true);
INSERT INTO public.word VALUES (566, 'accoltellato', true);
INSERT INTO public.word VALUES (567, 'accoltellata', true);
INSERT INTO public.word VALUES (568, 'accoltellati', true);
INSERT INTO public.word VALUES (569, 'accoltellate', true);
INSERT INTO public.word VALUES (570, 'arso', true);
INSERT INTO public.word VALUES (571, 'arsa', true);
INSERT INTO public.word VALUES (572, 'arsi', true);
INSERT INTO public.word VALUES (573, 'arse', true);
INSERT INTO public.word VALUES (574, 'mannaggia', true);
INSERT INTO public.word VALUES (575, 'accidenti', true);
INSERT INTO public.word VALUES (576, 'peste colga', true);
INSERT INTO public.word VALUES (577, 'morisse', true);
INSERT INTO public.word VALUES (578, 'morissero', true);
INSERT INTO public.word VALUES (579, 'crepasse', true);
INSERT INTO public.word VALUES (580, 'schiattasse', true);
INSERT INTO public.word VALUES (581, 'crepassero', true);
INSERT INTO public.word VALUES (582, 'schiattassero', true);
INSERT INTO public.word VALUES (583, '-', false);
INSERT INTO public.word VALUES (584, 'il', false);
INSERT INTO public.word VALUES (585, 'lo', false);
INSERT INTO public.word VALUES (586, 'la', false);
INSERT INTO public.word VALUES (587, 'i', false);
INSERT INTO public.word VALUES (588, 'gli', false);
INSERT INTO public.word VALUES (589, 'le', false);
INSERT INTO public.word VALUES (590, 'l''', false);
INSERT INTO public.word VALUES (591, 'un', false);
INSERT INTO public.word VALUES (592, 'uno', false);
INSERT INTO public.word VALUES (593, 'una', false);
INSERT INTO public.word VALUES (594, 'un''', false);
INSERT INTO public.word VALUES (595, 'di', false);
INSERT INTO public.word VALUES (596, 'del', false);
INSERT INTO public.word VALUES (597, 'dello', false);
INSERT INTO public.word VALUES (598, 'della', false);
INSERT INTO public.word VALUES (599, 'dei', false);
INSERT INTO public.word VALUES (600, 'degli', false);
INSERT INTO public.word VALUES (601, 'delle', false);
INSERT INTO public.word VALUES (602, 'dell''', false);
INSERT INTO public.word VALUES (603, 'a', false);
INSERT INTO public.word VALUES (604, 'al', false);
INSERT INTO public.word VALUES (605, 'allo', false);
INSERT INTO public.word VALUES (606, 'alla', false);
INSERT INTO public.word VALUES (607, 'ai', false);
INSERT INTO public.word VALUES (608, 'agli', false);
INSERT INTO public.word VALUES (609, 'alle', false);
INSERT INTO public.word VALUES (610, 'all''', false);
INSERT INTO public.word VALUES (611, 'da', false);
INSERT INTO public.word VALUES (612, 'dal', false);
INSERT INTO public.word VALUES (613, 'dallo', false);
INSERT INTO public.word VALUES (614, 'dalla', false);
INSERT INTO public.word VALUES (615, 'dai', false);
INSERT INTO public.word VALUES (616, 'dagli', false);
INSERT INTO public.word VALUES (617, 'dalle', false);
INSERT INTO public.word VALUES (618, 'dall''', false);
INSERT INTO public.word VALUES (619, 'in', false);
INSERT INTO public.word VALUES (620, 'nel', false);
INSERT INTO public.word VALUES (621, 'nello', false);
INSERT INTO public.word VALUES (622, 'nella', false);
INSERT INTO public.word VALUES (623, 'nei', false);
INSERT INTO public.word VALUES (624, 'negli', false);
INSERT INTO public.word VALUES (625, 'nelle', false);
INSERT INTO public.word VALUES (626, 'nell''', false);
INSERT INTO public.word VALUES (627, 'su', false);
INSERT INTO public.word VALUES (628, 'sul', false);
INSERT INTO public.word VALUES (629, 'sullo', false);
INSERT INTO public.word VALUES (630, 'sulla', false);
INSERT INTO public.word VALUES (631, 'sui', false);
INSERT INTO public.word VALUES (632, 'sugli', false);
INSERT INTO public.word VALUES (633, 'sulle', false);
INSERT INTO public.word VALUES (634, 'sull''', false);
INSERT INTO public.word VALUES (635, 'con', false);
INSERT INTO public.word VALUES (636, 'col', false);
INSERT INTO public.word VALUES (637, 'con la', false);
INSERT INTO public.word VALUES (638, 'con lo', false);
INSERT INTO public.word VALUES (639, 'con l''', false);
INSERT INTO public.word VALUES (640, 'con gli', false);
INSERT INTO public.word VALUES (641, 'con le', false);
INSERT INTO public.word VALUES (642, 'coi', false);
INSERT INTO public.word VALUES (643, 'per', false);
INSERT INTO public.word VALUES (644, 'per il', false);
INSERT INTO public.word VALUES (645, 'per la', false);
INSERT INTO public.word VALUES (646, 'per lo', false);
INSERT INTO public.word VALUES (647, 'per l''', false);
INSERT INTO public.word VALUES (648, 'per gli', false);
INSERT INTO public.word VALUES (649, 'per le', false);
INSERT INTO public.word VALUES (650, 'per i', false);
INSERT INTO public.word VALUES (651, 'tra', false);
INSERT INTO public.word VALUES (652, 'tra il', false);
INSERT INTO public.word VALUES (653, 'tra la', false);
INSERT INTO public.word VALUES (654, 'tra lo', false);
INSERT INTO public.word VALUES (655, 'tra l''', false);
INSERT INTO public.word VALUES (656, 'tra gli', false);
INSERT INTO public.word VALUES (657, 'tra le', false);
INSERT INTO public.word VALUES (658, 'tra i', false);
INSERT INTO public.word VALUES (659, 'fra', false);
INSERT INTO public.word VALUES (660, 'fra il', false);
INSERT INTO public.word VALUES (661, 'fra la', false);
INSERT INTO public.word VALUES (662, 'fra lo', false);
INSERT INTO public.word VALUES (663, 'fra l''', false);
INSERT INTO public.word VALUES (664, 'fra gli', false);
INSERT INTO public.word VALUES (665, 'fra le', false);
INSERT INTO public.word VALUES (666, 'fra i', false);
INSERT INTO public.word VALUES (667, 'come', false);
INSERT INTO public.word VALUES (668, 'quel', false);
INSERT INTO public.word VALUES (669, 'quello', false);
INSERT INTO public.word VALUES (670, 'quell''', false);
INSERT INTO public.word VALUES (671, 'quella', false);
INSERT INTO public.word VALUES (672, 'quelle', false);
INSERT INTO public.word VALUES (673, 'quei', false);
INSERT INTO public.word VALUES (674, 'quegli', false);
INSERT INTO public.word VALUES (675, 'questo', false);
INSERT INTO public.word VALUES (676, 'questa', false);
INSERT INTO public.word VALUES (677, 'quest''', false);
INSERT INTO public.word VALUES (678, 'questi', false);
INSERT INTO public.word VALUES (679, 'queste', false);
INSERT INTO public.word VALUES (680, 'tutto', true);
INSERT INTO public.word VALUES (681, 'tutta', true);
INSERT INTO public.word VALUES (682, 'tutti', true);
INSERT INTO public.word VALUES (683, 'tutte', true);
INSERT INTO public.word VALUES (168, 'dendrofilo', true);


--
-- TOC entry 3444 (class 0 OID 16469)
-- Dependencies: 223
-- Data for Name: word_grammar_compatibility; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.word_grammar_compatibility VALUES (2169, 659, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2170, 659, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2171, 659, 12);
INSERT INTO public.word_grammar_compatibility VALUES (4, 1, 1);
INSERT INTO public.word_grammar_compatibility VALUES (5, 1, 2);
INSERT INTO public.word_grammar_compatibility VALUES (6, 1, 3);
INSERT INTO public.word_grammar_compatibility VALUES (7, 2, 1);
INSERT INTO public.word_grammar_compatibility VALUES (8, 2, 2);
INSERT INTO public.word_grammar_compatibility VALUES (9, 2, 3);
INSERT INTO public.word_grammar_compatibility VALUES (10, 3, 5);
INSERT INTO public.word_grammar_compatibility VALUES (11, 3, 6);
INSERT INTO public.word_grammar_compatibility VALUES (12, 4, 1);
INSERT INTO public.word_grammar_compatibility VALUES (13, 4, 2);
INSERT INTO public.word_grammar_compatibility VALUES (14, 4, 3);
INSERT INTO public.word_grammar_compatibility VALUES (15, 5, 1);
INSERT INTO public.word_grammar_compatibility VALUES (16, 5, 2);
INSERT INTO public.word_grammar_compatibility VALUES (17, 5, 3);
INSERT INTO public.word_grammar_compatibility VALUES (18, 6, 8);
INSERT INTO public.word_grammar_compatibility VALUES (19, 6, 9);
INSERT INTO public.word_grammar_compatibility VALUES (20, 7, 8);
INSERT INTO public.word_grammar_compatibility VALUES (21, 7, 9);
INSERT INTO public.word_grammar_compatibility VALUES (22, 8, 8);
INSERT INTO public.word_grammar_compatibility VALUES (23, 8, 9);
INSERT INTO public.word_grammar_compatibility VALUES (24, 9, 1);
INSERT INTO public.word_grammar_compatibility VALUES (25, 9, 2);
INSERT INTO public.word_grammar_compatibility VALUES (26, 9, 3);
INSERT INTO public.word_grammar_compatibility VALUES (27, 10, 5);
INSERT INTO public.word_grammar_compatibility VALUES (28, 10, 6);
INSERT INTO public.word_grammar_compatibility VALUES (29, 11, 1);
INSERT INTO public.word_grammar_compatibility VALUES (30, 11, 2);
INSERT INTO public.word_grammar_compatibility VALUES (31, 11, 3);
INSERT INTO public.word_grammar_compatibility VALUES (32, 12, 1);
INSERT INTO public.word_grammar_compatibility VALUES (33, 12, 2);
INSERT INTO public.word_grammar_compatibility VALUES (34, 12, 3);
INSERT INTO public.word_grammar_compatibility VALUES (35, 13, 1);
INSERT INTO public.word_grammar_compatibility VALUES (36, 13, 2);
INSERT INTO public.word_grammar_compatibility VALUES (37, 13, 3);
INSERT INTO public.word_grammar_compatibility VALUES (38, 14, 1);
INSERT INTO public.word_grammar_compatibility VALUES (39, 14, 2);
INSERT INTO public.word_grammar_compatibility VALUES (40, 14, 3);
INSERT INTO public.word_grammar_compatibility VALUES (41, 15, 8);
INSERT INTO public.word_grammar_compatibility VALUES (42, 15, 9);
INSERT INTO public.word_grammar_compatibility VALUES (43, 16, 8);
INSERT INTO public.word_grammar_compatibility VALUES (44, 16, 9);
INSERT INTO public.word_grammar_compatibility VALUES (45, 17, 10);
INSERT INTO public.word_grammar_compatibility VALUES (46, 17, 11);
INSERT INTO public.word_grammar_compatibility VALUES (47, 18, 1);
INSERT INTO public.word_grammar_compatibility VALUES (48, 18, 2);
INSERT INTO public.word_grammar_compatibility VALUES (49, 18, 3);
INSERT INTO public.word_grammar_compatibility VALUES (50, 19, 1);
INSERT INTO public.word_grammar_compatibility VALUES (51, 19, 2);
INSERT INTO public.word_grammar_compatibility VALUES (52, 19, 3);
INSERT INTO public.word_grammar_compatibility VALUES (53, 20, 1);
INSERT INTO public.word_grammar_compatibility VALUES (54, 20, 2);
INSERT INTO public.word_grammar_compatibility VALUES (55, 20, 3);
INSERT INTO public.word_grammar_compatibility VALUES (56, 21, 1);
INSERT INTO public.word_grammar_compatibility VALUES (57, 21, 2);
INSERT INTO public.word_grammar_compatibility VALUES (58, 21, 3);
INSERT INTO public.word_grammar_compatibility VALUES (59, 22, 1);
INSERT INTO public.word_grammar_compatibility VALUES (60, 22, 2);
INSERT INTO public.word_grammar_compatibility VALUES (61, 22, 3);
INSERT INTO public.word_grammar_compatibility VALUES (62, 23, 1);
INSERT INTO public.word_grammar_compatibility VALUES (63, 23, 2);
INSERT INTO public.word_grammar_compatibility VALUES (64, 23, 3);
INSERT INTO public.word_grammar_compatibility VALUES (65, 24, 5);
INSERT INTO public.word_grammar_compatibility VALUES (66, 24, 6);
INSERT INTO public.word_grammar_compatibility VALUES (67, 25, 5);
INSERT INTO public.word_grammar_compatibility VALUES (68, 25, 6);
INSERT INTO public.word_grammar_compatibility VALUES (69, 26, 4);
INSERT INTO public.word_grammar_compatibility VALUES (70, 26, 1);
INSERT INTO public.word_grammar_compatibility VALUES (71, 26, 2);
INSERT INTO public.word_grammar_compatibility VALUES (72, 26, 3);
INSERT INTO public.word_grammar_compatibility VALUES (73, 27, 7);
INSERT INTO public.word_grammar_compatibility VALUES (74, 27, 5);
INSERT INTO public.word_grammar_compatibility VALUES (75, 27, 6);
INSERT INTO public.word_grammar_compatibility VALUES (76, 28, 12);
INSERT INTO public.word_grammar_compatibility VALUES (77, 28, 8);
INSERT INTO public.word_grammar_compatibility VALUES (78, 28, 9);
INSERT INTO public.word_grammar_compatibility VALUES (79, 29, 13);
INSERT INTO public.word_grammar_compatibility VALUES (80, 29, 10);
INSERT INTO public.word_grammar_compatibility VALUES (81, 30, 4);
INSERT INTO public.word_grammar_compatibility VALUES (82, 30, 1);
INSERT INTO public.word_grammar_compatibility VALUES (83, 30, 2);
INSERT INTO public.word_grammar_compatibility VALUES (84, 30, 3);
INSERT INTO public.word_grammar_compatibility VALUES (85, 30, 7);
INSERT INTO public.word_grammar_compatibility VALUES (86, 30, 5);
INSERT INTO public.word_grammar_compatibility VALUES (87, 30, 6);
INSERT INTO public.word_grammar_compatibility VALUES (88, 31, 12);
INSERT INTO public.word_grammar_compatibility VALUES (89, 31, 8);
INSERT INTO public.word_grammar_compatibility VALUES (90, 31, 9);
INSERT INTO public.word_grammar_compatibility VALUES (91, 31, 13);
INSERT INTO public.word_grammar_compatibility VALUES (92, 31, 10);
INSERT INTO public.word_grammar_compatibility VALUES (93, 32, 4);
INSERT INTO public.word_grammar_compatibility VALUES (94, 32, 1);
INSERT INTO public.word_grammar_compatibility VALUES (95, 32, 2);
INSERT INTO public.word_grammar_compatibility VALUES (96, 32, 3);
INSERT INTO public.word_grammar_compatibility VALUES (97, 32, 7);
INSERT INTO public.word_grammar_compatibility VALUES (98, 32, 5);
INSERT INTO public.word_grammar_compatibility VALUES (99, 32, 6);
INSERT INTO public.word_grammar_compatibility VALUES (100, 33, 12);
INSERT INTO public.word_grammar_compatibility VALUES (101, 33, 8);
INSERT INTO public.word_grammar_compatibility VALUES (102, 33, 9);
INSERT INTO public.word_grammar_compatibility VALUES (103, 33, 13);
INSERT INTO public.word_grammar_compatibility VALUES (104, 33, 10);
INSERT INTO public.word_grammar_compatibility VALUES (105, 34, 7);
INSERT INTO public.word_grammar_compatibility VALUES (106, 34, 5);
INSERT INTO public.word_grammar_compatibility VALUES (107, 34, 6);
INSERT INTO public.word_grammar_compatibility VALUES (108, 35, 13);
INSERT INTO public.word_grammar_compatibility VALUES (109, 35, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2172, 659, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2173, 660, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2174, 661, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2175, 662, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2176, 663, 3);
INSERT INTO public.word_grammar_compatibility VALUES (115, 36, 7);
INSERT INTO public.word_grammar_compatibility VALUES (116, 36, 5);
INSERT INTO public.word_grammar_compatibility VALUES (117, 36, 6);
INSERT INTO public.word_grammar_compatibility VALUES (118, 37, 13);
INSERT INTO public.word_grammar_compatibility VALUES (119, 37, 10);
INSERT INTO public.word_grammar_compatibility VALUES (120, 38, 4);
INSERT INTO public.word_grammar_compatibility VALUES (121, 38, 1);
INSERT INTO public.word_grammar_compatibility VALUES (122, 38, 2);
INSERT INTO public.word_grammar_compatibility VALUES (123, 38, 3);
INSERT INTO public.word_grammar_compatibility VALUES (124, 39, 7);
INSERT INTO public.word_grammar_compatibility VALUES (125, 39, 5);
INSERT INTO public.word_grammar_compatibility VALUES (126, 39, 6);
INSERT INTO public.word_grammar_compatibility VALUES (127, 40, 12);
INSERT INTO public.word_grammar_compatibility VALUES (128, 40, 8);
INSERT INTO public.word_grammar_compatibility VALUES (129, 40, 9);
INSERT INTO public.word_grammar_compatibility VALUES (130, 41, 13);
INSERT INTO public.word_grammar_compatibility VALUES (131, 41, 10);
INSERT INTO public.word_grammar_compatibility VALUES (132, 42, 4);
INSERT INTO public.word_grammar_compatibility VALUES (133, 42, 1);
INSERT INTO public.word_grammar_compatibility VALUES (134, 42, 2);
INSERT INTO public.word_grammar_compatibility VALUES (135, 42, 3);
INSERT INTO public.word_grammar_compatibility VALUES (136, 43, 12);
INSERT INTO public.word_grammar_compatibility VALUES (137, 43, 8);
INSERT INTO public.word_grammar_compatibility VALUES (138, 43, 9);
INSERT INTO public.word_grammar_compatibility VALUES (139, 44, 4);
INSERT INTO public.word_grammar_compatibility VALUES (140, 44, 1);
INSERT INTO public.word_grammar_compatibility VALUES (141, 44, 2);
INSERT INTO public.word_grammar_compatibility VALUES (142, 44, 3);
INSERT INTO public.word_grammar_compatibility VALUES (143, 45, 12);
INSERT INTO public.word_grammar_compatibility VALUES (144, 45, 8);
INSERT INTO public.word_grammar_compatibility VALUES (145, 45, 9);
INSERT INTO public.word_grammar_compatibility VALUES (146, 46, 4);
INSERT INTO public.word_grammar_compatibility VALUES (147, 46, 1);
INSERT INTO public.word_grammar_compatibility VALUES (148, 46, 2);
INSERT INTO public.word_grammar_compatibility VALUES (149, 46, 3);
INSERT INTO public.word_grammar_compatibility VALUES (150, 46, 7);
INSERT INTO public.word_grammar_compatibility VALUES (151, 46, 5);
INSERT INTO public.word_grammar_compatibility VALUES (152, 46, 6);
INSERT INTO public.word_grammar_compatibility VALUES (153, 47, 12);
INSERT INTO public.word_grammar_compatibility VALUES (154, 47, 8);
INSERT INTO public.word_grammar_compatibility VALUES (155, 47, 9);
INSERT INTO public.word_grammar_compatibility VALUES (156, 47, 13);
INSERT INTO public.word_grammar_compatibility VALUES (157, 47, 10);
INSERT INTO public.word_grammar_compatibility VALUES (158, 48, 4);
INSERT INTO public.word_grammar_compatibility VALUES (159, 48, 1);
INSERT INTO public.word_grammar_compatibility VALUES (160, 48, 2);
INSERT INTO public.word_grammar_compatibility VALUES (161, 48, 3);
INSERT INTO public.word_grammar_compatibility VALUES (162, 48, 7);
INSERT INTO public.word_grammar_compatibility VALUES (163, 48, 5);
INSERT INTO public.word_grammar_compatibility VALUES (164, 48, 6);
INSERT INTO public.word_grammar_compatibility VALUES (165, 49, 12);
INSERT INTO public.word_grammar_compatibility VALUES (166, 49, 8);
INSERT INTO public.word_grammar_compatibility VALUES (167, 49, 9);
INSERT INTO public.word_grammar_compatibility VALUES (168, 49, 13);
INSERT INTO public.word_grammar_compatibility VALUES (169, 49, 10);
INSERT INTO public.word_grammar_compatibility VALUES (170, 50, 4);
INSERT INTO public.word_grammar_compatibility VALUES (171, 50, 1);
INSERT INTO public.word_grammar_compatibility VALUES (172, 50, 2);
INSERT INTO public.word_grammar_compatibility VALUES (173, 50, 3);
INSERT INTO public.word_grammar_compatibility VALUES (174, 50, 7);
INSERT INTO public.word_grammar_compatibility VALUES (175, 50, 5);
INSERT INTO public.word_grammar_compatibility VALUES (176, 50, 6);
INSERT INTO public.word_grammar_compatibility VALUES (177, 51, 12);
INSERT INTO public.word_grammar_compatibility VALUES (178, 51, 8);
INSERT INTO public.word_grammar_compatibility VALUES (179, 51, 9);
INSERT INTO public.word_grammar_compatibility VALUES (180, 51, 13);
INSERT INTO public.word_grammar_compatibility VALUES (181, 51, 10);
INSERT INTO public.word_grammar_compatibility VALUES (182, 52, 4);
INSERT INTO public.word_grammar_compatibility VALUES (183, 52, 1);
INSERT INTO public.word_grammar_compatibility VALUES (184, 52, 2);
INSERT INTO public.word_grammar_compatibility VALUES (185, 52, 3);
INSERT INTO public.word_grammar_compatibility VALUES (186, 52, 7);
INSERT INTO public.word_grammar_compatibility VALUES (187, 52, 5);
INSERT INTO public.word_grammar_compatibility VALUES (188, 52, 6);
INSERT INTO public.word_grammar_compatibility VALUES (189, 53, 12);
INSERT INTO public.word_grammar_compatibility VALUES (190, 53, 8);
INSERT INTO public.word_grammar_compatibility VALUES (191, 53, 9);
INSERT INTO public.word_grammar_compatibility VALUES (192, 53, 13);
INSERT INTO public.word_grammar_compatibility VALUES (193, 53, 10);
INSERT INTO public.word_grammar_compatibility VALUES (194, 54, 4);
INSERT INTO public.word_grammar_compatibility VALUES (195, 54, 1);
INSERT INTO public.word_grammar_compatibility VALUES (196, 54, 2);
INSERT INTO public.word_grammar_compatibility VALUES (197, 54, 3);
INSERT INTO public.word_grammar_compatibility VALUES (198, 54, 7);
INSERT INTO public.word_grammar_compatibility VALUES (199, 54, 5);
INSERT INTO public.word_grammar_compatibility VALUES (200, 54, 6);
INSERT INTO public.word_grammar_compatibility VALUES (201, 55, 12);
INSERT INTO public.word_grammar_compatibility VALUES (202, 55, 8);
INSERT INTO public.word_grammar_compatibility VALUES (203, 55, 9);
INSERT INTO public.word_grammar_compatibility VALUES (204, 55, 13);
INSERT INTO public.word_grammar_compatibility VALUES (205, 55, 10);
INSERT INTO public.word_grammar_compatibility VALUES (206, 56, 4);
INSERT INTO public.word_grammar_compatibility VALUES (207, 56, 1);
INSERT INTO public.word_grammar_compatibility VALUES (208, 56, 2);
INSERT INTO public.word_grammar_compatibility VALUES (209, 56, 3);
INSERT INTO public.word_grammar_compatibility VALUES (210, 56, 7);
INSERT INTO public.word_grammar_compatibility VALUES (211, 56, 5);
INSERT INTO public.word_grammar_compatibility VALUES (212, 56, 6);
INSERT INTO public.word_grammar_compatibility VALUES (213, 57, 12);
INSERT INTO public.word_grammar_compatibility VALUES (214, 57, 8);
INSERT INTO public.word_grammar_compatibility VALUES (215, 57, 9);
INSERT INTO public.word_grammar_compatibility VALUES (216, 57, 13);
INSERT INTO public.word_grammar_compatibility VALUES (217, 57, 10);
INSERT INTO public.word_grammar_compatibility VALUES (218, 58, 4);
INSERT INTO public.word_grammar_compatibility VALUES (219, 58, 1);
INSERT INTO public.word_grammar_compatibility VALUES (220, 58, 2);
INSERT INTO public.word_grammar_compatibility VALUES (221, 58, 3);
INSERT INTO public.word_grammar_compatibility VALUES (222, 58, 7);
INSERT INTO public.word_grammar_compatibility VALUES (223, 58, 5);
INSERT INTO public.word_grammar_compatibility VALUES (224, 58, 6);
INSERT INTO public.word_grammar_compatibility VALUES (225, 59, 12);
INSERT INTO public.word_grammar_compatibility VALUES (226, 59, 8);
INSERT INTO public.word_grammar_compatibility VALUES (227, 59, 9);
INSERT INTO public.word_grammar_compatibility VALUES (228, 59, 13);
INSERT INTO public.word_grammar_compatibility VALUES (229, 59, 10);
INSERT INTO public.word_grammar_compatibility VALUES (230, 60, 4);
INSERT INTO public.word_grammar_compatibility VALUES (231, 60, 1);
INSERT INTO public.word_grammar_compatibility VALUES (232, 60, 2);
INSERT INTO public.word_grammar_compatibility VALUES (233, 60, 3);
INSERT INTO public.word_grammar_compatibility VALUES (234, 60, 7);
INSERT INTO public.word_grammar_compatibility VALUES (235, 60, 5);
INSERT INTO public.word_grammar_compatibility VALUES (236, 60, 6);
INSERT INTO public.word_grammar_compatibility VALUES (237, 61, 12);
INSERT INTO public.word_grammar_compatibility VALUES (238, 61, 8);
INSERT INTO public.word_grammar_compatibility VALUES (239, 61, 9);
INSERT INTO public.word_grammar_compatibility VALUES (240, 61, 13);
INSERT INTO public.word_grammar_compatibility VALUES (241, 61, 10);
INSERT INTO public.word_grammar_compatibility VALUES (242, 62, 4);
INSERT INTO public.word_grammar_compatibility VALUES (243, 62, 1);
INSERT INTO public.word_grammar_compatibility VALUES (244, 62, 2);
INSERT INTO public.word_grammar_compatibility VALUES (245, 62, 3);
INSERT INTO public.word_grammar_compatibility VALUES (246, 62, 7);
INSERT INTO public.word_grammar_compatibility VALUES (247, 62, 5);
INSERT INTO public.word_grammar_compatibility VALUES (248, 62, 6);
INSERT INTO public.word_grammar_compatibility VALUES (249, 63, 12);
INSERT INTO public.word_grammar_compatibility VALUES (250, 63, 8);
INSERT INTO public.word_grammar_compatibility VALUES (251, 63, 9);
INSERT INTO public.word_grammar_compatibility VALUES (252, 63, 13);
INSERT INTO public.word_grammar_compatibility VALUES (253, 63, 10);
INSERT INTO public.word_grammar_compatibility VALUES (254, 64, 4);
INSERT INTO public.word_grammar_compatibility VALUES (255, 64, 1);
INSERT INTO public.word_grammar_compatibility VALUES (256, 64, 2);
INSERT INTO public.word_grammar_compatibility VALUES (257, 64, 3);
INSERT INTO public.word_grammar_compatibility VALUES (258, 64, 7);
INSERT INTO public.word_grammar_compatibility VALUES (259, 64, 5);
INSERT INTO public.word_grammar_compatibility VALUES (260, 64, 6);
INSERT INTO public.word_grammar_compatibility VALUES (261, 65, 12);
INSERT INTO public.word_grammar_compatibility VALUES (262, 65, 8);
INSERT INTO public.word_grammar_compatibility VALUES (263, 65, 9);
INSERT INTO public.word_grammar_compatibility VALUES (264, 65, 13);
INSERT INTO public.word_grammar_compatibility VALUES (265, 65, 10);
INSERT INTO public.word_grammar_compatibility VALUES (266, 66, 4);
INSERT INTO public.word_grammar_compatibility VALUES (267, 66, 1);
INSERT INTO public.word_grammar_compatibility VALUES (268, 66, 2);
INSERT INTO public.word_grammar_compatibility VALUES (269, 66, 3);
INSERT INTO public.word_grammar_compatibility VALUES (270, 66, 7);
INSERT INTO public.word_grammar_compatibility VALUES (271, 66, 5);
INSERT INTO public.word_grammar_compatibility VALUES (272, 66, 6);
INSERT INTO public.word_grammar_compatibility VALUES (273, 67, 12);
INSERT INTO public.word_grammar_compatibility VALUES (274, 67, 8);
INSERT INTO public.word_grammar_compatibility VALUES (275, 67, 9);
INSERT INTO public.word_grammar_compatibility VALUES (276, 67, 13);
INSERT INTO public.word_grammar_compatibility VALUES (277, 67, 10);
INSERT INTO public.word_grammar_compatibility VALUES (278, 68, 4);
INSERT INTO public.word_grammar_compatibility VALUES (279, 68, 1);
INSERT INTO public.word_grammar_compatibility VALUES (280, 68, 2);
INSERT INTO public.word_grammar_compatibility VALUES (281, 68, 3);
INSERT INTO public.word_grammar_compatibility VALUES (282, 68, 7);
INSERT INTO public.word_grammar_compatibility VALUES (283, 68, 5);
INSERT INTO public.word_grammar_compatibility VALUES (284, 68, 6);
INSERT INTO public.word_grammar_compatibility VALUES (285, 69, 12);
INSERT INTO public.word_grammar_compatibility VALUES (286, 69, 8);
INSERT INTO public.word_grammar_compatibility VALUES (287, 69, 9);
INSERT INTO public.word_grammar_compatibility VALUES (288, 69, 13);
INSERT INTO public.word_grammar_compatibility VALUES (289, 69, 10);
INSERT INTO public.word_grammar_compatibility VALUES (290, 70, 4);
INSERT INTO public.word_grammar_compatibility VALUES (291, 70, 1);
INSERT INTO public.word_grammar_compatibility VALUES (292, 70, 2);
INSERT INTO public.word_grammar_compatibility VALUES (293, 70, 3);
INSERT INTO public.word_grammar_compatibility VALUES (294, 70, 7);
INSERT INTO public.word_grammar_compatibility VALUES (295, 70, 5);
INSERT INTO public.word_grammar_compatibility VALUES (296, 70, 6);
INSERT INTO public.word_grammar_compatibility VALUES (297, 71, 12);
INSERT INTO public.word_grammar_compatibility VALUES (298, 71, 8);
INSERT INTO public.word_grammar_compatibility VALUES (299, 71, 9);
INSERT INTO public.word_grammar_compatibility VALUES (300, 71, 13);
INSERT INTO public.word_grammar_compatibility VALUES (301, 71, 10);
INSERT INTO public.word_grammar_compatibility VALUES (302, 72, 4);
INSERT INTO public.word_grammar_compatibility VALUES (303, 72, 1);
INSERT INTO public.word_grammar_compatibility VALUES (304, 72, 2);
INSERT INTO public.word_grammar_compatibility VALUES (305, 72, 3);
INSERT INTO public.word_grammar_compatibility VALUES (306, 72, 7);
INSERT INTO public.word_grammar_compatibility VALUES (307, 72, 5);
INSERT INTO public.word_grammar_compatibility VALUES (308, 72, 6);
INSERT INTO public.word_grammar_compatibility VALUES (309, 73, 12);
INSERT INTO public.word_grammar_compatibility VALUES (310, 73, 8);
INSERT INTO public.word_grammar_compatibility VALUES (311, 73, 9);
INSERT INTO public.word_grammar_compatibility VALUES (312, 73, 13);
INSERT INTO public.word_grammar_compatibility VALUES (313, 73, 10);
INSERT INTO public.word_grammar_compatibility VALUES (314, 74, 4);
INSERT INTO public.word_grammar_compatibility VALUES (315, 74, 1);
INSERT INTO public.word_grammar_compatibility VALUES (316, 74, 2);
INSERT INTO public.word_grammar_compatibility VALUES (317, 74, 3);
INSERT INTO public.word_grammar_compatibility VALUES (318, 74, 7);
INSERT INTO public.word_grammar_compatibility VALUES (319, 74, 5);
INSERT INTO public.word_grammar_compatibility VALUES (320, 74, 6);
INSERT INTO public.word_grammar_compatibility VALUES (321, 75, 12);
INSERT INTO public.word_grammar_compatibility VALUES (322, 75, 8);
INSERT INTO public.word_grammar_compatibility VALUES (323, 75, 9);
INSERT INTO public.word_grammar_compatibility VALUES (324, 75, 13);
INSERT INTO public.word_grammar_compatibility VALUES (325, 75, 10);
INSERT INTO public.word_grammar_compatibility VALUES (326, 76, 4);
INSERT INTO public.word_grammar_compatibility VALUES (327, 76, 1);
INSERT INTO public.word_grammar_compatibility VALUES (328, 76, 2);
INSERT INTO public.word_grammar_compatibility VALUES (329, 76, 3);
INSERT INTO public.word_grammar_compatibility VALUES (330, 76, 7);
INSERT INTO public.word_grammar_compatibility VALUES (331, 76, 5);
INSERT INTO public.word_grammar_compatibility VALUES (332, 76, 6);
INSERT INTO public.word_grammar_compatibility VALUES (333, 77, 12);
INSERT INTO public.word_grammar_compatibility VALUES (334, 77, 8);
INSERT INTO public.word_grammar_compatibility VALUES (335, 77, 9);
INSERT INTO public.word_grammar_compatibility VALUES (336, 77, 13);
INSERT INTO public.word_grammar_compatibility VALUES (337, 77, 10);
INSERT INTO public.word_grammar_compatibility VALUES (338, 78, 4);
INSERT INTO public.word_grammar_compatibility VALUES (339, 78, 1);
INSERT INTO public.word_grammar_compatibility VALUES (340, 78, 2);
INSERT INTO public.word_grammar_compatibility VALUES (341, 78, 3);
INSERT INTO public.word_grammar_compatibility VALUES (342, 78, 7);
INSERT INTO public.word_grammar_compatibility VALUES (343, 78, 5);
INSERT INTO public.word_grammar_compatibility VALUES (344, 78, 6);
INSERT INTO public.word_grammar_compatibility VALUES (345, 79, 12);
INSERT INTO public.word_grammar_compatibility VALUES (346, 79, 8);
INSERT INTO public.word_grammar_compatibility VALUES (347, 79, 9);
INSERT INTO public.word_grammar_compatibility VALUES (348, 79, 13);
INSERT INTO public.word_grammar_compatibility VALUES (349, 79, 10);
INSERT INTO public.word_grammar_compatibility VALUES (350, 80, 4);
INSERT INTO public.word_grammar_compatibility VALUES (351, 80, 1);
INSERT INTO public.word_grammar_compatibility VALUES (352, 80, 2);
INSERT INTO public.word_grammar_compatibility VALUES (353, 80, 3);
INSERT INTO public.word_grammar_compatibility VALUES (354, 80, 7);
INSERT INTO public.word_grammar_compatibility VALUES (355, 80, 5);
INSERT INTO public.word_grammar_compatibility VALUES (356, 80, 6);
INSERT INTO public.word_grammar_compatibility VALUES (357, 81, 12);
INSERT INTO public.word_grammar_compatibility VALUES (358, 81, 8);
INSERT INTO public.word_grammar_compatibility VALUES (359, 81, 9);
INSERT INTO public.word_grammar_compatibility VALUES (360, 81, 13);
INSERT INTO public.word_grammar_compatibility VALUES (361, 81, 10);
INSERT INTO public.word_grammar_compatibility VALUES (362, 82, 4);
INSERT INTO public.word_grammar_compatibility VALUES (363, 82, 1);
INSERT INTO public.word_grammar_compatibility VALUES (364, 82, 2);
INSERT INTO public.word_grammar_compatibility VALUES (365, 82, 3);
INSERT INTO public.word_grammar_compatibility VALUES (366, 82, 7);
INSERT INTO public.word_grammar_compatibility VALUES (367, 82, 5);
INSERT INTO public.word_grammar_compatibility VALUES (368, 82, 6);
INSERT INTO public.word_grammar_compatibility VALUES (369, 83, 12);
INSERT INTO public.word_grammar_compatibility VALUES (370, 83, 8);
INSERT INTO public.word_grammar_compatibility VALUES (371, 83, 9);
INSERT INTO public.word_grammar_compatibility VALUES (372, 83, 13);
INSERT INTO public.word_grammar_compatibility VALUES (373, 83, 10);
INSERT INTO public.word_grammar_compatibility VALUES (374, 84, 4);
INSERT INTO public.word_grammar_compatibility VALUES (375, 84, 1);
INSERT INTO public.word_grammar_compatibility VALUES (376, 84, 2);
INSERT INTO public.word_grammar_compatibility VALUES (377, 84, 3);
INSERT INTO public.word_grammar_compatibility VALUES (378, 84, 7);
INSERT INTO public.word_grammar_compatibility VALUES (379, 84, 5);
INSERT INTO public.word_grammar_compatibility VALUES (380, 84, 6);
INSERT INTO public.word_grammar_compatibility VALUES (381, 85, 12);
INSERT INTO public.word_grammar_compatibility VALUES (382, 85, 8);
INSERT INTO public.word_grammar_compatibility VALUES (383, 85, 9);
INSERT INTO public.word_grammar_compatibility VALUES (384, 85, 13);
INSERT INTO public.word_grammar_compatibility VALUES (385, 85, 10);
INSERT INTO public.word_grammar_compatibility VALUES (386, 86, 4);
INSERT INTO public.word_grammar_compatibility VALUES (387, 86, 1);
INSERT INTO public.word_grammar_compatibility VALUES (388, 86, 2);
INSERT INTO public.word_grammar_compatibility VALUES (389, 86, 3);
INSERT INTO public.word_grammar_compatibility VALUES (390, 86, 7);
INSERT INTO public.word_grammar_compatibility VALUES (391, 86, 5);
INSERT INTO public.word_grammar_compatibility VALUES (392, 86, 6);
INSERT INTO public.word_grammar_compatibility VALUES (393, 87, 12);
INSERT INTO public.word_grammar_compatibility VALUES (394, 87, 8);
INSERT INTO public.word_grammar_compatibility VALUES (395, 87, 9);
INSERT INTO public.word_grammar_compatibility VALUES (396, 87, 13);
INSERT INTO public.word_grammar_compatibility VALUES (397, 87, 10);
INSERT INTO public.word_grammar_compatibility VALUES (398, 88, 4);
INSERT INTO public.word_grammar_compatibility VALUES (399, 88, 1);
INSERT INTO public.word_grammar_compatibility VALUES (400, 88, 2);
INSERT INTO public.word_grammar_compatibility VALUES (401, 88, 3);
INSERT INTO public.word_grammar_compatibility VALUES (402, 88, 7);
INSERT INTO public.word_grammar_compatibility VALUES (403, 88, 5);
INSERT INTO public.word_grammar_compatibility VALUES (404, 88, 6);
INSERT INTO public.word_grammar_compatibility VALUES (405, 89, 12);
INSERT INTO public.word_grammar_compatibility VALUES (406, 89, 8);
INSERT INTO public.word_grammar_compatibility VALUES (407, 89, 9);
INSERT INTO public.word_grammar_compatibility VALUES (408, 89, 13);
INSERT INTO public.word_grammar_compatibility VALUES (409, 89, 10);
INSERT INTO public.word_grammar_compatibility VALUES (410, 90, 4);
INSERT INTO public.word_grammar_compatibility VALUES (411, 90, 1);
INSERT INTO public.word_grammar_compatibility VALUES (412, 90, 2);
INSERT INTO public.word_grammar_compatibility VALUES (413, 90, 3);
INSERT INTO public.word_grammar_compatibility VALUES (414, 90, 7);
INSERT INTO public.word_grammar_compatibility VALUES (415, 90, 5);
INSERT INTO public.word_grammar_compatibility VALUES (416, 90, 6);
INSERT INTO public.word_grammar_compatibility VALUES (417, 91, 12);
INSERT INTO public.word_grammar_compatibility VALUES (418, 91, 8);
INSERT INTO public.word_grammar_compatibility VALUES (419, 91, 9);
INSERT INTO public.word_grammar_compatibility VALUES (420, 91, 13);
INSERT INTO public.word_grammar_compatibility VALUES (421, 91, 10);
INSERT INTO public.word_grammar_compatibility VALUES (422, 92, 4);
INSERT INTO public.word_grammar_compatibility VALUES (423, 92, 1);
INSERT INTO public.word_grammar_compatibility VALUES (424, 92, 2);
INSERT INTO public.word_grammar_compatibility VALUES (425, 92, 3);
INSERT INTO public.word_grammar_compatibility VALUES (426, 92, 7);
INSERT INTO public.word_grammar_compatibility VALUES (427, 92, 5);
INSERT INTO public.word_grammar_compatibility VALUES (428, 92, 6);
INSERT INTO public.word_grammar_compatibility VALUES (429, 93, 12);
INSERT INTO public.word_grammar_compatibility VALUES (430, 93, 8);
INSERT INTO public.word_grammar_compatibility VALUES (431, 93, 9);
INSERT INTO public.word_grammar_compatibility VALUES (432, 93, 13);
INSERT INTO public.word_grammar_compatibility VALUES (433, 93, 10);
INSERT INTO public.word_grammar_compatibility VALUES (434, 94, 4);
INSERT INTO public.word_grammar_compatibility VALUES (435, 94, 1);
INSERT INTO public.word_grammar_compatibility VALUES (436, 94, 2);
INSERT INTO public.word_grammar_compatibility VALUES (437, 94, 3);
INSERT INTO public.word_grammar_compatibility VALUES (438, 94, 7);
INSERT INTO public.word_grammar_compatibility VALUES (439, 94, 5);
INSERT INTO public.word_grammar_compatibility VALUES (440, 94, 6);
INSERT INTO public.word_grammar_compatibility VALUES (441, 95, 12);
INSERT INTO public.word_grammar_compatibility VALUES (442, 95, 8);
INSERT INTO public.word_grammar_compatibility VALUES (443, 95, 9);
INSERT INTO public.word_grammar_compatibility VALUES (444, 95, 13);
INSERT INTO public.word_grammar_compatibility VALUES (445, 95, 10);
INSERT INTO public.word_grammar_compatibility VALUES (446, 96, 4);
INSERT INTO public.word_grammar_compatibility VALUES (447, 96, 1);
INSERT INTO public.word_grammar_compatibility VALUES (448, 96, 2);
INSERT INTO public.word_grammar_compatibility VALUES (449, 96, 3);
INSERT INTO public.word_grammar_compatibility VALUES (450, 96, 7);
INSERT INTO public.word_grammar_compatibility VALUES (451, 96, 5);
INSERT INTO public.word_grammar_compatibility VALUES (452, 96, 6);
INSERT INTO public.word_grammar_compatibility VALUES (453, 97, 12);
INSERT INTO public.word_grammar_compatibility VALUES (454, 97, 8);
INSERT INTO public.word_grammar_compatibility VALUES (455, 97, 9);
INSERT INTO public.word_grammar_compatibility VALUES (456, 97, 13);
INSERT INTO public.word_grammar_compatibility VALUES (457, 97, 10);
INSERT INTO public.word_grammar_compatibility VALUES (458, 98, 4);
INSERT INTO public.word_grammar_compatibility VALUES (459, 98, 1);
INSERT INTO public.word_grammar_compatibility VALUES (460, 98, 2);
INSERT INTO public.word_grammar_compatibility VALUES (461, 98, 3);
INSERT INTO public.word_grammar_compatibility VALUES (462, 98, 7);
INSERT INTO public.word_grammar_compatibility VALUES (463, 98, 5);
INSERT INTO public.word_grammar_compatibility VALUES (464, 98, 6);
INSERT INTO public.word_grammar_compatibility VALUES (465, 99, 12);
INSERT INTO public.word_grammar_compatibility VALUES (466, 99, 8);
INSERT INTO public.word_grammar_compatibility VALUES (467, 99, 9);
INSERT INTO public.word_grammar_compatibility VALUES (468, 99, 13);
INSERT INTO public.word_grammar_compatibility VALUES (469, 99, 10);
INSERT INTO public.word_grammar_compatibility VALUES (470, 100, 4);
INSERT INTO public.word_grammar_compatibility VALUES (471, 100, 1);
INSERT INTO public.word_grammar_compatibility VALUES (472, 100, 2);
INSERT INTO public.word_grammar_compatibility VALUES (473, 100, 3);
INSERT INTO public.word_grammar_compatibility VALUES (474, 100, 7);
INSERT INTO public.word_grammar_compatibility VALUES (475, 100, 5);
INSERT INTO public.word_grammar_compatibility VALUES (476, 100, 6);
INSERT INTO public.word_grammar_compatibility VALUES (477, 101, 12);
INSERT INTO public.word_grammar_compatibility VALUES (478, 101, 8);
INSERT INTO public.word_grammar_compatibility VALUES (479, 101, 9);
INSERT INTO public.word_grammar_compatibility VALUES (480, 101, 13);
INSERT INTO public.word_grammar_compatibility VALUES (481, 101, 10);
INSERT INTO public.word_grammar_compatibility VALUES (482, 102, 4);
INSERT INTO public.word_grammar_compatibility VALUES (483, 102, 1);
INSERT INTO public.word_grammar_compatibility VALUES (484, 102, 2);
INSERT INTO public.word_grammar_compatibility VALUES (485, 102, 3);
INSERT INTO public.word_grammar_compatibility VALUES (486, 102, 7);
INSERT INTO public.word_grammar_compatibility VALUES (487, 102, 5);
INSERT INTO public.word_grammar_compatibility VALUES (488, 102, 6);
INSERT INTO public.word_grammar_compatibility VALUES (489, 103, 12);
INSERT INTO public.word_grammar_compatibility VALUES (490, 103, 8);
INSERT INTO public.word_grammar_compatibility VALUES (491, 103, 9);
INSERT INTO public.word_grammar_compatibility VALUES (492, 103, 13);
INSERT INTO public.word_grammar_compatibility VALUES (493, 103, 10);
INSERT INTO public.word_grammar_compatibility VALUES (494, 104, 4);
INSERT INTO public.word_grammar_compatibility VALUES (495, 104, 1);
INSERT INTO public.word_grammar_compatibility VALUES (496, 104, 2);
INSERT INTO public.word_grammar_compatibility VALUES (497, 104, 3);
INSERT INTO public.word_grammar_compatibility VALUES (498, 104, 7);
INSERT INTO public.word_grammar_compatibility VALUES (499, 104, 5);
INSERT INTO public.word_grammar_compatibility VALUES (500, 104, 6);
INSERT INTO public.word_grammar_compatibility VALUES (501, 105, 12);
INSERT INTO public.word_grammar_compatibility VALUES (502, 105, 8);
INSERT INTO public.word_grammar_compatibility VALUES (503, 105, 9);
INSERT INTO public.word_grammar_compatibility VALUES (504, 105, 13);
INSERT INTO public.word_grammar_compatibility VALUES (505, 105, 10);
INSERT INTO public.word_grammar_compatibility VALUES (506, 106, 4);
INSERT INTO public.word_grammar_compatibility VALUES (507, 106, 1);
INSERT INTO public.word_grammar_compatibility VALUES (508, 106, 2);
INSERT INTO public.word_grammar_compatibility VALUES (509, 106, 3);
INSERT INTO public.word_grammar_compatibility VALUES (510, 106, 7);
INSERT INTO public.word_grammar_compatibility VALUES (511, 106, 5);
INSERT INTO public.word_grammar_compatibility VALUES (512, 106, 6);
INSERT INTO public.word_grammar_compatibility VALUES (513, 107, 12);
INSERT INTO public.word_grammar_compatibility VALUES (514, 107, 8);
INSERT INTO public.word_grammar_compatibility VALUES (515, 107, 9);
INSERT INTO public.word_grammar_compatibility VALUES (516, 107, 13);
INSERT INTO public.word_grammar_compatibility VALUES (517, 107, 10);
INSERT INTO public.word_grammar_compatibility VALUES (518, 108, 4);
INSERT INTO public.word_grammar_compatibility VALUES (519, 108, 1);
INSERT INTO public.word_grammar_compatibility VALUES (520, 108, 2);
INSERT INTO public.word_grammar_compatibility VALUES (521, 108, 3);
INSERT INTO public.word_grammar_compatibility VALUES (522, 108, 7);
INSERT INTO public.word_grammar_compatibility VALUES (523, 108, 5);
INSERT INTO public.word_grammar_compatibility VALUES (524, 108, 6);
INSERT INTO public.word_grammar_compatibility VALUES (525, 109, 12);
INSERT INTO public.word_grammar_compatibility VALUES (526, 109, 8);
INSERT INTO public.word_grammar_compatibility VALUES (527, 109, 9);
INSERT INTO public.word_grammar_compatibility VALUES (528, 109, 13);
INSERT INTO public.word_grammar_compatibility VALUES (529, 109, 10);
INSERT INTO public.word_grammar_compatibility VALUES (530, 110, 4);
INSERT INTO public.word_grammar_compatibility VALUES (531, 110, 1);
INSERT INTO public.word_grammar_compatibility VALUES (532, 110, 2);
INSERT INTO public.word_grammar_compatibility VALUES (533, 110, 3);
INSERT INTO public.word_grammar_compatibility VALUES (534, 110, 7);
INSERT INTO public.word_grammar_compatibility VALUES (535, 110, 5);
INSERT INTO public.word_grammar_compatibility VALUES (536, 110, 6);
INSERT INTO public.word_grammar_compatibility VALUES (537, 111, 12);
INSERT INTO public.word_grammar_compatibility VALUES (538, 111, 8);
INSERT INTO public.word_grammar_compatibility VALUES (539, 111, 9);
INSERT INTO public.word_grammar_compatibility VALUES (540, 111, 13);
INSERT INTO public.word_grammar_compatibility VALUES (541, 111, 10);
INSERT INTO public.word_grammar_compatibility VALUES (542, 112, 4);
INSERT INTO public.word_grammar_compatibility VALUES (543, 112, 1);
INSERT INTO public.word_grammar_compatibility VALUES (544, 112, 2);
INSERT INTO public.word_grammar_compatibility VALUES (545, 112, 3);
INSERT INTO public.word_grammar_compatibility VALUES (546, 112, 7);
INSERT INTO public.word_grammar_compatibility VALUES (547, 112, 5);
INSERT INTO public.word_grammar_compatibility VALUES (548, 112, 6);
INSERT INTO public.word_grammar_compatibility VALUES (549, 113, 12);
INSERT INTO public.word_grammar_compatibility VALUES (550, 113, 8);
INSERT INTO public.word_grammar_compatibility VALUES (551, 113, 9);
INSERT INTO public.word_grammar_compatibility VALUES (552, 113, 13);
INSERT INTO public.word_grammar_compatibility VALUES (553, 113, 10);
INSERT INTO public.word_grammar_compatibility VALUES (554, 114, 4);
INSERT INTO public.word_grammar_compatibility VALUES (555, 114, 1);
INSERT INTO public.word_grammar_compatibility VALUES (556, 114, 2);
INSERT INTO public.word_grammar_compatibility VALUES (557, 114, 3);
INSERT INTO public.word_grammar_compatibility VALUES (558, 114, 7);
INSERT INTO public.word_grammar_compatibility VALUES (559, 114, 5);
INSERT INTO public.word_grammar_compatibility VALUES (560, 114, 6);
INSERT INTO public.word_grammar_compatibility VALUES (561, 115, 12);
INSERT INTO public.word_grammar_compatibility VALUES (562, 115, 8);
INSERT INTO public.word_grammar_compatibility VALUES (563, 115, 9);
INSERT INTO public.word_grammar_compatibility VALUES (564, 115, 13);
INSERT INTO public.word_grammar_compatibility VALUES (565, 115, 10);
INSERT INTO public.word_grammar_compatibility VALUES (566, 116, 4);
INSERT INTO public.word_grammar_compatibility VALUES (567, 116, 1);
INSERT INTO public.word_grammar_compatibility VALUES (568, 116, 2);
INSERT INTO public.word_grammar_compatibility VALUES (569, 116, 3);
INSERT INTO public.word_grammar_compatibility VALUES (570, 116, 7);
INSERT INTO public.word_grammar_compatibility VALUES (571, 116, 5);
INSERT INTO public.word_grammar_compatibility VALUES (572, 116, 6);
INSERT INTO public.word_grammar_compatibility VALUES (573, 117, 12);
INSERT INTO public.word_grammar_compatibility VALUES (574, 117, 8);
INSERT INTO public.word_grammar_compatibility VALUES (575, 117, 9);
INSERT INTO public.word_grammar_compatibility VALUES (576, 117, 13);
INSERT INTO public.word_grammar_compatibility VALUES (577, 117, 10);
INSERT INTO public.word_grammar_compatibility VALUES (578, 118, 4);
INSERT INTO public.word_grammar_compatibility VALUES (579, 118, 1);
INSERT INTO public.word_grammar_compatibility VALUES (580, 118, 2);
INSERT INTO public.word_grammar_compatibility VALUES (581, 118, 3);
INSERT INTO public.word_grammar_compatibility VALUES (582, 118, 7);
INSERT INTO public.word_grammar_compatibility VALUES (583, 118, 5);
INSERT INTO public.word_grammar_compatibility VALUES (584, 118, 6);
INSERT INTO public.word_grammar_compatibility VALUES (585, 119, 12);
INSERT INTO public.word_grammar_compatibility VALUES (586, 119, 8);
INSERT INTO public.word_grammar_compatibility VALUES (587, 119, 9);
INSERT INTO public.word_grammar_compatibility VALUES (588, 119, 13);
INSERT INTO public.word_grammar_compatibility VALUES (589, 119, 10);
INSERT INTO public.word_grammar_compatibility VALUES (590, 120, 4);
INSERT INTO public.word_grammar_compatibility VALUES (591, 120, 1);
INSERT INTO public.word_grammar_compatibility VALUES (592, 120, 2);
INSERT INTO public.word_grammar_compatibility VALUES (593, 120, 3);
INSERT INTO public.word_grammar_compatibility VALUES (594, 120, 7);
INSERT INTO public.word_grammar_compatibility VALUES (595, 120, 5);
INSERT INTO public.word_grammar_compatibility VALUES (596, 120, 6);
INSERT INTO public.word_grammar_compatibility VALUES (597, 121, 12);
INSERT INTO public.word_grammar_compatibility VALUES (598, 121, 8);
INSERT INTO public.word_grammar_compatibility VALUES (599, 121, 9);
INSERT INTO public.word_grammar_compatibility VALUES (600, 121, 13);
INSERT INTO public.word_grammar_compatibility VALUES (601, 121, 10);
INSERT INTO public.word_grammar_compatibility VALUES (602, 122, 4);
INSERT INTO public.word_grammar_compatibility VALUES (603, 122, 1);
INSERT INTO public.word_grammar_compatibility VALUES (604, 122, 2);
INSERT INTO public.word_grammar_compatibility VALUES (605, 122, 3);
INSERT INTO public.word_grammar_compatibility VALUES (606, 122, 7);
INSERT INTO public.word_grammar_compatibility VALUES (607, 122, 5);
INSERT INTO public.word_grammar_compatibility VALUES (608, 122, 6);
INSERT INTO public.word_grammar_compatibility VALUES (609, 123, 12);
INSERT INTO public.word_grammar_compatibility VALUES (610, 123, 8);
INSERT INTO public.word_grammar_compatibility VALUES (611, 123, 9);
INSERT INTO public.word_grammar_compatibility VALUES (612, 123, 13);
INSERT INTO public.word_grammar_compatibility VALUES (613, 123, 10);
INSERT INTO public.word_grammar_compatibility VALUES (614, 124, 4);
INSERT INTO public.word_grammar_compatibility VALUES (615, 124, 1);
INSERT INTO public.word_grammar_compatibility VALUES (616, 124, 2);
INSERT INTO public.word_grammar_compatibility VALUES (617, 124, 3);
INSERT INTO public.word_grammar_compatibility VALUES (618, 124, 7);
INSERT INTO public.word_grammar_compatibility VALUES (619, 124, 5);
INSERT INTO public.word_grammar_compatibility VALUES (620, 124, 6);
INSERT INTO public.word_grammar_compatibility VALUES (621, 125, 12);
INSERT INTO public.word_grammar_compatibility VALUES (622, 125, 8);
INSERT INTO public.word_grammar_compatibility VALUES (623, 125, 9);
INSERT INTO public.word_grammar_compatibility VALUES (624, 125, 13);
INSERT INTO public.word_grammar_compatibility VALUES (625, 125, 10);
INSERT INTO public.word_grammar_compatibility VALUES (626, 126, 4);
INSERT INTO public.word_grammar_compatibility VALUES (627, 126, 1);
INSERT INTO public.word_grammar_compatibility VALUES (628, 126, 2);
INSERT INTO public.word_grammar_compatibility VALUES (629, 126, 3);
INSERT INTO public.word_grammar_compatibility VALUES (630, 126, 7);
INSERT INTO public.word_grammar_compatibility VALUES (631, 126, 5);
INSERT INTO public.word_grammar_compatibility VALUES (632, 126, 6);
INSERT INTO public.word_grammar_compatibility VALUES (633, 127, 12);
INSERT INTO public.word_grammar_compatibility VALUES (634, 127, 8);
INSERT INTO public.word_grammar_compatibility VALUES (635, 127, 9);
INSERT INTO public.word_grammar_compatibility VALUES (636, 127, 13);
INSERT INTO public.word_grammar_compatibility VALUES (637, 127, 10);
INSERT INTO public.word_grammar_compatibility VALUES (638, 128, 4);
INSERT INTO public.word_grammar_compatibility VALUES (639, 128, 1);
INSERT INTO public.word_grammar_compatibility VALUES (640, 128, 2);
INSERT INTO public.word_grammar_compatibility VALUES (641, 128, 3);
INSERT INTO public.word_grammar_compatibility VALUES (642, 128, 7);
INSERT INTO public.word_grammar_compatibility VALUES (643, 128, 5);
INSERT INTO public.word_grammar_compatibility VALUES (644, 128, 6);
INSERT INTO public.word_grammar_compatibility VALUES (645, 129, 12);
INSERT INTO public.word_grammar_compatibility VALUES (646, 129, 8);
INSERT INTO public.word_grammar_compatibility VALUES (647, 129, 9);
INSERT INTO public.word_grammar_compatibility VALUES (648, 129, 13);
INSERT INTO public.word_grammar_compatibility VALUES (649, 129, 10);
INSERT INTO public.word_grammar_compatibility VALUES (650, 130, 4);
INSERT INTO public.word_grammar_compatibility VALUES (651, 130, 1);
INSERT INTO public.word_grammar_compatibility VALUES (652, 130, 2);
INSERT INTO public.word_grammar_compatibility VALUES (653, 130, 3);
INSERT INTO public.word_grammar_compatibility VALUES (654, 130, 7);
INSERT INTO public.word_grammar_compatibility VALUES (655, 130, 5);
INSERT INTO public.word_grammar_compatibility VALUES (656, 130, 6);
INSERT INTO public.word_grammar_compatibility VALUES (657, 131, 12);
INSERT INTO public.word_grammar_compatibility VALUES (658, 131, 8);
INSERT INTO public.word_grammar_compatibility VALUES (659, 131, 9);
INSERT INTO public.word_grammar_compatibility VALUES (660, 131, 13);
INSERT INTO public.word_grammar_compatibility VALUES (661, 131, 10);
INSERT INTO public.word_grammar_compatibility VALUES (662, 132, 4);
INSERT INTO public.word_grammar_compatibility VALUES (663, 132, 1);
INSERT INTO public.word_grammar_compatibility VALUES (664, 132, 2);
INSERT INTO public.word_grammar_compatibility VALUES (665, 132, 3);
INSERT INTO public.word_grammar_compatibility VALUES (666, 132, 7);
INSERT INTO public.word_grammar_compatibility VALUES (667, 132, 5);
INSERT INTO public.word_grammar_compatibility VALUES (668, 132, 6);
INSERT INTO public.word_grammar_compatibility VALUES (669, 133, 12);
INSERT INTO public.word_grammar_compatibility VALUES (670, 133, 8);
INSERT INTO public.word_grammar_compatibility VALUES (671, 133, 9);
INSERT INTO public.word_grammar_compatibility VALUES (672, 133, 13);
INSERT INTO public.word_grammar_compatibility VALUES (673, 133, 10);
INSERT INTO public.word_grammar_compatibility VALUES (674, 134, 4);
INSERT INTO public.word_grammar_compatibility VALUES (675, 134, 1);
INSERT INTO public.word_grammar_compatibility VALUES (676, 134, 2);
INSERT INTO public.word_grammar_compatibility VALUES (677, 134, 3);
INSERT INTO public.word_grammar_compatibility VALUES (678, 134, 7);
INSERT INTO public.word_grammar_compatibility VALUES (679, 134, 5);
INSERT INTO public.word_grammar_compatibility VALUES (680, 134, 6);
INSERT INTO public.word_grammar_compatibility VALUES (681, 135, 12);
INSERT INTO public.word_grammar_compatibility VALUES (682, 135, 8);
INSERT INTO public.word_grammar_compatibility VALUES (683, 135, 9);
INSERT INTO public.word_grammar_compatibility VALUES (684, 135, 13);
INSERT INTO public.word_grammar_compatibility VALUES (685, 135, 10);
INSERT INTO public.word_grammar_compatibility VALUES (686, 136, 4);
INSERT INTO public.word_grammar_compatibility VALUES (687, 136, 1);
INSERT INTO public.word_grammar_compatibility VALUES (688, 136, 2);
INSERT INTO public.word_grammar_compatibility VALUES (689, 136, 3);
INSERT INTO public.word_grammar_compatibility VALUES (690, 136, 7);
INSERT INTO public.word_grammar_compatibility VALUES (691, 136, 5);
INSERT INTO public.word_grammar_compatibility VALUES (692, 136, 6);
INSERT INTO public.word_grammar_compatibility VALUES (693, 137, 12);
INSERT INTO public.word_grammar_compatibility VALUES (694, 137, 8);
INSERT INTO public.word_grammar_compatibility VALUES (695, 137, 9);
INSERT INTO public.word_grammar_compatibility VALUES (696, 137, 13);
INSERT INTO public.word_grammar_compatibility VALUES (697, 137, 10);
INSERT INTO public.word_grammar_compatibility VALUES (698, 138, 4);
INSERT INTO public.word_grammar_compatibility VALUES (699, 138, 1);
INSERT INTO public.word_grammar_compatibility VALUES (700, 138, 2);
INSERT INTO public.word_grammar_compatibility VALUES (701, 138, 3);
INSERT INTO public.word_grammar_compatibility VALUES (702, 138, 7);
INSERT INTO public.word_grammar_compatibility VALUES (703, 138, 5);
INSERT INTO public.word_grammar_compatibility VALUES (704, 138, 6);
INSERT INTO public.word_grammar_compatibility VALUES (705, 139, 12);
INSERT INTO public.word_grammar_compatibility VALUES (706, 139, 8);
INSERT INTO public.word_grammar_compatibility VALUES (707, 139, 9);
INSERT INTO public.word_grammar_compatibility VALUES (708, 139, 13);
INSERT INTO public.word_grammar_compatibility VALUES (709, 139, 10);
INSERT INTO public.word_grammar_compatibility VALUES (710, 140, 4);
INSERT INTO public.word_grammar_compatibility VALUES (711, 140, 1);
INSERT INTO public.word_grammar_compatibility VALUES (712, 140, 2);
INSERT INTO public.word_grammar_compatibility VALUES (713, 140, 3);
INSERT INTO public.word_grammar_compatibility VALUES (714, 140, 7);
INSERT INTO public.word_grammar_compatibility VALUES (715, 140, 5);
INSERT INTO public.word_grammar_compatibility VALUES (716, 140, 6);
INSERT INTO public.word_grammar_compatibility VALUES (717, 141, 12);
INSERT INTO public.word_grammar_compatibility VALUES (718, 141, 8);
INSERT INTO public.word_grammar_compatibility VALUES (719, 141, 9);
INSERT INTO public.word_grammar_compatibility VALUES (720, 141, 13);
INSERT INTO public.word_grammar_compatibility VALUES (721, 141, 10);
INSERT INTO public.word_grammar_compatibility VALUES (722, 142, 4);
INSERT INTO public.word_grammar_compatibility VALUES (723, 142, 1);
INSERT INTO public.word_grammar_compatibility VALUES (724, 142, 2);
INSERT INTO public.word_grammar_compatibility VALUES (725, 142, 3);
INSERT INTO public.word_grammar_compatibility VALUES (726, 142, 7);
INSERT INTO public.word_grammar_compatibility VALUES (727, 142, 5);
INSERT INTO public.word_grammar_compatibility VALUES (728, 142, 6);
INSERT INTO public.word_grammar_compatibility VALUES (729, 143, 12);
INSERT INTO public.word_grammar_compatibility VALUES (730, 143, 8);
INSERT INTO public.word_grammar_compatibility VALUES (731, 143, 9);
INSERT INTO public.word_grammar_compatibility VALUES (732, 143, 13);
INSERT INTO public.word_grammar_compatibility VALUES (733, 143, 10);
INSERT INTO public.word_grammar_compatibility VALUES (734, 144, 4);
INSERT INTO public.word_grammar_compatibility VALUES (735, 144, 1);
INSERT INTO public.word_grammar_compatibility VALUES (736, 144, 2);
INSERT INTO public.word_grammar_compatibility VALUES (737, 144, 3);
INSERT INTO public.word_grammar_compatibility VALUES (738, 145, 7);
INSERT INTO public.word_grammar_compatibility VALUES (739, 145, 5);
INSERT INTO public.word_grammar_compatibility VALUES (740, 145, 6);
INSERT INTO public.word_grammar_compatibility VALUES (741, 146, 12);
INSERT INTO public.word_grammar_compatibility VALUES (742, 146, 8);
INSERT INTO public.word_grammar_compatibility VALUES (743, 146, 9);
INSERT INTO public.word_grammar_compatibility VALUES (744, 147, 13);
INSERT INTO public.word_grammar_compatibility VALUES (745, 147, 10);
INSERT INTO public.word_grammar_compatibility VALUES (746, 148, 4);
INSERT INTO public.word_grammar_compatibility VALUES (747, 148, 1);
INSERT INTO public.word_grammar_compatibility VALUES (748, 148, 2);
INSERT INTO public.word_grammar_compatibility VALUES (749, 148, 3);
INSERT INTO public.word_grammar_compatibility VALUES (750, 149, 7);
INSERT INTO public.word_grammar_compatibility VALUES (751, 149, 5);
INSERT INTO public.word_grammar_compatibility VALUES (752, 149, 6);
INSERT INTO public.word_grammar_compatibility VALUES (753, 150, 12);
INSERT INTO public.word_grammar_compatibility VALUES (754, 150, 8);
INSERT INTO public.word_grammar_compatibility VALUES (755, 150, 9);
INSERT INTO public.word_grammar_compatibility VALUES (756, 151, 13);
INSERT INTO public.word_grammar_compatibility VALUES (757, 151, 10);
INSERT INTO public.word_grammar_compatibility VALUES (758, 152, 4);
INSERT INTO public.word_grammar_compatibility VALUES (759, 152, 1);
INSERT INTO public.word_grammar_compatibility VALUES (760, 152, 2);
INSERT INTO public.word_grammar_compatibility VALUES (761, 152, 3);
INSERT INTO public.word_grammar_compatibility VALUES (762, 153, 7);
INSERT INTO public.word_grammar_compatibility VALUES (763, 153, 5);
INSERT INTO public.word_grammar_compatibility VALUES (764, 153, 6);
INSERT INTO public.word_grammar_compatibility VALUES (765, 154, 12);
INSERT INTO public.word_grammar_compatibility VALUES (766, 154, 8);
INSERT INTO public.word_grammar_compatibility VALUES (767, 154, 9);
INSERT INTO public.word_grammar_compatibility VALUES (768, 155, 13);
INSERT INTO public.word_grammar_compatibility VALUES (769, 155, 10);
INSERT INTO public.word_grammar_compatibility VALUES (770, 156, 4);
INSERT INTO public.word_grammar_compatibility VALUES (771, 156, 1);
INSERT INTO public.word_grammar_compatibility VALUES (772, 156, 2);
INSERT INTO public.word_grammar_compatibility VALUES (773, 156, 3);
INSERT INTO public.word_grammar_compatibility VALUES (774, 157, 7);
INSERT INTO public.word_grammar_compatibility VALUES (775, 157, 5);
INSERT INTO public.word_grammar_compatibility VALUES (776, 157, 6);
INSERT INTO public.word_grammar_compatibility VALUES (777, 158, 12);
INSERT INTO public.word_grammar_compatibility VALUES (778, 158, 8);
INSERT INTO public.word_grammar_compatibility VALUES (779, 158, 9);
INSERT INTO public.word_grammar_compatibility VALUES (780, 159, 13);
INSERT INTO public.word_grammar_compatibility VALUES (781, 159, 10);
INSERT INTO public.word_grammar_compatibility VALUES (782, 160, 4);
INSERT INTO public.word_grammar_compatibility VALUES (783, 160, 1);
INSERT INTO public.word_grammar_compatibility VALUES (784, 160, 2);
INSERT INTO public.word_grammar_compatibility VALUES (785, 160, 3);
INSERT INTO public.word_grammar_compatibility VALUES (786, 161, 7);
INSERT INTO public.word_grammar_compatibility VALUES (787, 161, 5);
INSERT INTO public.word_grammar_compatibility VALUES (788, 161, 6);
INSERT INTO public.word_grammar_compatibility VALUES (789, 162, 12);
INSERT INTO public.word_grammar_compatibility VALUES (790, 162, 8);
INSERT INTO public.word_grammar_compatibility VALUES (791, 162, 9);
INSERT INTO public.word_grammar_compatibility VALUES (792, 163, 13);
INSERT INTO public.word_grammar_compatibility VALUES (793, 163, 10);
INSERT INTO public.word_grammar_compatibility VALUES (794, 164, 4);
INSERT INTO public.word_grammar_compatibility VALUES (795, 164, 1);
INSERT INTO public.word_grammar_compatibility VALUES (796, 164, 2);
INSERT INTO public.word_grammar_compatibility VALUES (797, 164, 3);
INSERT INTO public.word_grammar_compatibility VALUES (798, 165, 7);
INSERT INTO public.word_grammar_compatibility VALUES (799, 165, 5);
INSERT INTO public.word_grammar_compatibility VALUES (800, 165, 6);
INSERT INTO public.word_grammar_compatibility VALUES (801, 166, 12);
INSERT INTO public.word_grammar_compatibility VALUES (802, 166, 8);
INSERT INTO public.word_grammar_compatibility VALUES (803, 166, 9);
INSERT INTO public.word_grammar_compatibility VALUES (804, 167, 13);
INSERT INTO public.word_grammar_compatibility VALUES (805, 167, 10);
INSERT INTO public.word_grammar_compatibility VALUES (806, 168, 4);
INSERT INTO public.word_grammar_compatibility VALUES (807, 168, 1);
INSERT INTO public.word_grammar_compatibility VALUES (808, 168, 2);
INSERT INTO public.word_grammar_compatibility VALUES (809, 168, 3);
INSERT INTO public.word_grammar_compatibility VALUES (810, 169, 7);
INSERT INTO public.word_grammar_compatibility VALUES (811, 169, 5);
INSERT INTO public.word_grammar_compatibility VALUES (812, 169, 6);
INSERT INTO public.word_grammar_compatibility VALUES (813, 170, 12);
INSERT INTO public.word_grammar_compatibility VALUES (814, 170, 8);
INSERT INTO public.word_grammar_compatibility VALUES (815, 170, 9);
INSERT INTO public.word_grammar_compatibility VALUES (816, 171, 13);
INSERT INTO public.word_grammar_compatibility VALUES (817, 171, 10);
INSERT INTO public.word_grammar_compatibility VALUES (818, 172, 4);
INSERT INTO public.word_grammar_compatibility VALUES (819, 172, 1);
INSERT INTO public.word_grammar_compatibility VALUES (820, 172, 2);
INSERT INTO public.word_grammar_compatibility VALUES (821, 172, 3);
INSERT INTO public.word_grammar_compatibility VALUES (822, 173, 7);
INSERT INTO public.word_grammar_compatibility VALUES (823, 173, 5);
INSERT INTO public.word_grammar_compatibility VALUES (824, 173, 6);
INSERT INTO public.word_grammar_compatibility VALUES (825, 174, 12);
INSERT INTO public.word_grammar_compatibility VALUES (826, 174, 8);
INSERT INTO public.word_grammar_compatibility VALUES (827, 174, 9);
INSERT INTO public.word_grammar_compatibility VALUES (828, 175, 13);
INSERT INTO public.word_grammar_compatibility VALUES (829, 175, 10);
INSERT INTO public.word_grammar_compatibility VALUES (830, 176, 4);
INSERT INTO public.word_grammar_compatibility VALUES (831, 176, 1);
INSERT INTO public.word_grammar_compatibility VALUES (832, 176, 2);
INSERT INTO public.word_grammar_compatibility VALUES (833, 176, 3);
INSERT INTO public.word_grammar_compatibility VALUES (834, 177, 7);
INSERT INTO public.word_grammar_compatibility VALUES (835, 177, 5);
INSERT INTO public.word_grammar_compatibility VALUES (836, 177, 6);
INSERT INTO public.word_grammar_compatibility VALUES (837, 178, 12);
INSERT INTO public.word_grammar_compatibility VALUES (838, 178, 8);
INSERT INTO public.word_grammar_compatibility VALUES (839, 178, 9);
INSERT INTO public.word_grammar_compatibility VALUES (840, 179, 13);
INSERT INTO public.word_grammar_compatibility VALUES (841, 179, 10);
INSERT INTO public.word_grammar_compatibility VALUES (842, 180, 4);
INSERT INTO public.word_grammar_compatibility VALUES (843, 180, 1);
INSERT INTO public.word_grammar_compatibility VALUES (844, 180, 2);
INSERT INTO public.word_grammar_compatibility VALUES (845, 180, 3);
INSERT INTO public.word_grammar_compatibility VALUES (846, 181, 7);
INSERT INTO public.word_grammar_compatibility VALUES (847, 181, 5);
INSERT INTO public.word_grammar_compatibility VALUES (848, 181, 6);
INSERT INTO public.word_grammar_compatibility VALUES (849, 182, 12);
INSERT INTO public.word_grammar_compatibility VALUES (850, 182, 8);
INSERT INTO public.word_grammar_compatibility VALUES (851, 182, 9);
INSERT INTO public.word_grammar_compatibility VALUES (852, 183, 13);
INSERT INTO public.word_grammar_compatibility VALUES (853, 183, 10);
INSERT INTO public.word_grammar_compatibility VALUES (854, 184, 4);
INSERT INTO public.word_grammar_compatibility VALUES (855, 184, 1);
INSERT INTO public.word_grammar_compatibility VALUES (856, 184, 2);
INSERT INTO public.word_grammar_compatibility VALUES (857, 184, 3);
INSERT INTO public.word_grammar_compatibility VALUES (858, 185, 7);
INSERT INTO public.word_grammar_compatibility VALUES (859, 185, 5);
INSERT INTO public.word_grammar_compatibility VALUES (860, 185, 6);
INSERT INTO public.word_grammar_compatibility VALUES (861, 186, 12);
INSERT INTO public.word_grammar_compatibility VALUES (862, 186, 8);
INSERT INTO public.word_grammar_compatibility VALUES (863, 186, 9);
INSERT INTO public.word_grammar_compatibility VALUES (864, 187, 13);
INSERT INTO public.word_grammar_compatibility VALUES (865, 187, 10);
INSERT INTO public.word_grammar_compatibility VALUES (866, 188, 4);
INSERT INTO public.word_grammar_compatibility VALUES (867, 188, 1);
INSERT INTO public.word_grammar_compatibility VALUES (868, 188, 2);
INSERT INTO public.word_grammar_compatibility VALUES (869, 188, 3);
INSERT INTO public.word_grammar_compatibility VALUES (870, 189, 7);
INSERT INTO public.word_grammar_compatibility VALUES (871, 189, 5);
INSERT INTO public.word_grammar_compatibility VALUES (872, 189, 6);
INSERT INTO public.word_grammar_compatibility VALUES (873, 190, 12);
INSERT INTO public.word_grammar_compatibility VALUES (874, 190, 8);
INSERT INTO public.word_grammar_compatibility VALUES (875, 190, 9);
INSERT INTO public.word_grammar_compatibility VALUES (876, 191, 13);
INSERT INTO public.word_grammar_compatibility VALUES (877, 191, 10);
INSERT INTO public.word_grammar_compatibility VALUES (878, 192, 4);
INSERT INTO public.word_grammar_compatibility VALUES (879, 192, 1);
INSERT INTO public.word_grammar_compatibility VALUES (880, 192, 2);
INSERT INTO public.word_grammar_compatibility VALUES (881, 192, 3);
INSERT INTO public.word_grammar_compatibility VALUES (882, 193, 7);
INSERT INTO public.word_grammar_compatibility VALUES (883, 193, 5);
INSERT INTO public.word_grammar_compatibility VALUES (884, 193, 6);
INSERT INTO public.word_grammar_compatibility VALUES (885, 194, 12);
INSERT INTO public.word_grammar_compatibility VALUES (886, 194, 8);
INSERT INTO public.word_grammar_compatibility VALUES (887, 194, 9);
INSERT INTO public.word_grammar_compatibility VALUES (888, 195, 13);
INSERT INTO public.word_grammar_compatibility VALUES (889, 195, 10);
INSERT INTO public.word_grammar_compatibility VALUES (890, 196, 7);
INSERT INTO public.word_grammar_compatibility VALUES (891, 196, 5);
INSERT INTO public.word_grammar_compatibility VALUES (892, 196, 6);
INSERT INTO public.word_grammar_compatibility VALUES (893, 197, 13);
INSERT INTO public.word_grammar_compatibility VALUES (894, 197, 10);
INSERT INTO public.word_grammar_compatibility VALUES (895, 198, 7);
INSERT INTO public.word_grammar_compatibility VALUES (896, 198, 5);
INSERT INTO public.word_grammar_compatibility VALUES (897, 198, 6);
INSERT INTO public.word_grammar_compatibility VALUES (898, 199, 13);
INSERT INTO public.word_grammar_compatibility VALUES (899, 199, 10);
INSERT INTO public.word_grammar_compatibility VALUES (900, 200, 7);
INSERT INTO public.word_grammar_compatibility VALUES (901, 200, 5);
INSERT INTO public.word_grammar_compatibility VALUES (902, 200, 6);
INSERT INTO public.word_grammar_compatibility VALUES (903, 201, 13);
INSERT INTO public.word_grammar_compatibility VALUES (904, 201, 10);
INSERT INTO public.word_grammar_compatibility VALUES (905, 202, 7);
INSERT INTO public.word_grammar_compatibility VALUES (906, 202, 5);
INSERT INTO public.word_grammar_compatibility VALUES (907, 202, 6);
INSERT INTO public.word_grammar_compatibility VALUES (908, 203, 13);
INSERT INTO public.word_grammar_compatibility VALUES (909, 203, 10);
INSERT INTO public.word_grammar_compatibility VALUES (910, 204, 7);
INSERT INTO public.word_grammar_compatibility VALUES (911, 204, 5);
INSERT INTO public.word_grammar_compatibility VALUES (912, 204, 6);
INSERT INTO public.word_grammar_compatibility VALUES (913, 205, 13);
INSERT INTO public.word_grammar_compatibility VALUES (914, 205, 10);
INSERT INTO public.word_grammar_compatibility VALUES (915, 206, 7);
INSERT INTO public.word_grammar_compatibility VALUES (916, 206, 5);
INSERT INTO public.word_grammar_compatibility VALUES (917, 206, 6);
INSERT INTO public.word_grammar_compatibility VALUES (918, 207, 13);
INSERT INTO public.word_grammar_compatibility VALUES (919, 207, 10);
INSERT INTO public.word_grammar_compatibility VALUES (920, 208, 7);
INSERT INTO public.word_grammar_compatibility VALUES (921, 208, 5);
INSERT INTO public.word_grammar_compatibility VALUES (922, 208, 6);
INSERT INTO public.word_grammar_compatibility VALUES (923, 209, 13);
INSERT INTO public.word_grammar_compatibility VALUES (924, 209, 10);
INSERT INTO public.word_grammar_compatibility VALUES (925, 210, 1);
INSERT INTO public.word_grammar_compatibility VALUES (926, 210, 2);
INSERT INTO public.word_grammar_compatibility VALUES (927, 210, 3);
INSERT INTO public.word_grammar_compatibility VALUES (928, 210, 4);
INSERT INTO public.word_grammar_compatibility VALUES (929, 211, 5);
INSERT INTO public.word_grammar_compatibility VALUES (930, 211, 6);
INSERT INTO public.word_grammar_compatibility VALUES (931, 211, 7);
INSERT INTO public.word_grammar_compatibility VALUES (932, 212, 8);
INSERT INTO public.word_grammar_compatibility VALUES (933, 212, 9);
INSERT INTO public.word_grammar_compatibility VALUES (934, 212, 12);
INSERT INTO public.word_grammar_compatibility VALUES (935, 213, 10);
INSERT INTO public.word_grammar_compatibility VALUES (936, 213, 13);
INSERT INTO public.word_grammar_compatibility VALUES (937, 214, 1);
INSERT INTO public.word_grammar_compatibility VALUES (938, 214, 2);
INSERT INTO public.word_grammar_compatibility VALUES (939, 214, 3);
INSERT INTO public.word_grammar_compatibility VALUES (940, 214, 4);
INSERT INTO public.word_grammar_compatibility VALUES (941, 215, 5);
INSERT INTO public.word_grammar_compatibility VALUES (942, 215, 6);
INSERT INTO public.word_grammar_compatibility VALUES (943, 215, 7);
INSERT INTO public.word_grammar_compatibility VALUES (944, 216, 8);
INSERT INTO public.word_grammar_compatibility VALUES (945, 216, 9);
INSERT INTO public.word_grammar_compatibility VALUES (946, 216, 12);
INSERT INTO public.word_grammar_compatibility VALUES (947, 217, 10);
INSERT INTO public.word_grammar_compatibility VALUES (948, 217, 13);
INSERT INTO public.word_grammar_compatibility VALUES (949, 218, 1);
INSERT INTO public.word_grammar_compatibility VALUES (950, 218, 2);
INSERT INTO public.word_grammar_compatibility VALUES (951, 218, 3);
INSERT INTO public.word_grammar_compatibility VALUES (952, 218, 4);
INSERT INTO public.word_grammar_compatibility VALUES (953, 219, 5);
INSERT INTO public.word_grammar_compatibility VALUES (954, 219, 6);
INSERT INTO public.word_grammar_compatibility VALUES (955, 219, 7);
INSERT INTO public.word_grammar_compatibility VALUES (956, 220, 8);
INSERT INTO public.word_grammar_compatibility VALUES (957, 220, 9);
INSERT INTO public.word_grammar_compatibility VALUES (958, 220, 12);
INSERT INTO public.word_grammar_compatibility VALUES (959, 221, 10);
INSERT INTO public.word_grammar_compatibility VALUES (960, 221, 13);
INSERT INTO public.word_grammar_compatibility VALUES (961, 222, 1);
INSERT INTO public.word_grammar_compatibility VALUES (962, 222, 2);
INSERT INTO public.word_grammar_compatibility VALUES (963, 222, 3);
INSERT INTO public.word_grammar_compatibility VALUES (964, 222, 4);
INSERT INTO public.word_grammar_compatibility VALUES (965, 223, 5);
INSERT INTO public.word_grammar_compatibility VALUES (966, 223, 6);
INSERT INTO public.word_grammar_compatibility VALUES (967, 223, 7);
INSERT INTO public.word_grammar_compatibility VALUES (968, 224, 8);
INSERT INTO public.word_grammar_compatibility VALUES (969, 224, 9);
INSERT INTO public.word_grammar_compatibility VALUES (970, 224, 12);
INSERT INTO public.word_grammar_compatibility VALUES (971, 225, 10);
INSERT INTO public.word_grammar_compatibility VALUES (972, 225, 13);
INSERT INTO public.word_grammar_compatibility VALUES (973, 226, 1);
INSERT INTO public.word_grammar_compatibility VALUES (974, 226, 2);
INSERT INTO public.word_grammar_compatibility VALUES (975, 226, 3);
INSERT INTO public.word_grammar_compatibility VALUES (976, 226, 4);
INSERT INTO public.word_grammar_compatibility VALUES (977, 227, 5);
INSERT INTO public.word_grammar_compatibility VALUES (978, 227, 6);
INSERT INTO public.word_grammar_compatibility VALUES (979, 227, 7);
INSERT INTO public.word_grammar_compatibility VALUES (980, 228, 8);
INSERT INTO public.word_grammar_compatibility VALUES (981, 228, 9);
INSERT INTO public.word_grammar_compatibility VALUES (982, 228, 12);
INSERT INTO public.word_grammar_compatibility VALUES (983, 229, 10);
INSERT INTO public.word_grammar_compatibility VALUES (984, 229, 13);
INSERT INTO public.word_grammar_compatibility VALUES (985, 230, 1);
INSERT INTO public.word_grammar_compatibility VALUES (986, 230, 2);
INSERT INTO public.word_grammar_compatibility VALUES (987, 230, 3);
INSERT INTO public.word_grammar_compatibility VALUES (988, 230, 4);
INSERT INTO public.word_grammar_compatibility VALUES (989, 231, 5);
INSERT INTO public.word_grammar_compatibility VALUES (990, 231, 6);
INSERT INTO public.word_grammar_compatibility VALUES (991, 231, 7);
INSERT INTO public.word_grammar_compatibility VALUES (992, 232, 8);
INSERT INTO public.word_grammar_compatibility VALUES (993, 232, 9);
INSERT INTO public.word_grammar_compatibility VALUES (994, 232, 12);
INSERT INTO public.word_grammar_compatibility VALUES (995, 233, 10);
INSERT INTO public.word_grammar_compatibility VALUES (996, 233, 13);
INSERT INTO public.word_grammar_compatibility VALUES (997, 234, 1);
INSERT INTO public.word_grammar_compatibility VALUES (998, 234, 2);
INSERT INTO public.word_grammar_compatibility VALUES (999, 234, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1000, 234, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1001, 235, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1002, 235, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1003, 235, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1004, 236, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1005, 236, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1006, 236, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1007, 237, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1008, 237, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1009, 238, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1010, 238, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1011, 238, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1012, 238, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1013, 239, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1014, 239, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1015, 239, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1016, 240, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1017, 240, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1018, 240, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1019, 241, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1020, 241, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1021, 242, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1022, 242, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1023, 242, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1024, 242, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1025, 243, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1026, 243, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1027, 243, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1028, 244, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1029, 244, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1030, 244, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1031, 245, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1032, 245, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1033, 246, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1034, 246, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1035, 246, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1036, 246, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1037, 247, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1038, 247, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1039, 247, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1040, 248, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1041, 248, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1042, 248, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1043, 249, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1044, 249, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1045, 250, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1046, 250, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1047, 250, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1048, 250, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1049, 251, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1050, 251, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1051, 251, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1052, 252, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1053, 252, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1054, 252, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1055, 253, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1056, 253, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1057, 254, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1058, 254, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1059, 254, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1060, 254, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1061, 255, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1062, 255, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1063, 255, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1064, 256, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1065, 256, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1066, 256, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1067, 257, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1068, 257, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1069, 258, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1070, 258, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1071, 258, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1072, 258, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1073, 259, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1074, 259, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1075, 259, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1076, 260, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1077, 260, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1078, 260, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1079, 261, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1080, 261, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1081, 262, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1082, 262, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1083, 262, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1084, 262, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1085, 263, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1086, 263, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1087, 263, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1088, 264, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1089, 264, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1090, 264, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1091, 265, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1092, 265, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1093, 266, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1094, 266, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1095, 266, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1096, 266, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1097, 267, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1098, 267, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1099, 267, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1100, 268, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1101, 268, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1102, 268, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1103, 269, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1104, 269, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1105, 270, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1106, 270, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1107, 270, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1108, 270, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1109, 271, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1110, 271, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1111, 271, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1112, 272, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1113, 272, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1114, 272, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1115, 273, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1116, 273, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1117, 274, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1118, 274, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1119, 274, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1120, 274, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1121, 275, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1122, 275, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1123, 275, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1124, 276, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1125, 276, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1126, 276, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1127, 277, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1128, 277, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1129, 278, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1130, 278, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1131, 278, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1132, 278, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1133, 279, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1134, 279, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1135, 279, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1136, 280, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1137, 280, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1138, 280, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1139, 281, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1140, 281, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1141, 282, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1142, 282, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1143, 282, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1144, 282, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1145, 283, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1146, 283, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1147, 283, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1148, 284, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1149, 284, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1150, 284, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1151, 285, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1152, 285, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1153, 286, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1154, 286, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1155, 286, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1156, 286, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1157, 287, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1158, 287, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1159, 287, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1160, 288, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1161, 288, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1162, 288, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1163, 289, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1164, 289, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1165, 290, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1166, 290, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1167, 290, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1168, 290, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1169, 291, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1170, 291, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1171, 291, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1172, 292, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1173, 292, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1174, 292, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1175, 293, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1176, 293, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1177, 294, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1178, 294, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1179, 294, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1180, 294, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1181, 295, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1182, 295, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1183, 295, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1184, 296, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1185, 296, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1186, 296, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1187, 297, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1188, 297, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1189, 298, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1190, 298, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1191, 298, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1192, 298, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1193, 299, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1194, 299, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1195, 299, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1196, 300, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1197, 300, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1198, 300, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1199, 301, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1200, 301, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1201, 302, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1202, 302, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1203, 302, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1204, 302, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1205, 303, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1206, 303, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1207, 303, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1208, 304, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1209, 304, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1210, 304, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1211, 305, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1212, 305, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1213, 306, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1214, 306, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1215, 306, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1216, 306, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1217, 307, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1218, 307, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1219, 307, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1220, 308, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1221, 308, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1222, 308, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1223, 309, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1224, 309, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1225, 310, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1226, 310, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1227, 310, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1228, 310, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1229, 311, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1230, 311, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1231, 311, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1232, 312, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1233, 312, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1234, 312, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1235, 313, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1236, 313, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1237, 314, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1238, 314, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1239, 314, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1240, 314, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1241, 315, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1242, 315, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1243, 315, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1244, 316, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1245, 316, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1246, 316, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1247, 317, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1248, 317, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1249, 318, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1250, 318, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1251, 318, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1252, 318, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1253, 319, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1254, 319, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1255, 319, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1256, 320, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1257, 320, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1258, 320, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1259, 321, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1260, 321, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1261, 322, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1262, 322, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1263, 322, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1264, 322, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1265, 323, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1266, 323, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1267, 323, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1268, 324, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1269, 324, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1270, 324, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1271, 325, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1272, 325, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1273, 326, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1274, 326, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1275, 326, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1276, 326, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1277, 327, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1278, 327, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1279, 327, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1280, 328, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1281, 328, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1282, 328, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1283, 329, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1284, 329, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1285, 330, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1286, 330, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1287, 330, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1288, 330, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1289, 331, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1290, 331, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1291, 331, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1292, 332, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1293, 332, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1294, 332, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1295, 333, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1296, 333, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1297, 334, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1298, 334, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1299, 334, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1300, 334, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1301, 335, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1302, 335, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1303, 335, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1304, 336, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1305, 336, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1306, 336, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1307, 337, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1308, 337, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1309, 338, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1310, 338, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1311, 338, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1312, 338, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1313, 339, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1314, 339, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1315, 339, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1316, 340, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1317, 340, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1318, 340, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1319, 341, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1320, 341, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1321, 342, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1322, 342, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1323, 342, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1324, 342, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1325, 343, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1326, 343, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1327, 343, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1328, 344, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1329, 344, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1330, 344, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1331, 345, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1332, 345, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1333, 346, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1334, 346, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1335, 346, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1336, 346, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1337, 347, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1338, 347, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1339, 347, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1340, 348, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1341, 348, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1342, 348, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1343, 349, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1344, 349, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1345, 350, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1346, 350, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1347, 350, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1348, 350, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1349, 351, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1350, 351, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1351, 351, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1352, 352, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1353, 352, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1354, 352, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1355, 353, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1356, 353, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1357, 354, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1358, 354, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1359, 354, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1360, 354, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1361, 355, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1362, 355, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1363, 355, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1364, 356, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1365, 356, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1366, 356, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1367, 357, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1368, 357, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1369, 358, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1370, 358, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1371, 358, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1372, 358, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1373, 359, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1374, 359, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1375, 359, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1376, 360, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1377, 360, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1378, 360, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1379, 361, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1380, 361, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1381, 362, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1382, 362, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1383, 362, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1384, 362, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1385, 363, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1386, 363, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1387, 363, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1388, 364, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1389, 364, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1390, 364, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1391, 365, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1392, 365, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1393, 366, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1394, 366, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1395, 366, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1396, 366, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1397, 367, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1398, 367, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1399, 367, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1400, 368, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1401, 368, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1402, 368, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1403, 369, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1404, 369, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1405, 370, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1406, 370, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1407, 370, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1408, 370, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1409, 371, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1410, 371, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1411, 371, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1412, 372, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1413, 372, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1414, 372, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1415, 373, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1416, 373, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1417, 374, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1418, 374, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1419, 374, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1420, 374, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1421, 375, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1422, 375, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1423, 375, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1424, 376, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1425, 376, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1426, 376, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1427, 377, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1428, 377, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1429, 378, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1430, 378, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1431, 378, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1432, 378, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1433, 379, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1434, 379, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1435, 379, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1436, 380, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1437, 380, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1438, 380, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1439, 381, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1440, 381, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1441, 382, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1442, 382, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1443, 382, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1444, 382, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1445, 383, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1446, 383, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1447, 383, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1448, 384, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1449, 384, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1450, 384, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1451, 385, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1452, 385, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1453, 386, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1454, 386, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1455, 386, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1456, 386, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1457, 387, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1458, 387, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1459, 387, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1460, 388, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1461, 388, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1462, 388, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1463, 389, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1464, 389, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1465, 390, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1466, 390, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1467, 390, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1468, 390, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1469, 391, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1470, 391, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1471, 391, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1472, 392, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1473, 392, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1474, 392, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1475, 393, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1476, 393, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1477, 394, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1478, 394, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1479, 394, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1480, 394, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1481, 395, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1482, 395, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1483, 395, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1484, 396, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1485, 396, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1486, 396, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1487, 397, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1488, 397, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1489, 398, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1490, 398, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1491, 398, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1492, 398, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1493, 399, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1494, 399, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1495, 399, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1496, 400, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1497, 400, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1498, 400, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1499, 401, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1500, 401, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1501, 402, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1502, 402, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1503, 402, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1504, 402, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1505, 403, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1506, 403, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1507, 403, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1508, 404, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1509, 404, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1510, 404, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1511, 405, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1512, 405, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1513, 406, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1514, 406, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1515, 406, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1516, 406, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1517, 407, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1518, 407, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1519, 407, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1520, 408, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1521, 408, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1522, 408, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1523, 409, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1524, 409, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1525, 410, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1526, 410, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1527, 410, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1528, 410, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1529, 411, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1530, 411, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1531, 411, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1532, 412, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1533, 412, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1534, 412, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1535, 413, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1536, 413, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1537, 414, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1538, 414, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1539, 414, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1540, 414, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1541, 415, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1542, 415, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1543, 415, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1544, 416, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1545, 416, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1546, 416, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1547, 417, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1548, 417, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1549, 418, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1550, 418, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1551, 418, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1552, 418, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1553, 419, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1554, 419, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1555, 419, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1556, 420, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1557, 420, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1558, 420, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1559, 421, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1560, 421, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1561, 422, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1562, 422, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1563, 422, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1564, 422, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1565, 423, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1566, 423, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1567, 423, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1568, 424, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1569, 424, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1570, 424, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1571, 425, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1572, 425, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1573, 426, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1574, 426, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1575, 426, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1576, 426, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1577, 427, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1578, 427, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1579, 427, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1580, 428, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1581, 428, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1582, 428, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1583, 429, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1584, 429, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1585, 430, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1586, 430, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1587, 430, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1588, 430, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1589, 431, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1590, 431, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1591, 431, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1592, 432, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1593, 432, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1594, 432, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1595, 433, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1596, 433, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1597, 434, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1598, 434, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1599, 434, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1600, 434, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1601, 435, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1602, 435, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1603, 435, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1604, 436, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1605, 436, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1606, 436, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1607, 437, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1608, 437, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1609, 438, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1610, 438, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1611, 438, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1612, 438, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1613, 439, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1614, 439, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1615, 439, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1616, 440, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1617, 440, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1618, 440, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1619, 441, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1620, 441, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1621, 442, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1622, 442, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1623, 442, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1624, 442, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1625, 443, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1626, 443, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1627, 443, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1628, 444, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1629, 444, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1630, 444, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1631, 445, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1632, 445, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1633, 446, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1634, 446, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1635, 446, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1636, 446, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1637, 447, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1638, 447, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1639, 447, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1640, 448, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1641, 448, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1642, 448, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1643, 449, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1644, 449, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1645, 450, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1646, 450, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1647, 450, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1648, 450, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1649, 451, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1650, 451, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1651, 451, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1652, 452, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1653, 452, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1654, 452, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1655, 453, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1656, 453, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1657, 454, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1658, 454, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1659, 454, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1660, 454, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1661, 455, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1662, 455, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1663, 455, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1664, 456, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1665, 456, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1666, 456, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1667, 457, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1668, 457, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1669, 458, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1670, 458, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1671, 458, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1672, 458, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1673, 459, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1674, 459, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1675, 459, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1676, 460, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1677, 460, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1678, 460, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1679, 461, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1680, 461, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1681, 462, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1682, 462, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1683, 462, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1684, 462, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1685, 463, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1686, 463, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1687, 463, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1688, 464, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1689, 464, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1690, 464, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1691, 465, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1692, 465, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1693, 466, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1694, 466, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1695, 466, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1696, 466, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1697, 467, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1698, 467, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1699, 467, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1700, 468, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1701, 468, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1702, 468, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1703, 469, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1704, 469, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1705, 470, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1706, 470, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1707, 470, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1708, 470, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1709, 471, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1710, 471, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1711, 471, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1712, 472, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1713, 472, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1714, 472, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1715, 473, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1716, 473, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1717, 474, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1718, 474, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1719, 474, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1720, 474, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1721, 475, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1722, 475, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1723, 475, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1724, 476, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1725, 476, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1726, 476, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1727, 477, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1728, 477, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1729, 478, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1730, 478, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1731, 478, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1732, 478, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1733, 479, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1734, 479, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1735, 479, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1736, 480, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1737, 480, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1738, 480, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1739, 481, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1740, 481, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1741, 482, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1742, 482, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1743, 482, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1744, 482, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1745, 483, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1746, 483, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1747, 483, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1748, 484, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1749, 484, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1750, 484, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1751, 485, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1752, 485, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1753, 486, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1754, 486, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1755, 486, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1756, 486, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1757, 487, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1758, 487, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1759, 487, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1760, 488, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1761, 488, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1762, 488, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1763, 489, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1764, 489, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1765, 490, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1766, 490, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1767, 490, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1768, 490, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1769, 491, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1770, 491, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1771, 491, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1772, 492, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1773, 492, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1774, 492, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1775, 493, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1776, 493, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1777, 494, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1778, 494, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1779, 494, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1780, 494, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1781, 495, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1782, 495, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1783, 495, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1784, 496, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1785, 496, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1786, 496, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1787, 497, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1788, 497, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1789, 498, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1790, 498, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1791, 498, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1792, 498, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1793, 499, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1794, 499, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1795, 499, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1796, 500, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1797, 500, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1798, 500, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1799, 501, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1800, 501, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1801, 502, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1802, 502, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1803, 502, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1804, 502, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1805, 503, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1806, 503, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1807, 503, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1808, 504, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1809, 504, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1810, 504, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1811, 505, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1812, 505, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1813, 506, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1814, 506, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1815, 506, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1816, 506, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1817, 507, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1818, 507, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1819, 507, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1820, 508, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1821, 508, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1822, 508, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1823, 509, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1824, 509, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1825, 510, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1826, 510, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1827, 510, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1828, 510, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1829, 511, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1830, 511, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1831, 511, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1832, 512, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1833, 512, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1834, 512, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1835, 513, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1836, 513, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1837, 514, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1838, 514, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1839, 514, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1840, 514, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1841, 515, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1842, 515, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1843, 515, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1844, 516, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1845, 516, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1846, 516, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1847, 517, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1848, 517, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1849, 518, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1850, 518, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1851, 518, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1852, 518, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1853, 519, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1854, 519, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1855, 519, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1856, 520, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1857, 520, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1858, 520, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1859, 521, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1860, 521, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1861, 522, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1862, 522, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1863, 522, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1864, 522, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1865, 523, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1866, 523, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1867, 523, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1868, 524, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1869, 524, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1870, 524, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1871, 525, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1872, 525, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1873, 526, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1874, 526, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1875, 526, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1876, 526, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1877, 527, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1878, 527, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1879, 527, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1880, 528, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1881, 528, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1882, 528, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1883, 529, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1884, 529, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1885, 530, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1886, 530, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1887, 530, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1888, 530, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1889, 531, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1890, 531, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1891, 531, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1892, 532, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1893, 532, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1894, 532, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1895, 533, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1896, 533, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1897, 534, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1898, 534, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1899, 534, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1900, 534, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1901, 535, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1902, 535, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1903, 535, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1904, 536, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1905, 536, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1906, 536, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1907, 537, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1908, 537, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1909, 538, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1910, 538, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1911, 538, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1912, 538, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1913, 539, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1914, 539, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1915, 539, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1916, 540, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1917, 540, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1918, 540, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1919, 541, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1920, 541, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1921, 542, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1922, 542, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1923, 542, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1924, 542, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1925, 543, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1926, 543, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1927, 543, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1928, 544, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1929, 544, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1930, 544, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1931, 545, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1932, 545, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1933, 546, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1934, 546, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1935, 546, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1936, 546, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1937, 547, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1938, 547, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1939, 547, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1940, 548, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1941, 548, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1942, 548, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1943, 549, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1944, 549, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1945, 550, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1946, 550, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1947, 550, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1948, 550, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1949, 551, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1950, 551, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1951, 551, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1952, 552, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1953, 552, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1954, 552, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1955, 553, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1956, 553, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1957, 554, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1958, 554, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1959, 554, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1960, 554, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1961, 555, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1962, 555, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1963, 555, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1964, 556, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1965, 556, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1966, 556, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1967, 557, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1968, 557, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1969, 558, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1970, 558, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1971, 558, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1972, 558, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1973, 559, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1974, 559, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1975, 559, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1976, 560, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1977, 560, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1978, 560, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1979, 561, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1980, 561, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1981, 562, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1982, 562, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1983, 562, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1984, 562, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1985, 563, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1986, 563, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1987, 563, 6);
INSERT INTO public.word_grammar_compatibility VALUES (1988, 564, 12);
INSERT INTO public.word_grammar_compatibility VALUES (1989, 564, 8);
INSERT INTO public.word_grammar_compatibility VALUES (1990, 564, 9);
INSERT INTO public.word_grammar_compatibility VALUES (1991, 565, 13);
INSERT INTO public.word_grammar_compatibility VALUES (1992, 565, 10);
INSERT INTO public.word_grammar_compatibility VALUES (1993, 566, 4);
INSERT INTO public.word_grammar_compatibility VALUES (1994, 566, 1);
INSERT INTO public.word_grammar_compatibility VALUES (1995, 566, 2);
INSERT INTO public.word_grammar_compatibility VALUES (1996, 566, 3);
INSERT INTO public.word_grammar_compatibility VALUES (1997, 567, 7);
INSERT INTO public.word_grammar_compatibility VALUES (1998, 567, 5);
INSERT INTO public.word_grammar_compatibility VALUES (1999, 567, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2000, 568, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2001, 568, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2002, 568, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2003, 569, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2004, 569, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2005, 570, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2006, 570, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2007, 570, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2008, 570, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2009, 571, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2010, 571, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2011, 571, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2012, 572, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2013, 572, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2014, 572, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2015, 573, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2016, 573, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2017, 574, 14);
INSERT INTO public.word_grammar_compatibility VALUES (2018, 575, 14);
INSERT INTO public.word_grammar_compatibility VALUES (2019, 576, 14);
INSERT INTO public.word_grammar_compatibility VALUES (2020, 577, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2021, 577, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2022, 577, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2023, 577, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2024, 577, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2025, 577, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2026, 577, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2027, 578, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2028, 578, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2029, 578, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2030, 578, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2031, 578, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2032, 579, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2033, 579, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2034, 579, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2035, 579, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2036, 579, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2037, 579, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2038, 579, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2039, 580, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2040, 580, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2041, 580, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2042, 580, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2043, 580, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2044, 580, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2045, 580, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2046, 581, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2047, 581, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2048, 581, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2049, 581, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2050, 581, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2051, 582, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2052, 582, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2053, 582, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2054, 582, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2055, 582, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2056, 583, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2057, 583, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2058, 583, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2059, 583, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2060, 584, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2061, 585, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2062, 586, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2063, 587, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2064, 588, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2065, 589, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2066, 590, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2067, 590, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2068, 591, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2069, 591, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2070, 592, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2071, 593, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2072, 594, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2073, 595, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2074, 595, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2075, 595, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2076, 595, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2077, 596, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2078, 597, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2079, 598, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2080, 599, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2081, 600, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2082, 601, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2083, 602, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2084, 602, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2085, 603, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2086, 603, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2087, 603, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2088, 603, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2089, 604, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2090, 605, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2091, 606, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2092, 607, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2093, 608, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2094, 609, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2095, 610, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2096, 610, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2097, 611, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2098, 611, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2099, 611, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2100, 611, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2101, 612, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2102, 613, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2103, 614, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2104, 615, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2105, 616, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2106, 617, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2107, 618, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2108, 618, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2109, 619, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2110, 619, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2111, 619, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2112, 619, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2113, 620, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2114, 621, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2115, 622, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2116, 623, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2117, 624, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2118, 625, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2119, 626, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2120, 626, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2121, 627, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2122, 627, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2123, 627, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2124, 627, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2125, 628, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2126, 629, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2127, 630, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2128, 631, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2129, 632, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2130, 633, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2131, 634, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2132, 634, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2133, 635, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2134, 635, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2135, 635, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2136, 635, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2137, 636, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2138, 637, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2139, 638, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2140, 639, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2141, 639, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2142, 640, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2143, 641, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2144, 642, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2145, 643, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2146, 643, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2147, 643, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2148, 643, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2149, 644, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2150, 645, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2151, 646, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2152, 647, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2153, 647, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2154, 648, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2155, 649, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2156, 650, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2157, 651, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2158, 651, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2159, 651, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2160, 651, 13);
INSERT INTO public.word_grammar_compatibility VALUES (2161, 652, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2162, 653, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2163, 654, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2164, 655, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2165, 655, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2166, 656, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2167, 657, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2168, 658, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2177, 663, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2178, 664, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2179, 665, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2180, 666, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2181, 667, 14);
INSERT INTO public.word_grammar_compatibility VALUES (2182, 668, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2183, 669, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2184, 670, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2185, 670, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2186, 671, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2187, 672, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2188, 673, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2189, 674, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2190, 675, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2191, 675, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2192, 676, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2193, 677, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2194, 677, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2195, 678, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2196, 678, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2197, 679, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2198, 680, 1);
INSERT INTO public.word_grammar_compatibility VALUES (2199, 680, 2);
INSERT INTO public.word_grammar_compatibility VALUES (2200, 680, 3);
INSERT INTO public.word_grammar_compatibility VALUES (2201, 680, 4);
INSERT INTO public.word_grammar_compatibility VALUES (2202, 681, 5);
INSERT INTO public.word_grammar_compatibility VALUES (2203, 681, 6);
INSERT INTO public.word_grammar_compatibility VALUES (2204, 681, 7);
INSERT INTO public.word_grammar_compatibility VALUES (2205, 682, 8);
INSERT INTO public.word_grammar_compatibility VALUES (2206, 682, 9);
INSERT INTO public.word_grammar_compatibility VALUES (2207, 682, 12);
INSERT INTO public.word_grammar_compatibility VALUES (2208, 683, 10);
INSERT INTO public.word_grammar_compatibility VALUES (2209, 683, 13);


--
-- TOC entry 3446 (class 0 OID 16489)
-- Dependencies: 225
-- Data for Name: word_grammar_requirements; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.word_grammar_requirements VALUES (2, 1, 4);
INSERT INTO public.word_grammar_requirements VALUES (3, 2, 4);
INSERT INTO public.word_grammar_requirements VALUES (5, 4, 4);
INSERT INTO public.word_grammar_requirements VALUES (6, 5, 1);
INSERT INTO public.word_grammar_requirements VALUES (7, 6, 9);
INSERT INTO public.word_grammar_requirements VALUES (8, 7, 9);
INSERT INTO public.word_grammar_requirements VALUES (9, 8, 9);
INSERT INTO public.word_grammar_requirements VALUES (10, 9, 4);
INSERT INTO public.word_grammar_requirements VALUES (11, 10, 7);
INSERT INTO public.word_grammar_requirements VALUES (12, 11, 4);
INSERT INTO public.word_grammar_requirements VALUES (13, 12, 4);
INSERT INTO public.word_grammar_requirements VALUES (14, 13, 1);
INSERT INTO public.word_grammar_requirements VALUES (15, 14, 4);
INSERT INTO public.word_grammar_requirements VALUES (16, 15, 8);
INSERT INTO public.word_grammar_requirements VALUES (17, 16, 8);
INSERT INTO public.word_grammar_requirements VALUES (18, 17, 10);
INSERT INTO public.word_grammar_requirements VALUES (19, 18, 4);
INSERT INTO public.word_grammar_requirements VALUES (20, 19, 4);
INSERT INTO public.word_grammar_requirements VALUES (21, 20, 4);
INSERT INTO public.word_grammar_requirements VALUES (22, 21, 4);
INSERT INTO public.word_grammar_requirements VALUES (23, 22, 4);
INSERT INTO public.word_grammar_requirements VALUES (24, 23, 4);
INSERT INTO public.word_grammar_requirements VALUES (25, 24, 7);
INSERT INTO public.word_grammar_requirements VALUES (26, 25, 7);
INSERT INTO public.word_grammar_requirements VALUES (27, 26, 1);
INSERT INTO public.word_grammar_requirements VALUES (28, 27, 5);
INSERT INTO public.word_grammar_requirements VALUES (29, 28, 1);
INSERT INTO public.word_grammar_requirements VALUES (30, 29, 10);
INSERT INTO public.word_grammar_requirements VALUES (31, 30, 1);
INSERT INTO public.word_grammar_requirements VALUES (32, 31, 8);
INSERT INTO public.word_grammar_requirements VALUES (33, 32, 1);
INSERT INTO public.word_grammar_requirements VALUES (34, 33, 8);
INSERT INTO public.word_grammar_requirements VALUES (35, 34, 5);
INSERT INTO public.word_grammar_requirements VALUES (36, 35, 10);
INSERT INTO public.word_grammar_requirements VALUES (39, 36, 5);
INSERT INTO public.word_grammar_requirements VALUES (40, 37, 10);
INSERT INTO public.word_grammar_requirements VALUES (41, 38, 3);
INSERT INTO public.word_grammar_requirements VALUES (42, 39, 6);
INSERT INTO public.word_grammar_requirements VALUES (43, 40, 9);
INSERT INTO public.word_grammar_requirements VALUES (44, 41, 10);
INSERT INTO public.word_grammar_requirements VALUES (45, 42, 1);
INSERT INTO public.word_grammar_requirements VALUES (46, 43, 8);
INSERT INTO public.word_grammar_requirements VALUES (47, 44, 1);
INSERT INTO public.word_grammar_requirements VALUES (48, 45, 8);
INSERT INTO public.word_grammar_requirements VALUES (49, 46, 1);
INSERT INTO public.word_grammar_requirements VALUES (50, 47, 8);
INSERT INTO public.word_grammar_requirements VALUES (51, 48, 1);
INSERT INTO public.word_grammar_requirements VALUES (52, 49, 8);
INSERT INTO public.word_grammar_requirements VALUES (53, 50, 1);
INSERT INTO public.word_grammar_requirements VALUES (54, 51, 8);
INSERT INTO public.word_grammar_requirements VALUES (55, 52, 1);
INSERT INTO public.word_grammar_requirements VALUES (56, 53, 8);
INSERT INTO public.word_grammar_requirements VALUES (57, 54, 1);
INSERT INTO public.word_grammar_requirements VALUES (58, 55, 8);
INSERT INTO public.word_grammar_requirements VALUES (59, 56, 1);
INSERT INTO public.word_grammar_requirements VALUES (60, 57, 8);
INSERT INTO public.word_grammar_requirements VALUES (61, 58, 1);
INSERT INTO public.word_grammar_requirements VALUES (62, 59, 8);
INSERT INTO public.word_grammar_requirements VALUES (63, 60, 5);
INSERT INTO public.word_grammar_requirements VALUES (64, 61, 10);
INSERT INTO public.word_grammar_requirements VALUES (65, 62, 5);
INSERT INTO public.word_grammar_requirements VALUES (66, 63, 10);
INSERT INTO public.word_grammar_requirements VALUES (67, 64, 5);
INSERT INTO public.word_grammar_requirements VALUES (68, 65, 10);
INSERT INTO public.word_grammar_requirements VALUES (69, 66, 5);
INSERT INTO public.word_grammar_requirements VALUES (70, 67, 10);
INSERT INTO public.word_grammar_requirements VALUES (71, 68, 6);
INSERT INTO public.word_grammar_requirements VALUES (72, 69, 10);
INSERT INTO public.word_grammar_requirements VALUES (73, 70, 3);
INSERT INTO public.word_grammar_requirements VALUES (74, 71, 9);
INSERT INTO public.word_grammar_requirements VALUES (75, 72, 1);
INSERT INTO public.word_grammar_requirements VALUES (76, 73, 8);
INSERT INTO public.word_grammar_requirements VALUES (77, 74, 1);
INSERT INTO public.word_grammar_requirements VALUES (78, 75, 8);
INSERT INTO public.word_grammar_requirements VALUES (79, 76, 1);
INSERT INTO public.word_grammar_requirements VALUES (80, 77, 8);
INSERT INTO public.word_grammar_requirements VALUES (81, 78, 1);
INSERT INTO public.word_grammar_requirements VALUES (82, 79, 8);
INSERT INTO public.word_grammar_requirements VALUES (83, 80, 5);
INSERT INTO public.word_grammar_requirements VALUES (84, 81, 10);
INSERT INTO public.word_grammar_requirements VALUES (85, 82, 5);
INSERT INTO public.word_grammar_requirements VALUES (86, 83, 10);
INSERT INTO public.word_grammar_requirements VALUES (87, 84, 1);
INSERT INTO public.word_grammar_requirements VALUES (88, 85, 8);
INSERT INTO public.word_grammar_requirements VALUES (89, 86, 1);
INSERT INTO public.word_grammar_requirements VALUES (90, 87, 8);
INSERT INTO public.word_grammar_requirements VALUES (91, 88, 1);
INSERT INTO public.word_grammar_requirements VALUES (92, 89, 8);
INSERT INTO public.word_grammar_requirements VALUES (93, 90, 1);
INSERT INTO public.word_grammar_requirements VALUES (94, 91, 8);
INSERT INTO public.word_grammar_requirements VALUES (95, 92, 1);
INSERT INTO public.word_grammar_requirements VALUES (96, 93, 8);
INSERT INTO public.word_grammar_requirements VALUES (97, 94, 1);
INSERT INTO public.word_grammar_requirements VALUES (98, 95, 8);
INSERT INTO public.word_grammar_requirements VALUES (99, 96, 2);
INSERT INTO public.word_grammar_requirements VALUES (100, 97, 9);
INSERT INTO public.word_grammar_requirements VALUES (101, 98, 1);
INSERT INTO public.word_grammar_requirements VALUES (102, 99, 8);
INSERT INTO public.word_grammar_requirements VALUES (103, 100, 1);
INSERT INTO public.word_grammar_requirements VALUES (104, 101, 8);
INSERT INTO public.word_grammar_requirements VALUES (105, 102, 1);
INSERT INTO public.word_grammar_requirements VALUES (106, 103, 8);
INSERT INTO public.word_grammar_requirements VALUES (107, 104, 1);
INSERT INTO public.word_grammar_requirements VALUES (108, 105, 8);
INSERT INTO public.word_grammar_requirements VALUES (109, 106, 5);
INSERT INTO public.word_grammar_requirements VALUES (110, 107, 10);
INSERT INTO public.word_grammar_requirements VALUES (111, 108, 3);
INSERT INTO public.word_grammar_requirements VALUES (112, 109, 9);
INSERT INTO public.word_grammar_requirements VALUES (113, 110, 1);
INSERT INTO public.word_grammar_requirements VALUES (114, 111, 8);
INSERT INTO public.word_grammar_requirements VALUES (115, 112, 1);
INSERT INTO public.word_grammar_requirements VALUES (116, 113, 8);
INSERT INTO public.word_grammar_requirements VALUES (117, 114, 5);
INSERT INTO public.word_grammar_requirements VALUES (118, 115, 10);
INSERT INTO public.word_grammar_requirements VALUES (119, 116, 5);
INSERT INTO public.word_grammar_requirements VALUES (120, 117, 10);
INSERT INTO public.word_grammar_requirements VALUES (121, 118, 5);
INSERT INTO public.word_grammar_requirements VALUES (122, 119, 10);
INSERT INTO public.word_grammar_requirements VALUES (123, 120, 5);
INSERT INTO public.word_grammar_requirements VALUES (124, 121, 10);
INSERT INTO public.word_grammar_requirements VALUES (125, 122, 5);
INSERT INTO public.word_grammar_requirements VALUES (126, 123, 10);
INSERT INTO public.word_grammar_requirements VALUES (127, 124, 5);
INSERT INTO public.word_grammar_requirements VALUES (128, 125, 10);
INSERT INTO public.word_grammar_requirements VALUES (129, 126, 5);
INSERT INTO public.word_grammar_requirements VALUES (130, 127, 10);
INSERT INTO public.word_grammar_requirements VALUES (131, 128, 5);
INSERT INTO public.word_grammar_requirements VALUES (132, 129, 10);
INSERT INTO public.word_grammar_requirements VALUES (133, 130, 5);
INSERT INTO public.word_grammar_requirements VALUES (134, 131, 10);
INSERT INTO public.word_grammar_requirements VALUES (135, 132, 5);
INSERT INTO public.word_grammar_requirements VALUES (136, 133, 10);
INSERT INTO public.word_grammar_requirements VALUES (137, 134, 5);
INSERT INTO public.word_grammar_requirements VALUES (138, 135, 10);
INSERT INTO public.word_grammar_requirements VALUES (139, 136, 5);
INSERT INTO public.word_grammar_requirements VALUES (140, 137, 10);
INSERT INTO public.word_grammar_requirements VALUES (141, 138, 5);
INSERT INTO public.word_grammar_requirements VALUES (142, 139, 10);
INSERT INTO public.word_grammar_requirements VALUES (143, 140, 1);
INSERT INTO public.word_grammar_requirements VALUES (144, 141, 8);
INSERT INTO public.word_grammar_requirements VALUES (145, 142, 1);
INSERT INTO public.word_grammar_requirements VALUES (146, 143, 8);
INSERT INTO public.word_grammar_requirements VALUES (147, 144, 1);
INSERT INTO public.word_grammar_requirements VALUES (148, 145, 5);
INSERT INTO public.word_grammar_requirements VALUES (149, 146, 8);
INSERT INTO public.word_grammar_requirements VALUES (150, 147, 10);
INSERT INTO public.word_grammar_requirements VALUES (151, 148, 1);
INSERT INTO public.word_grammar_requirements VALUES (152, 149, 5);
INSERT INTO public.word_grammar_requirements VALUES (153, 150, 8);
INSERT INTO public.word_grammar_requirements VALUES (154, 151, 10);
INSERT INTO public.word_grammar_requirements VALUES (155, 152, 1);
INSERT INTO public.word_grammar_requirements VALUES (156, 153, 5);
INSERT INTO public.word_grammar_requirements VALUES (157, 154, 8);
INSERT INTO public.word_grammar_requirements VALUES (158, 155, 10);
INSERT INTO public.word_grammar_requirements VALUES (159, 156, 1);
INSERT INTO public.word_grammar_requirements VALUES (160, 157, 5);
INSERT INTO public.word_grammar_requirements VALUES (161, 158, 8);
INSERT INTO public.word_grammar_requirements VALUES (162, 159, 10);
INSERT INTO public.word_grammar_requirements VALUES (163, 160, 1);
INSERT INTO public.word_grammar_requirements VALUES (164, 161, 5);
INSERT INTO public.word_grammar_requirements VALUES (165, 162, 8);
INSERT INTO public.word_grammar_requirements VALUES (166, 163, 10);
INSERT INTO public.word_grammar_requirements VALUES (167, 164, 1);
INSERT INTO public.word_grammar_requirements VALUES (168, 165, 5);
INSERT INTO public.word_grammar_requirements VALUES (169, 166, 8);
INSERT INTO public.word_grammar_requirements VALUES (170, 167, 10);
INSERT INTO public.word_grammar_requirements VALUES (171, 168, 1);
INSERT INTO public.word_grammar_requirements VALUES (172, 169, 5);
INSERT INTO public.word_grammar_requirements VALUES (173, 170, 8);
INSERT INTO public.word_grammar_requirements VALUES (174, 171, 10);
INSERT INTO public.word_grammar_requirements VALUES (175, 172, 2);
INSERT INTO public.word_grammar_requirements VALUES (176, 173, 5);
INSERT INTO public.word_grammar_requirements VALUES (177, 174, 9);
INSERT INTO public.word_grammar_requirements VALUES (178, 175, 10);
INSERT INTO public.word_grammar_requirements VALUES (179, 176, 2);
INSERT INTO public.word_grammar_requirements VALUES (180, 177, 5);
INSERT INTO public.word_grammar_requirements VALUES (181, 178, 9);
INSERT INTO public.word_grammar_requirements VALUES (182, 179, 10);
INSERT INTO public.word_grammar_requirements VALUES (183, 180, 3);
INSERT INTO public.word_grammar_requirements VALUES (184, 181, 6);
INSERT INTO public.word_grammar_requirements VALUES (185, 182, 9);
INSERT INTO public.word_grammar_requirements VALUES (4, 3, 5);
INSERT INTO public.word_grammar_requirements VALUES (186, 183, 10);
INSERT INTO public.word_grammar_requirements VALUES (187, 184, 3);
INSERT INTO public.word_grammar_requirements VALUES (188, 185, 6);
INSERT INTO public.word_grammar_requirements VALUES (189, 186, 9);
INSERT INTO public.word_grammar_requirements VALUES (190, 187, 10);
INSERT INTO public.word_grammar_requirements VALUES (191, 188, 2);
INSERT INTO public.word_grammar_requirements VALUES (192, 189, 5);
INSERT INTO public.word_grammar_requirements VALUES (193, 190, 9);
INSERT INTO public.word_grammar_requirements VALUES (194, 191, 10);
INSERT INTO public.word_grammar_requirements VALUES (195, 192, 2);
INSERT INTO public.word_grammar_requirements VALUES (196, 193, 5);
INSERT INTO public.word_grammar_requirements VALUES (197, 194, 9);
INSERT INTO public.word_grammar_requirements VALUES (198, 195, 10);
INSERT INTO public.word_grammar_requirements VALUES (199, 196, 5);
INSERT INTO public.word_grammar_requirements VALUES (200, 197, 10);
INSERT INTO public.word_grammar_requirements VALUES (201, 198, 5);
INSERT INTO public.word_grammar_requirements VALUES (202, 199, 10);
INSERT INTO public.word_grammar_requirements VALUES (203, 200, 5);
INSERT INTO public.word_grammar_requirements VALUES (204, 201, 10);
INSERT INTO public.word_grammar_requirements VALUES (205, 202, 5);
INSERT INTO public.word_grammar_requirements VALUES (206, 203, 10);
INSERT INTO public.word_grammar_requirements VALUES (207, 204, 5);
INSERT INTO public.word_grammar_requirements VALUES (208, 205, 10);
INSERT INTO public.word_grammar_requirements VALUES (209, 206, 5);
INSERT INTO public.word_grammar_requirements VALUES (210, 207, 10);
INSERT INTO public.word_grammar_requirements VALUES (211, 208, 6);
INSERT INTO public.word_grammar_requirements VALUES (212, 209, 10);
INSERT INTO public.word_grammar_requirements VALUES (213, 210, 1);
INSERT INTO public.word_grammar_requirements VALUES (214, 211, 5);
INSERT INTO public.word_grammar_requirements VALUES (215, 212, 8);
INSERT INTO public.word_grammar_requirements VALUES (216, 213, 10);
INSERT INTO public.word_grammar_requirements VALUES (217, 214, 1);
INSERT INTO public.word_grammar_requirements VALUES (218, 215, 5);
INSERT INTO public.word_grammar_requirements VALUES (219, 216, 8);
INSERT INTO public.word_grammar_requirements VALUES (220, 217, 10);
INSERT INTO public.word_grammar_requirements VALUES (221, 218, 1);
INSERT INTO public.word_grammar_requirements VALUES (222, 219, 5);
INSERT INTO public.word_grammar_requirements VALUES (223, 220, 8);
INSERT INTO public.word_grammar_requirements VALUES (224, 221, 10);
INSERT INTO public.word_grammar_requirements VALUES (225, 222, 1);
INSERT INTO public.word_grammar_requirements VALUES (226, 223, 5);
INSERT INTO public.word_grammar_requirements VALUES (227, 224, 8);
INSERT INTO public.word_grammar_requirements VALUES (228, 225, 10);
INSERT INTO public.word_grammar_requirements VALUES (229, 226, 1);
INSERT INTO public.word_grammar_requirements VALUES (230, 227, 5);
INSERT INTO public.word_grammar_requirements VALUES (231, 228, 8);
INSERT INTO public.word_grammar_requirements VALUES (232, 229, 10);
INSERT INTO public.word_grammar_requirements VALUES (233, 230, 1);
INSERT INTO public.word_grammar_requirements VALUES (234, 231, 5);
INSERT INTO public.word_grammar_requirements VALUES (235, 232, 8);
INSERT INTO public.word_grammar_requirements VALUES (236, 233, 10);
INSERT INTO public.word_grammar_requirements VALUES (237, 234, 1);
INSERT INTO public.word_grammar_requirements VALUES (238, 235, 5);
INSERT INTO public.word_grammar_requirements VALUES (239, 236, 8);
INSERT INTO public.word_grammar_requirements VALUES (240, 237, 10);
INSERT INTO public.word_grammar_requirements VALUES (241, 238, 1);
INSERT INTO public.word_grammar_requirements VALUES (242, 239, 5);
INSERT INTO public.word_grammar_requirements VALUES (243, 240, 8);
INSERT INTO public.word_grammar_requirements VALUES (244, 241, 10);
INSERT INTO public.word_grammar_requirements VALUES (245, 242, 3);
INSERT INTO public.word_grammar_requirements VALUES (246, 243, 6);
INSERT INTO public.word_grammar_requirements VALUES (247, 244, 9);
INSERT INTO public.word_grammar_requirements VALUES (248, 245, 10);
INSERT INTO public.word_grammar_requirements VALUES (249, 246, 1);
INSERT INTO public.word_grammar_requirements VALUES (250, 247, 5);
INSERT INTO public.word_grammar_requirements VALUES (251, 248, 8);
INSERT INTO public.word_grammar_requirements VALUES (252, 249, 10);
INSERT INTO public.word_grammar_requirements VALUES (253, 250, 1);
INSERT INTO public.word_grammar_requirements VALUES (254, 251, 5);
INSERT INTO public.word_grammar_requirements VALUES (255, 252, 8);
INSERT INTO public.word_grammar_requirements VALUES (256, 253, 10);
INSERT INTO public.word_grammar_requirements VALUES (257, 254, 2);
INSERT INTO public.word_grammar_requirements VALUES (258, 255, 5);
INSERT INTO public.word_grammar_requirements VALUES (259, 256, 9);
INSERT INTO public.word_grammar_requirements VALUES (260, 257, 10);
INSERT INTO public.word_grammar_requirements VALUES (261, 258, 1);
INSERT INTO public.word_grammar_requirements VALUES (262, 259, 5);
INSERT INTO public.word_grammar_requirements VALUES (263, 260, 8);
INSERT INTO public.word_grammar_requirements VALUES (264, 261, 10);
INSERT INTO public.word_grammar_requirements VALUES (265, 262, 3);
INSERT INTO public.word_grammar_requirements VALUES (266, 263, 6);
INSERT INTO public.word_grammar_requirements VALUES (267, 264, 9);
INSERT INTO public.word_grammar_requirements VALUES (268, 265, 10);
INSERT INTO public.word_grammar_requirements VALUES (269, 266, 2);
INSERT INTO public.word_grammar_requirements VALUES (270, 267, 5);
INSERT INTO public.word_grammar_requirements VALUES (271, 268, 9);
INSERT INTO public.word_grammar_requirements VALUES (272, 269, 10);
INSERT INTO public.word_grammar_requirements VALUES (273, 270, 1);
INSERT INTO public.word_grammar_requirements VALUES (274, 271, 5);
INSERT INTO public.word_grammar_requirements VALUES (275, 272, 8);
INSERT INTO public.word_grammar_requirements VALUES (276, 273, 10);
INSERT INTO public.word_grammar_requirements VALUES (277, 274, 3);
INSERT INTO public.word_grammar_requirements VALUES (278, 275, 6);
INSERT INTO public.word_grammar_requirements VALUES (279, 276, 9);
INSERT INTO public.word_grammar_requirements VALUES (280, 277, 10);
INSERT INTO public.word_grammar_requirements VALUES (281, 278, 1);
INSERT INTO public.word_grammar_requirements VALUES (282, 279, 5);
INSERT INTO public.word_grammar_requirements VALUES (283, 280, 8);
INSERT INTO public.word_grammar_requirements VALUES (284, 281, 10);
INSERT INTO public.word_grammar_requirements VALUES (285, 282, 1);
INSERT INTO public.word_grammar_requirements VALUES (286, 283, 5);
INSERT INTO public.word_grammar_requirements VALUES (287, 284, 8);
INSERT INTO public.word_grammar_requirements VALUES (288, 285, 10);
INSERT INTO public.word_grammar_requirements VALUES (289, 286, 1);
INSERT INTO public.word_grammar_requirements VALUES (290, 287, 5);
INSERT INTO public.word_grammar_requirements VALUES (291, 288, 8);
INSERT INTO public.word_grammar_requirements VALUES (292, 289, 10);
INSERT INTO public.word_grammar_requirements VALUES (293, 290, 1);
INSERT INTO public.word_grammar_requirements VALUES (294, 291, 5);
INSERT INTO public.word_grammar_requirements VALUES (295, 292, 8);
INSERT INTO public.word_grammar_requirements VALUES (296, 293, 10);
INSERT INTO public.word_grammar_requirements VALUES (297, 294, 1);
INSERT INTO public.word_grammar_requirements VALUES (298, 295, 5);
INSERT INTO public.word_grammar_requirements VALUES (299, 296, 8);
INSERT INTO public.word_grammar_requirements VALUES (300, 297, 10);
INSERT INTO public.word_grammar_requirements VALUES (301, 298, 1);
INSERT INTO public.word_grammar_requirements VALUES (302, 299, 5);
INSERT INTO public.word_grammar_requirements VALUES (303, 300, 8);
INSERT INTO public.word_grammar_requirements VALUES (304, 301, 10);
INSERT INTO public.word_grammar_requirements VALUES (305, 302, 2);
INSERT INTO public.word_grammar_requirements VALUES (306, 303, 5);
INSERT INTO public.word_grammar_requirements VALUES (307, 304, 9);
INSERT INTO public.word_grammar_requirements VALUES (308, 305, 10);
INSERT INTO public.word_grammar_requirements VALUES (309, 306, 1);
INSERT INTO public.word_grammar_requirements VALUES (310, 307, 5);
INSERT INTO public.word_grammar_requirements VALUES (311, 308, 8);
INSERT INTO public.word_grammar_requirements VALUES (312, 309, 10);
INSERT INTO public.word_grammar_requirements VALUES (313, 310, 1);
INSERT INTO public.word_grammar_requirements VALUES (314, 311, 5);
INSERT INTO public.word_grammar_requirements VALUES (315, 312, 8);
INSERT INTO public.word_grammar_requirements VALUES (316, 313, 10);
INSERT INTO public.word_grammar_requirements VALUES (317, 314, 1);
INSERT INTO public.word_grammar_requirements VALUES (318, 315, 5);
INSERT INTO public.word_grammar_requirements VALUES (319, 316, 8);
INSERT INTO public.word_grammar_requirements VALUES (320, 317, 10);
INSERT INTO public.word_grammar_requirements VALUES (321, 318, 1);
INSERT INTO public.word_grammar_requirements VALUES (322, 319, 5);
INSERT INTO public.word_grammar_requirements VALUES (323, 320, 8);
INSERT INTO public.word_grammar_requirements VALUES (324, 321, 10);
INSERT INTO public.word_grammar_requirements VALUES (325, 322, 2);
INSERT INTO public.word_grammar_requirements VALUES (326, 323, 5);
INSERT INTO public.word_grammar_requirements VALUES (327, 324, 9);
INSERT INTO public.word_grammar_requirements VALUES (328, 325, 10);
INSERT INTO public.word_grammar_requirements VALUES (329, 326, 1);
INSERT INTO public.word_grammar_requirements VALUES (330, 327, 5);
INSERT INTO public.word_grammar_requirements VALUES (331, 328, 8);
INSERT INTO public.word_grammar_requirements VALUES (332, 329, 10);
INSERT INTO public.word_grammar_requirements VALUES (333, 330, 3);
INSERT INTO public.word_grammar_requirements VALUES (334, 331, 6);
INSERT INTO public.word_grammar_requirements VALUES (335, 332, 9);
INSERT INTO public.word_grammar_requirements VALUES (336, 333, 10);
INSERT INTO public.word_grammar_requirements VALUES (337, 334, 2);
INSERT INTO public.word_grammar_requirements VALUES (338, 335, 5);
INSERT INTO public.word_grammar_requirements VALUES (339, 336, 9);
INSERT INTO public.word_grammar_requirements VALUES (340, 337, 10);
INSERT INTO public.word_grammar_requirements VALUES (341, 338, 1);
INSERT INTO public.word_grammar_requirements VALUES (342, 339, 5);
INSERT INTO public.word_grammar_requirements VALUES (343, 340, 8);
INSERT INTO public.word_grammar_requirements VALUES (344, 341, 10);
INSERT INTO public.word_grammar_requirements VALUES (345, 342, 3);
INSERT INTO public.word_grammar_requirements VALUES (346, 343, 6);
INSERT INTO public.word_grammar_requirements VALUES (347, 344, 9);
INSERT INTO public.word_grammar_requirements VALUES (348, 345, 10);
INSERT INTO public.word_grammar_requirements VALUES (349, 346, 3);
INSERT INTO public.word_grammar_requirements VALUES (350, 347, 6);
INSERT INTO public.word_grammar_requirements VALUES (351, 348, 9);
INSERT INTO public.word_grammar_requirements VALUES (352, 349, 10);
INSERT INTO public.word_grammar_requirements VALUES (353, 350, 3);
INSERT INTO public.word_grammar_requirements VALUES (354, 351, 6);
INSERT INTO public.word_grammar_requirements VALUES (355, 352, 9);
INSERT INTO public.word_grammar_requirements VALUES (356, 353, 10);
INSERT INTO public.word_grammar_requirements VALUES (357, 354, 1);
INSERT INTO public.word_grammar_requirements VALUES (358, 355, 5);
INSERT INTO public.word_grammar_requirements VALUES (359, 356, 8);
INSERT INTO public.word_grammar_requirements VALUES (360, 357, 10);
INSERT INTO public.word_grammar_requirements VALUES (361, 358, 1);
INSERT INTO public.word_grammar_requirements VALUES (362, 359, 5);
INSERT INTO public.word_grammar_requirements VALUES (363, 360, 8);
INSERT INTO public.word_grammar_requirements VALUES (364, 361, 10);
INSERT INTO public.word_grammar_requirements VALUES (365, 362, 1);
INSERT INTO public.word_grammar_requirements VALUES (366, 363, 5);
INSERT INTO public.word_grammar_requirements VALUES (367, 364, 8);
INSERT INTO public.word_grammar_requirements VALUES (368, 365, 10);
INSERT INTO public.word_grammar_requirements VALUES (369, 366, 2);
INSERT INTO public.word_grammar_requirements VALUES (370, 367, 5);
INSERT INTO public.word_grammar_requirements VALUES (371, 368, 9);
INSERT INTO public.word_grammar_requirements VALUES (372, 369, 10);
INSERT INTO public.word_grammar_requirements VALUES (373, 370, 1);
INSERT INTO public.word_grammar_requirements VALUES (374, 371, 5);
INSERT INTO public.word_grammar_requirements VALUES (375, 372, 8);
INSERT INTO public.word_grammar_requirements VALUES (376, 373, 10);
INSERT INTO public.word_grammar_requirements VALUES (377, 374, 1);
INSERT INTO public.word_grammar_requirements VALUES (378, 375, 5);
INSERT INTO public.word_grammar_requirements VALUES (379, 376, 8);
INSERT INTO public.word_grammar_requirements VALUES (380, 377, 10);
INSERT INTO public.word_grammar_requirements VALUES (381, 378, 1);
INSERT INTO public.word_grammar_requirements VALUES (382, 379, 5);
INSERT INTO public.word_grammar_requirements VALUES (383, 380, 8);
INSERT INTO public.word_grammar_requirements VALUES (384, 381, 10);
INSERT INTO public.word_grammar_requirements VALUES (385, 382, 1);
INSERT INTO public.word_grammar_requirements VALUES (386, 383, 5);
INSERT INTO public.word_grammar_requirements VALUES (387, 384, 8);
INSERT INTO public.word_grammar_requirements VALUES (388, 385, 10);
INSERT INTO public.word_grammar_requirements VALUES (389, 386, 3);
INSERT INTO public.word_grammar_requirements VALUES (390, 387, 6);
INSERT INTO public.word_grammar_requirements VALUES (391, 388, 9);
INSERT INTO public.word_grammar_requirements VALUES (392, 389, 10);
INSERT INTO public.word_grammar_requirements VALUES (393, 390, 1);
INSERT INTO public.word_grammar_requirements VALUES (394, 391, 5);
INSERT INTO public.word_grammar_requirements VALUES (395, 392, 8);
INSERT INTO public.word_grammar_requirements VALUES (396, 393, 10);
INSERT INTO public.word_grammar_requirements VALUES (397, 394, 1);
INSERT INTO public.word_grammar_requirements VALUES (398, 395, 5);
INSERT INTO public.word_grammar_requirements VALUES (399, 396, 8);
INSERT INTO public.word_grammar_requirements VALUES (400, 397, 10);
INSERT INTO public.word_grammar_requirements VALUES (401, 398, 1);
INSERT INTO public.word_grammar_requirements VALUES (402, 399, 5);
INSERT INTO public.word_grammar_requirements VALUES (403, 400, 8);
INSERT INTO public.word_grammar_requirements VALUES (404, 401, 10);
INSERT INTO public.word_grammar_requirements VALUES (405, 402, 1);
INSERT INTO public.word_grammar_requirements VALUES (406, 403, 5);
INSERT INTO public.word_grammar_requirements VALUES (407, 404, 8);
INSERT INTO public.word_grammar_requirements VALUES (408, 405, 10);
INSERT INTO public.word_grammar_requirements VALUES (409, 406, 3);
INSERT INTO public.word_grammar_requirements VALUES (410, 407, 6);
INSERT INTO public.word_grammar_requirements VALUES (411, 408, 9);
INSERT INTO public.word_grammar_requirements VALUES (412, 409, 10);
INSERT INTO public.word_grammar_requirements VALUES (413, 410, 1);
INSERT INTO public.word_grammar_requirements VALUES (414, 411, 5);
INSERT INTO public.word_grammar_requirements VALUES (415, 412, 8);
INSERT INTO public.word_grammar_requirements VALUES (416, 413, 10);
INSERT INTO public.word_grammar_requirements VALUES (417, 414, 1);
INSERT INTO public.word_grammar_requirements VALUES (418, 415, 5);
INSERT INTO public.word_grammar_requirements VALUES (419, 416, 8);
INSERT INTO public.word_grammar_requirements VALUES (420, 417, 10);
INSERT INTO public.word_grammar_requirements VALUES (421, 418, 1);
INSERT INTO public.word_grammar_requirements VALUES (422, 419, 5);
INSERT INTO public.word_grammar_requirements VALUES (423, 420, 8);
INSERT INTO public.word_grammar_requirements VALUES (424, 421, 10);
INSERT INTO public.word_grammar_requirements VALUES (425, 422, 1);
INSERT INTO public.word_grammar_requirements VALUES (426, 423, 5);
INSERT INTO public.word_grammar_requirements VALUES (427, 424, 8);
INSERT INTO public.word_grammar_requirements VALUES (428, 425, 10);
INSERT INTO public.word_grammar_requirements VALUES (429, 426, 1);
INSERT INTO public.word_grammar_requirements VALUES (430, 427, 5);
INSERT INTO public.word_grammar_requirements VALUES (431, 428, 8);
INSERT INTO public.word_grammar_requirements VALUES (432, 429, 10);
INSERT INTO public.word_grammar_requirements VALUES (433, 430, 3);
INSERT INTO public.word_grammar_requirements VALUES (434, 431, 6);
INSERT INTO public.word_grammar_requirements VALUES (435, 432, 9);
INSERT INTO public.word_grammar_requirements VALUES (436, 433, 10);
INSERT INTO public.word_grammar_requirements VALUES (437, 434, 1);
INSERT INTO public.word_grammar_requirements VALUES (438, 435, 5);
INSERT INTO public.word_grammar_requirements VALUES (439, 436, 8);
INSERT INTO public.word_grammar_requirements VALUES (440, 437, 10);
INSERT INTO public.word_grammar_requirements VALUES (441, 438, 1);
INSERT INTO public.word_grammar_requirements VALUES (442, 439, 5);
INSERT INTO public.word_grammar_requirements VALUES (443, 440, 8);
INSERT INTO public.word_grammar_requirements VALUES (444, 441, 10);
INSERT INTO public.word_grammar_requirements VALUES (445, 442, 1);
INSERT INTO public.word_grammar_requirements VALUES (446, 443, 5);
INSERT INTO public.word_grammar_requirements VALUES (447, 444, 8);
INSERT INTO public.word_grammar_requirements VALUES (448, 445, 10);
INSERT INTO public.word_grammar_requirements VALUES (449, 446, 1);
INSERT INTO public.word_grammar_requirements VALUES (450, 447, 5);
INSERT INTO public.word_grammar_requirements VALUES (451, 448, 8);
INSERT INTO public.word_grammar_requirements VALUES (452, 449, 10);
INSERT INTO public.word_grammar_requirements VALUES (453, 450, 1);
INSERT INTO public.word_grammar_requirements VALUES (454, 451, 5);
INSERT INTO public.word_grammar_requirements VALUES (455, 452, 8);
INSERT INTO public.word_grammar_requirements VALUES (456, 453, 10);
INSERT INTO public.word_grammar_requirements VALUES (457, 454, 1);
INSERT INTO public.word_grammar_requirements VALUES (458, 455, 5);
INSERT INTO public.word_grammar_requirements VALUES (459, 456, 8);
INSERT INTO public.word_grammar_requirements VALUES (460, 457, 10);
INSERT INTO public.word_grammar_requirements VALUES (461, 458, 1);
INSERT INTO public.word_grammar_requirements VALUES (462, 459, 5);
INSERT INTO public.word_grammar_requirements VALUES (463, 460, 8);
INSERT INTO public.word_grammar_requirements VALUES (464, 461, 10);
INSERT INTO public.word_grammar_requirements VALUES (465, 462, 1);
INSERT INTO public.word_grammar_requirements VALUES (466, 463, 5);
INSERT INTO public.word_grammar_requirements VALUES (467, 464, 8);
INSERT INTO public.word_grammar_requirements VALUES (468, 465, 10);
INSERT INTO public.word_grammar_requirements VALUES (469, 466, 3);
INSERT INTO public.word_grammar_requirements VALUES (470, 467, 6);
INSERT INTO public.word_grammar_requirements VALUES (471, 468, 9);
INSERT INTO public.word_grammar_requirements VALUES (472, 469, 10);
INSERT INTO public.word_grammar_requirements VALUES (473, 470, 1);
INSERT INTO public.word_grammar_requirements VALUES (474, 471, 5);
INSERT INTO public.word_grammar_requirements VALUES (475, 472, 8);
INSERT INTO public.word_grammar_requirements VALUES (476, 473, 10);
INSERT INTO public.word_grammar_requirements VALUES (477, 474, 1);
INSERT INTO public.word_grammar_requirements VALUES (478, 475, 5);
INSERT INTO public.word_grammar_requirements VALUES (479, 476, 8);
INSERT INTO public.word_grammar_requirements VALUES (480, 477, 10);
INSERT INTO public.word_grammar_requirements VALUES (481, 478, 1);
INSERT INTO public.word_grammar_requirements VALUES (482, 479, 5);
INSERT INTO public.word_grammar_requirements VALUES (483, 480, 8);
INSERT INTO public.word_grammar_requirements VALUES (484, 481, 10);
INSERT INTO public.word_grammar_requirements VALUES (485, 482, 1);
INSERT INTO public.word_grammar_requirements VALUES (486, 483, 5);
INSERT INTO public.word_grammar_requirements VALUES (487, 484, 8);
INSERT INTO public.word_grammar_requirements VALUES (488, 485, 10);
INSERT INTO public.word_grammar_requirements VALUES (489, 486, 3);
INSERT INTO public.word_grammar_requirements VALUES (490, 487, 6);
INSERT INTO public.word_grammar_requirements VALUES (491, 488, 9);
INSERT INTO public.word_grammar_requirements VALUES (492, 489, 10);
INSERT INTO public.word_grammar_requirements VALUES (493, 490, 1);
INSERT INTO public.word_grammar_requirements VALUES (494, 491, 5);
INSERT INTO public.word_grammar_requirements VALUES (495, 492, 8);
INSERT INTO public.word_grammar_requirements VALUES (496, 493, 10);
INSERT INTO public.word_grammar_requirements VALUES (497, 494, 3);
INSERT INTO public.word_grammar_requirements VALUES (498, 495, 6);
INSERT INTO public.word_grammar_requirements VALUES (499, 496, 9);
INSERT INTO public.word_grammar_requirements VALUES (500, 497, 10);
INSERT INTO public.word_grammar_requirements VALUES (501, 498, 3);
INSERT INTO public.word_grammar_requirements VALUES (502, 499, 6);
INSERT INTO public.word_grammar_requirements VALUES (503, 500, 9);
INSERT INTO public.word_grammar_requirements VALUES (504, 501, 10);
INSERT INTO public.word_grammar_requirements VALUES (505, 502, 3);
INSERT INTO public.word_grammar_requirements VALUES (506, 503, 6);
INSERT INTO public.word_grammar_requirements VALUES (507, 504, 9);
INSERT INTO public.word_grammar_requirements VALUES (508, 505, 10);
INSERT INTO public.word_grammar_requirements VALUES (509, 506, 3);
INSERT INTO public.word_grammar_requirements VALUES (510, 507, 6);
INSERT INTO public.word_grammar_requirements VALUES (511, 508, 9);
INSERT INTO public.word_grammar_requirements VALUES (512, 509, 10);
INSERT INTO public.word_grammar_requirements VALUES (513, 510, 1);
INSERT INTO public.word_grammar_requirements VALUES (514, 511, 5);
INSERT INTO public.word_grammar_requirements VALUES (515, 512, 8);
INSERT INTO public.word_grammar_requirements VALUES (516, 513, 10);
INSERT INTO public.word_grammar_requirements VALUES (517, 514, 1);
INSERT INTO public.word_grammar_requirements VALUES (518, 515, 5);
INSERT INTO public.word_grammar_requirements VALUES (519, 516, 8);
INSERT INTO public.word_grammar_requirements VALUES (520, 517, 10);
INSERT INTO public.word_grammar_requirements VALUES (521, 518, 2);
INSERT INTO public.word_grammar_requirements VALUES (522, 519, 5);
INSERT INTO public.word_grammar_requirements VALUES (523, 520, 9);
INSERT INTO public.word_grammar_requirements VALUES (524, 521, 10);
INSERT INTO public.word_grammar_requirements VALUES (525, 522, 1);
INSERT INTO public.word_grammar_requirements VALUES (526, 523, 5);
INSERT INTO public.word_grammar_requirements VALUES (527, 524, 8);
INSERT INTO public.word_grammar_requirements VALUES (528, 525, 10);
INSERT INTO public.word_grammar_requirements VALUES (529, 526, 1);
INSERT INTO public.word_grammar_requirements VALUES (530, 527, 5);
INSERT INTO public.word_grammar_requirements VALUES (531, 528, 8);
INSERT INTO public.word_grammar_requirements VALUES (532, 529, 10);
INSERT INTO public.word_grammar_requirements VALUES (533, 530, 1);
INSERT INTO public.word_grammar_requirements VALUES (534, 531, 5);
INSERT INTO public.word_grammar_requirements VALUES (535, 532, 8);
INSERT INTO public.word_grammar_requirements VALUES (536, 533, 10);
INSERT INTO public.word_grammar_requirements VALUES (537, 534, 1);
INSERT INTO public.word_grammar_requirements VALUES (538, 535, 5);
INSERT INTO public.word_grammar_requirements VALUES (539, 536, 8);
INSERT INTO public.word_grammar_requirements VALUES (540, 537, 10);
INSERT INTO public.word_grammar_requirements VALUES (541, 538, 2);
INSERT INTO public.word_grammar_requirements VALUES (542, 539, 5);
INSERT INTO public.word_grammar_requirements VALUES (543, 540, 9);
INSERT INTO public.word_grammar_requirements VALUES (544, 541, 10);
INSERT INTO public.word_grammar_requirements VALUES (545, 542, 2);
INSERT INTO public.word_grammar_requirements VALUES (546, 543, 5);
INSERT INTO public.word_grammar_requirements VALUES (547, 544, 9);
INSERT INTO public.word_grammar_requirements VALUES (548, 545, 10);
INSERT INTO public.word_grammar_requirements VALUES (549, 546, 1);
INSERT INTO public.word_grammar_requirements VALUES (550, 547, 5);
INSERT INTO public.word_grammar_requirements VALUES (551, 548, 8);
INSERT INTO public.word_grammar_requirements VALUES (552, 549, 10);
INSERT INTO public.word_grammar_requirements VALUES (553, 550, 3);
INSERT INTO public.word_grammar_requirements VALUES (554, 551, 6);
INSERT INTO public.word_grammar_requirements VALUES (555, 552, 9);
INSERT INTO public.word_grammar_requirements VALUES (556, 553, 10);
INSERT INTO public.word_grammar_requirements VALUES (557, 554, 3);
INSERT INTO public.word_grammar_requirements VALUES (558, 555, 6);
INSERT INTO public.word_grammar_requirements VALUES (559, 556, 9);
INSERT INTO public.word_grammar_requirements VALUES (560, 557, 10);
INSERT INTO public.word_grammar_requirements VALUES (561, 558, 3);
INSERT INTO public.word_grammar_requirements VALUES (562, 559, 6);
INSERT INTO public.word_grammar_requirements VALUES (563, 560, 9);
INSERT INTO public.word_grammar_requirements VALUES (564, 561, 10);
INSERT INTO public.word_grammar_requirements VALUES (565, 562, 3);
INSERT INTO public.word_grammar_requirements VALUES (566, 563, 6);
INSERT INTO public.word_grammar_requirements VALUES (567, 564, 9);
INSERT INTO public.word_grammar_requirements VALUES (568, 565, 10);
INSERT INTO public.word_grammar_requirements VALUES (569, 566, 3);
INSERT INTO public.word_grammar_requirements VALUES (570, 567, 6);
INSERT INTO public.word_grammar_requirements VALUES (571, 568, 9);
INSERT INTO public.word_grammar_requirements VALUES (572, 569, 10);
INSERT INTO public.word_grammar_requirements VALUES (573, 570, 3);
INSERT INTO public.word_grammar_requirements VALUES (574, 571, 6);
INSERT INTO public.word_grammar_requirements VALUES (575, 572, 9);
INSERT INTO public.word_grammar_requirements VALUES (576, 573, 10);
INSERT INTO public.word_grammar_requirements VALUES (577, 574, 14);
INSERT INTO public.word_grammar_requirements VALUES (578, 575, 14);
INSERT INTO public.word_grammar_requirements VALUES (579, 576, 14);
INSERT INTO public.word_grammar_requirements VALUES (580, 577, 14);
INSERT INTO public.word_grammar_requirements VALUES (581, 578, 14);
INSERT INTO public.word_grammar_requirements VALUES (582, 579, 14);
INSERT INTO public.word_grammar_requirements VALUES (583, 580, 14);
INSERT INTO public.word_grammar_requirements VALUES (584, 581, 14);
INSERT INTO public.word_grammar_requirements VALUES (585, 582, 14);
INSERT INTO public.word_grammar_requirements VALUES (586, 583, 14);
INSERT INTO public.word_grammar_requirements VALUES (587, 584, 14);
INSERT INTO public.word_grammar_requirements VALUES (588, 585, 14);
INSERT INTO public.word_grammar_requirements VALUES (589, 586, 14);
INSERT INTO public.word_grammar_requirements VALUES (590, 587, 14);
INSERT INTO public.word_grammar_requirements VALUES (591, 588, 14);
INSERT INTO public.word_grammar_requirements VALUES (592, 589, 14);
INSERT INTO public.word_grammar_requirements VALUES (593, 590, 14);
INSERT INTO public.word_grammar_requirements VALUES (594, 591, 14);
INSERT INTO public.word_grammar_requirements VALUES (595, 592, 14);
INSERT INTO public.word_grammar_requirements VALUES (596, 593, 14);
INSERT INTO public.word_grammar_requirements VALUES (597, 594, 14);
INSERT INTO public.word_grammar_requirements VALUES (598, 595, 14);
INSERT INTO public.word_grammar_requirements VALUES (599, 596, 14);
INSERT INTO public.word_grammar_requirements VALUES (600, 597, 14);
INSERT INTO public.word_grammar_requirements VALUES (601, 598, 14);
INSERT INTO public.word_grammar_requirements VALUES (602, 599, 14);
INSERT INTO public.word_grammar_requirements VALUES (603, 600, 14);
INSERT INTO public.word_grammar_requirements VALUES (604, 601, 14);
INSERT INTO public.word_grammar_requirements VALUES (605, 602, 14);
INSERT INTO public.word_grammar_requirements VALUES (606, 603, 14);
INSERT INTO public.word_grammar_requirements VALUES (607, 604, 14);
INSERT INTO public.word_grammar_requirements VALUES (608, 605, 14);
INSERT INTO public.word_grammar_requirements VALUES (609, 606, 14);
INSERT INTO public.word_grammar_requirements VALUES (610, 607, 14);
INSERT INTO public.word_grammar_requirements VALUES (611, 608, 14);
INSERT INTO public.word_grammar_requirements VALUES (612, 609, 14);
INSERT INTO public.word_grammar_requirements VALUES (613, 610, 14);
INSERT INTO public.word_grammar_requirements VALUES (614, 611, 14);
INSERT INTO public.word_grammar_requirements VALUES (615, 612, 14);
INSERT INTO public.word_grammar_requirements VALUES (616, 613, 14);
INSERT INTO public.word_grammar_requirements VALUES (617, 614, 14);
INSERT INTO public.word_grammar_requirements VALUES (618, 615, 14);
INSERT INTO public.word_grammar_requirements VALUES (619, 616, 14);
INSERT INTO public.word_grammar_requirements VALUES (620, 617, 14);
INSERT INTO public.word_grammar_requirements VALUES (621, 618, 14);
INSERT INTO public.word_grammar_requirements VALUES (622, 619, 14);
INSERT INTO public.word_grammar_requirements VALUES (623, 620, 14);
INSERT INTO public.word_grammar_requirements VALUES (624, 621, 14);
INSERT INTO public.word_grammar_requirements VALUES (625, 622, 14);
INSERT INTO public.word_grammar_requirements VALUES (626, 623, 14);
INSERT INTO public.word_grammar_requirements VALUES (627, 624, 14);
INSERT INTO public.word_grammar_requirements VALUES (628, 625, 14);
INSERT INTO public.word_grammar_requirements VALUES (629, 626, 14);
INSERT INTO public.word_grammar_requirements VALUES (630, 627, 14);
INSERT INTO public.word_grammar_requirements VALUES (631, 628, 14);
INSERT INTO public.word_grammar_requirements VALUES (632, 629, 14);
INSERT INTO public.word_grammar_requirements VALUES (633, 630, 14);
INSERT INTO public.word_grammar_requirements VALUES (634, 631, 14);
INSERT INTO public.word_grammar_requirements VALUES (635, 632, 14);
INSERT INTO public.word_grammar_requirements VALUES (636, 633, 14);
INSERT INTO public.word_grammar_requirements VALUES (637, 634, 14);
INSERT INTO public.word_grammar_requirements VALUES (638, 635, 14);
INSERT INTO public.word_grammar_requirements VALUES (639, 636, 14);
INSERT INTO public.word_grammar_requirements VALUES (640, 637, 14);
INSERT INTO public.word_grammar_requirements VALUES (641, 638, 14);
INSERT INTO public.word_grammar_requirements VALUES (642, 639, 14);
INSERT INTO public.word_grammar_requirements VALUES (643, 640, 14);
INSERT INTO public.word_grammar_requirements VALUES (644, 641, 14);
INSERT INTO public.word_grammar_requirements VALUES (645, 642, 14);
INSERT INTO public.word_grammar_requirements VALUES (646, 643, 14);
INSERT INTO public.word_grammar_requirements VALUES (647, 644, 14);
INSERT INTO public.word_grammar_requirements VALUES (648, 645, 14);
INSERT INTO public.word_grammar_requirements VALUES (649, 646, 14);
INSERT INTO public.word_grammar_requirements VALUES (650, 647, 14);
INSERT INTO public.word_grammar_requirements VALUES (651, 648, 14);
INSERT INTO public.word_grammar_requirements VALUES (652, 649, 14);
INSERT INTO public.word_grammar_requirements VALUES (653, 650, 14);
INSERT INTO public.word_grammar_requirements VALUES (654, 651, 14);
INSERT INTO public.word_grammar_requirements VALUES (655, 652, 14);
INSERT INTO public.word_grammar_requirements VALUES (656, 653, 14);
INSERT INTO public.word_grammar_requirements VALUES (657, 654, 14);
INSERT INTO public.word_grammar_requirements VALUES (658, 655, 14);
INSERT INTO public.word_grammar_requirements VALUES (659, 656, 14);
INSERT INTO public.word_grammar_requirements VALUES (660, 657, 14);
INSERT INTO public.word_grammar_requirements VALUES (661, 658, 14);
INSERT INTO public.word_grammar_requirements VALUES (662, 659, 14);
INSERT INTO public.word_grammar_requirements VALUES (663, 660, 14);
INSERT INTO public.word_grammar_requirements VALUES (664, 661, 14);
INSERT INTO public.word_grammar_requirements VALUES (665, 662, 14);
INSERT INTO public.word_grammar_requirements VALUES (666, 663, 14);
INSERT INTO public.word_grammar_requirements VALUES (667, 664, 14);
INSERT INTO public.word_grammar_requirements VALUES (668, 665, 14);
INSERT INTO public.word_grammar_requirements VALUES (669, 666, 14);
INSERT INTO public.word_grammar_requirements VALUES (670, 667, 14);
INSERT INTO public.word_grammar_requirements VALUES (671, 668, 4);
INSERT INTO public.word_grammar_requirements VALUES (672, 669, 4);
INSERT INTO public.word_grammar_requirements VALUES (673, 670, 4);
INSERT INTO public.word_grammar_requirements VALUES (674, 671, 7);
INSERT INTO public.word_grammar_requirements VALUES (675, 672, 13);
INSERT INTO public.word_grammar_requirements VALUES (676, 673, 12);
INSERT INTO public.word_grammar_requirements VALUES (677, 674, 12);
INSERT INTO public.word_grammar_requirements VALUES (678, 675, 4);
INSERT INTO public.word_grammar_requirements VALUES (679, 676, 7);
INSERT INTO public.word_grammar_requirements VALUES (680, 677, 4);
INSERT INTO public.word_grammar_requirements VALUES (681, 678, 12);
INSERT INTO public.word_grammar_requirements VALUES (682, 679, 13);
INSERT INTO public.word_grammar_requirements VALUES (683, 680, 4);
INSERT INTO public.word_grammar_requirements VALUES (684, 681, 7);
INSERT INTO public.word_grammar_requirements VALUES (685, 682, 12);
INSERT INTO public.word_grammar_requirements VALUES (686, 683, 13);


--
-- TOC entry 3442 (class 0 OID 16449)
-- Dependencies: 221
-- Data for Name: word_semantic; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.word_semantic VALUES (4759, 658, 66);
INSERT INTO public.word_semantic VALUES (4760, 658, 52);
INSERT INTO public.word_semantic VALUES (4762, 659, 67);
INSERT INTO public.word_semantic VALUES (15, 1, 1);
INSERT INTO public.word_semantic VALUES (16, 1, 2);
INSERT INTO public.word_semantic VALUES (17, 1, 3);
INSERT INTO public.word_semantic VALUES (18, 1, 4);
INSERT INTO public.word_semantic VALUES (19, 1, 5);
INSERT INTO public.word_semantic VALUES (24, 2, 1);
INSERT INTO public.word_semantic VALUES (25, 2, 2);
INSERT INTO public.word_semantic VALUES (26, 2, 3);
INSERT INTO public.word_semantic VALUES (27, 2, 4);
INSERT INTO public.word_semantic VALUES (28, 2, 5);
INSERT INTO public.word_semantic VALUES (33, 3, 1);
INSERT INTO public.word_semantic VALUES (34, 3, 2);
INSERT INTO public.word_semantic VALUES (35, 3, 3);
INSERT INTO public.word_semantic VALUES (36, 3, 4);
INSERT INTO public.word_semantic VALUES (37, 3, 5);
INSERT INTO public.word_semantic VALUES (42, 4, 1);
INSERT INTO public.word_semantic VALUES (43, 4, 2);
INSERT INTO public.word_semantic VALUES (44, 4, 3);
INSERT INTO public.word_semantic VALUES (45, 4, 4);
INSERT INTO public.word_semantic VALUES (46, 4, 5);
INSERT INTO public.word_semantic VALUES (51, 5, 1);
INSERT INTO public.word_semantic VALUES (52, 5, 2);
INSERT INTO public.word_semantic VALUES (53, 5, 3);
INSERT INTO public.word_semantic VALUES (54, 5, 4);
INSERT INTO public.word_semantic VALUES (55, 5, 5);
INSERT INTO public.word_semantic VALUES (60, 6, 1);
INSERT INTO public.word_semantic VALUES (61, 6, 2);
INSERT INTO public.word_semantic VALUES (62, 6, 6);
INSERT INTO public.word_semantic VALUES (63, 6, 4);
INSERT INTO public.word_semantic VALUES (64, 6, 5);
INSERT INTO public.word_semantic VALUES (69, 7, 1);
INSERT INTO public.word_semantic VALUES (70, 7, 2);
INSERT INTO public.word_semantic VALUES (71, 7, 6);
INSERT INTO public.word_semantic VALUES (72, 7, 4);
INSERT INTO public.word_semantic VALUES (73, 7, 5);
INSERT INTO public.word_semantic VALUES (78, 8, 1);
INSERT INTO public.word_semantic VALUES (79, 8, 2);
INSERT INTO public.word_semantic VALUES (80, 8, 6);
INSERT INTO public.word_semantic VALUES (81, 8, 4);
INSERT INTO public.word_semantic VALUES (82, 8, 5);
INSERT INTO public.word_semantic VALUES (87, 9, 1);
INSERT INTO public.word_semantic VALUES (88, 9, 2);
INSERT INTO public.word_semantic VALUES (89, 9, 3);
INSERT INTO public.word_semantic VALUES (90, 9, 4);
INSERT INTO public.word_semantic VALUES (91, 9, 5);
INSERT INTO public.word_semantic VALUES (96, 10, 1);
INSERT INTO public.word_semantic VALUES (97, 10, 2);
INSERT INTO public.word_semantic VALUES (98, 10, 3);
INSERT INTO public.word_semantic VALUES (99, 10, 4);
INSERT INTO public.word_semantic VALUES (100, 10, 5);
INSERT INTO public.word_semantic VALUES (105, 11, 1);
INSERT INTO public.word_semantic VALUES (106, 11, 2);
INSERT INTO public.word_semantic VALUES (107, 11, 3);
INSERT INTO public.word_semantic VALUES (108, 11, 4);
INSERT INTO public.word_semantic VALUES (109, 11, 5);
INSERT INTO public.word_semantic VALUES (114, 12, 1);
INSERT INTO public.word_semantic VALUES (115, 12, 2);
INSERT INTO public.word_semantic VALUES (116, 12, 3);
INSERT INTO public.word_semantic VALUES (117, 12, 4);
INSERT INTO public.word_semantic VALUES (118, 12, 5);
INSERT INTO public.word_semantic VALUES (123, 13, 1);
INSERT INTO public.word_semantic VALUES (124, 13, 2);
INSERT INTO public.word_semantic VALUES (125, 13, 3);
INSERT INTO public.word_semantic VALUES (126, 13, 4);
INSERT INTO public.word_semantic VALUES (127, 13, 5);
INSERT INTO public.word_semantic VALUES (132, 14, 1);
INSERT INTO public.word_semantic VALUES (133, 14, 2);
INSERT INTO public.word_semantic VALUES (134, 14, 3);
INSERT INTO public.word_semantic VALUES (135, 14, 4);
INSERT INTO public.word_semantic VALUES (136, 14, 5);
INSERT INTO public.word_semantic VALUES (141, 15, 1);
INSERT INTO public.word_semantic VALUES (142, 15, 2);
INSERT INTO public.word_semantic VALUES (143, 15, 6);
INSERT INTO public.word_semantic VALUES (144, 15, 4);
INSERT INTO public.word_semantic VALUES (145, 15, 5);
INSERT INTO public.word_semantic VALUES (150, 16, 1);
INSERT INTO public.word_semantic VALUES (151, 16, 2);
INSERT INTO public.word_semantic VALUES (152, 16, 6);
INSERT INTO public.word_semantic VALUES (153, 16, 4);
INSERT INTO public.word_semantic VALUES (154, 16, 5);
INSERT INTO public.word_semantic VALUES (159, 17, 1);
INSERT INTO public.word_semantic VALUES (160, 17, 2);
INSERT INTO public.word_semantic VALUES (161, 17, 6);
INSERT INTO public.word_semantic VALUES (162, 17, 4);
INSERT INTO public.word_semantic VALUES (163, 17, 5);
INSERT INTO public.word_semantic VALUES (168, 18, 1);
INSERT INTO public.word_semantic VALUES (169, 18, 2);
INSERT INTO public.word_semantic VALUES (170, 18, 3);
INSERT INTO public.word_semantic VALUES (171, 18, 4);
INSERT INTO public.word_semantic VALUES (172, 18, 5);
INSERT INTO public.word_semantic VALUES (177, 19, 1);
INSERT INTO public.word_semantic VALUES (178, 19, 2);
INSERT INTO public.word_semantic VALUES (179, 19, 3);
INSERT INTO public.word_semantic VALUES (180, 19, 4);
INSERT INTO public.word_semantic VALUES (181, 19, 5);
INSERT INTO public.word_semantic VALUES (186, 20, 1);
INSERT INTO public.word_semantic VALUES (187, 20, 2);
INSERT INTO public.word_semantic VALUES (188, 20, 3);
INSERT INTO public.word_semantic VALUES (189, 20, 4);
INSERT INTO public.word_semantic VALUES (190, 20, 5);
INSERT INTO public.word_semantic VALUES (195, 21, 1);
INSERT INTO public.word_semantic VALUES (196, 21, 2);
INSERT INTO public.word_semantic VALUES (197, 21, 3);
INSERT INTO public.word_semantic VALUES (198, 21, 4);
INSERT INTO public.word_semantic VALUES (199, 21, 5);
INSERT INTO public.word_semantic VALUES (204, 22, 1);
INSERT INTO public.word_semantic VALUES (205, 22, 2);
INSERT INTO public.word_semantic VALUES (206, 22, 3);
INSERT INTO public.word_semantic VALUES (207, 22, 4);
INSERT INTO public.word_semantic VALUES (208, 22, 5);
INSERT INTO public.word_semantic VALUES (213, 23, 1);
INSERT INTO public.word_semantic VALUES (214, 23, 2);
INSERT INTO public.word_semantic VALUES (215, 23, 3);
INSERT INTO public.word_semantic VALUES (216, 23, 4);
INSERT INTO public.word_semantic VALUES (217, 23, 5);
INSERT INTO public.word_semantic VALUES (222, 24, 1);
INSERT INTO public.word_semantic VALUES (223, 24, 2);
INSERT INTO public.word_semantic VALUES (224, 24, 3);
INSERT INTO public.word_semantic VALUES (225, 24, 4);
INSERT INTO public.word_semantic VALUES (226, 24, 5);
INSERT INTO public.word_semantic VALUES (231, 25, 1);
INSERT INTO public.word_semantic VALUES (232, 25, 2);
INSERT INTO public.word_semantic VALUES (233, 25, 3);
INSERT INTO public.word_semantic VALUES (234, 25, 4);
INSERT INTO public.word_semantic VALUES (235, 25, 5);
INSERT INTO public.word_semantic VALUES (238, 26, 7);
INSERT INTO public.word_semantic VALUES (239, 26, 8);
INSERT INTO public.word_semantic VALUES (240, 26, 9);
INSERT INTO public.word_semantic VALUES (241, 26, 10);
INSERT INTO public.word_semantic VALUES (242, 26, 11);
INSERT INTO public.word_semantic VALUES (243, 26, 12);
INSERT INTO public.word_semantic VALUES (244, 26, 13);
INSERT INTO public.word_semantic VALUES (245, 26, 14);
INSERT INTO public.word_semantic VALUES (246, 26, 15);
INSERT INTO public.word_semantic VALUES (249, 27, 7);
INSERT INTO public.word_semantic VALUES (250, 27, 8);
INSERT INTO public.word_semantic VALUES (251, 27, 9);
INSERT INTO public.word_semantic VALUES (252, 27, 10);
INSERT INTO public.word_semantic VALUES (253, 27, 11);
INSERT INTO public.word_semantic VALUES (254, 27, 12);
INSERT INTO public.word_semantic VALUES (255, 27, 13);
INSERT INTO public.word_semantic VALUES (256, 27, 14);
INSERT INTO public.word_semantic VALUES (257, 27, 16);
INSERT INTO public.word_semantic VALUES (258, 27, 15);
INSERT INTO public.word_semantic VALUES (261, 28, 7);
INSERT INTO public.word_semantic VALUES (262, 28, 8);
INSERT INTO public.word_semantic VALUES (263, 28, 9);
INSERT INTO public.word_semantic VALUES (264, 28, 10);
INSERT INTO public.word_semantic VALUES (265, 28, 11);
INSERT INTO public.word_semantic VALUES (266, 28, 12);
INSERT INTO public.word_semantic VALUES (267, 28, 13);
INSERT INTO public.word_semantic VALUES (268, 28, 14);
INSERT INTO public.word_semantic VALUES (269, 28, 15);
INSERT INTO public.word_semantic VALUES (272, 29, 7);
INSERT INTO public.word_semantic VALUES (273, 29, 8);
INSERT INTO public.word_semantic VALUES (274, 29, 9);
INSERT INTO public.word_semantic VALUES (275, 29, 10);
INSERT INTO public.word_semantic VALUES (276, 29, 11);
INSERT INTO public.word_semantic VALUES (277, 29, 12);
INSERT INTO public.word_semantic VALUES (278, 29, 13);
INSERT INTO public.word_semantic VALUES (279, 29, 14);
INSERT INTO public.word_semantic VALUES (280, 29, 16);
INSERT INTO public.word_semantic VALUES (281, 29, 15);
INSERT INTO public.word_semantic VALUES (284, 30, 7);
INSERT INTO public.word_semantic VALUES (285, 30, 8);
INSERT INTO public.word_semantic VALUES (286, 30, 9);
INSERT INTO public.word_semantic VALUES (287, 30, 11);
INSERT INTO public.word_semantic VALUES (288, 30, 12);
INSERT INTO public.word_semantic VALUES (289, 30, 13);
INSERT INTO public.word_semantic VALUES (290, 30, 17);
INSERT INTO public.word_semantic VALUES (291, 30, 15);
INSERT INTO public.word_semantic VALUES (4763, 659, 52);
INSERT INTO public.word_semantic VALUES (294, 31, 7);
INSERT INTO public.word_semantic VALUES (295, 31, 8);
INSERT INTO public.word_semantic VALUES (296, 31, 9);
INSERT INTO public.word_semantic VALUES (297, 31, 11);
INSERT INTO public.word_semantic VALUES (298, 31, 12);
INSERT INTO public.word_semantic VALUES (299, 31, 13);
INSERT INTO public.word_semantic VALUES (300, 31, 17);
INSERT INTO public.word_semantic VALUES (301, 31, 15);
INSERT INTO public.word_semantic VALUES (304, 32, 7);
INSERT INTO public.word_semantic VALUES (305, 32, 8);
INSERT INTO public.word_semantic VALUES (306, 32, 9);
INSERT INTO public.word_semantic VALUES (307, 32, 11);
INSERT INTO public.word_semantic VALUES (308, 32, 12);
INSERT INTO public.word_semantic VALUES (309, 32, 13);
INSERT INTO public.word_semantic VALUES (310, 32, 17);
INSERT INTO public.word_semantic VALUES (311, 32, 15);
INSERT INTO public.word_semantic VALUES (314, 33, 7);
INSERT INTO public.word_semantic VALUES (315, 33, 8);
INSERT INTO public.word_semantic VALUES (316, 33, 9);
INSERT INTO public.word_semantic VALUES (317, 33, 11);
INSERT INTO public.word_semantic VALUES (318, 33, 12);
INSERT INTO public.word_semantic VALUES (319, 33, 13);
INSERT INTO public.word_semantic VALUES (320, 33, 17);
INSERT INTO public.word_semantic VALUES (321, 33, 15);
INSERT INTO public.word_semantic VALUES (324, 34, 7);
INSERT INTO public.word_semantic VALUES (325, 34, 8);
INSERT INTO public.word_semantic VALUES (326, 34, 9);
INSERT INTO public.word_semantic VALUES (327, 34, 11);
INSERT INTO public.word_semantic VALUES (328, 34, 12);
INSERT INTO public.word_semantic VALUES (329, 34, 13);
INSERT INTO public.word_semantic VALUES (330, 34, 17);
INSERT INTO public.word_semantic VALUES (331, 34, 15);
INSERT INTO public.word_semantic VALUES (334, 35, 7);
INSERT INTO public.word_semantic VALUES (335, 35, 8);
INSERT INTO public.word_semantic VALUES (336, 35, 9);
INSERT INTO public.word_semantic VALUES (337, 35, 11);
INSERT INTO public.word_semantic VALUES (338, 35, 12);
INSERT INTO public.word_semantic VALUES (339, 35, 13);
INSERT INTO public.word_semantic VALUES (340, 35, 17);
INSERT INTO public.word_semantic VALUES (341, 35, 15);
INSERT INTO public.word_semantic VALUES (370, 36, 7);
INSERT INTO public.word_semantic VALUES (371, 36, 8);
INSERT INTO public.word_semantic VALUES (372, 36, 9);
INSERT INTO public.word_semantic VALUES (373, 36, 11);
INSERT INTO public.word_semantic VALUES (374, 36, 12);
INSERT INTO public.word_semantic VALUES (375, 36, 13);
INSERT INTO public.word_semantic VALUES (376, 36, 17);
INSERT INTO public.word_semantic VALUES (377, 36, 15);
INSERT INTO public.word_semantic VALUES (386, 37, 7);
INSERT INTO public.word_semantic VALUES (387, 37, 8);
INSERT INTO public.word_semantic VALUES (388, 37, 9);
INSERT INTO public.word_semantic VALUES (389, 37, 11);
INSERT INTO public.word_semantic VALUES (390, 37, 12);
INSERT INTO public.word_semantic VALUES (391, 37, 13);
INSERT INTO public.word_semantic VALUES (392, 37, 17);
INSERT INTO public.word_semantic VALUES (393, 37, 15);
INSERT INTO public.word_semantic VALUES (396, 38, 7);
INSERT INTO public.word_semantic VALUES (397, 38, 8);
INSERT INTO public.word_semantic VALUES (398, 38, 9);
INSERT INTO public.word_semantic VALUES (399, 38, 10);
INSERT INTO public.word_semantic VALUES (400, 38, 11);
INSERT INTO public.word_semantic VALUES (401, 38, 12);
INSERT INTO public.word_semantic VALUES (402, 38, 13);
INSERT INTO public.word_semantic VALUES (403, 38, 17);
INSERT INTO public.word_semantic VALUES (404, 38, 15);
INSERT INTO public.word_semantic VALUES (407, 39, 7);
INSERT INTO public.word_semantic VALUES (408, 39, 8);
INSERT INTO public.word_semantic VALUES (409, 39, 9);
INSERT INTO public.word_semantic VALUES (410, 39, 10);
INSERT INTO public.word_semantic VALUES (411, 39, 11);
INSERT INTO public.word_semantic VALUES (412, 39, 12);
INSERT INTO public.word_semantic VALUES (413, 39, 13);
INSERT INTO public.word_semantic VALUES (414, 39, 17);
INSERT INTO public.word_semantic VALUES (415, 39, 15);
INSERT INTO public.word_semantic VALUES (418, 40, 7);
INSERT INTO public.word_semantic VALUES (419, 40, 8);
INSERT INTO public.word_semantic VALUES (420, 40, 9);
INSERT INTO public.word_semantic VALUES (421, 40, 10);
INSERT INTO public.word_semantic VALUES (422, 40, 11);
INSERT INTO public.word_semantic VALUES (423, 40, 12);
INSERT INTO public.word_semantic VALUES (424, 40, 13);
INSERT INTO public.word_semantic VALUES (425, 40, 17);
INSERT INTO public.word_semantic VALUES (426, 40, 15);
INSERT INTO public.word_semantic VALUES (429, 41, 7);
INSERT INTO public.word_semantic VALUES (430, 41, 8);
INSERT INTO public.word_semantic VALUES (431, 41, 9);
INSERT INTO public.word_semantic VALUES (432, 41, 10);
INSERT INTO public.word_semantic VALUES (433, 41, 11);
INSERT INTO public.word_semantic VALUES (434, 41, 12);
INSERT INTO public.word_semantic VALUES (435, 41, 13);
INSERT INTO public.word_semantic VALUES (436, 41, 14);
INSERT INTO public.word_semantic VALUES (437, 41, 17);
INSERT INTO public.word_semantic VALUES (438, 41, 15);
INSERT INTO public.word_semantic VALUES (441, 42, 7);
INSERT INTO public.word_semantic VALUES (442, 42, 8);
INSERT INTO public.word_semantic VALUES (443, 42, 9);
INSERT INTO public.word_semantic VALUES (444, 42, 10);
INSERT INTO public.word_semantic VALUES (445, 42, 11);
INSERT INTO public.word_semantic VALUES (446, 42, 12);
INSERT INTO public.word_semantic VALUES (447, 42, 13);
INSERT INTO public.word_semantic VALUES (448, 42, 17);
INSERT INTO public.word_semantic VALUES (449, 42, 18);
INSERT INTO public.word_semantic VALUES (450, 42, 15);
INSERT INTO public.word_semantic VALUES (453, 43, 7);
INSERT INTO public.word_semantic VALUES (454, 43, 8);
INSERT INTO public.word_semantic VALUES (455, 43, 9);
INSERT INTO public.word_semantic VALUES (456, 43, 10);
INSERT INTO public.word_semantic VALUES (457, 43, 11);
INSERT INTO public.word_semantic VALUES (458, 43, 12);
INSERT INTO public.word_semantic VALUES (459, 43, 13);
INSERT INTO public.word_semantic VALUES (460, 43, 17);
INSERT INTO public.word_semantic VALUES (461, 43, 18);
INSERT INTO public.word_semantic VALUES (462, 43, 15);
INSERT INTO public.word_semantic VALUES (465, 44, 7);
INSERT INTO public.word_semantic VALUES (466, 44, 8);
INSERT INTO public.word_semantic VALUES (467, 44, 9);
INSERT INTO public.word_semantic VALUES (468, 44, 10);
INSERT INTO public.word_semantic VALUES (469, 44, 11);
INSERT INTO public.word_semantic VALUES (470, 44, 12);
INSERT INTO public.word_semantic VALUES (471, 44, 13);
INSERT INTO public.word_semantic VALUES (472, 44, 17);
INSERT INTO public.word_semantic VALUES (473, 44, 18);
INSERT INTO public.word_semantic VALUES (474, 44, 15);
INSERT INTO public.word_semantic VALUES (477, 45, 7);
INSERT INTO public.word_semantic VALUES (478, 45, 8);
INSERT INTO public.word_semantic VALUES (479, 45, 9);
INSERT INTO public.word_semantic VALUES (480, 45, 10);
INSERT INTO public.word_semantic VALUES (481, 45, 11);
INSERT INTO public.word_semantic VALUES (482, 45, 12);
INSERT INTO public.word_semantic VALUES (483, 45, 13);
INSERT INTO public.word_semantic VALUES (484, 45, 17);
INSERT INTO public.word_semantic VALUES (485, 45, 18);
INSERT INTO public.word_semantic VALUES (486, 45, 15);
INSERT INTO public.word_semantic VALUES (489, 46, 7);
INSERT INTO public.word_semantic VALUES (490, 46, 8);
INSERT INTO public.word_semantic VALUES (491, 46, 9);
INSERT INTO public.word_semantic VALUES (492, 46, 10);
INSERT INTO public.word_semantic VALUES (493, 46, 11);
INSERT INTO public.word_semantic VALUES (494, 46, 12);
INSERT INTO public.word_semantic VALUES (495, 46, 13);
INSERT INTO public.word_semantic VALUES (496, 46, 17);
INSERT INTO public.word_semantic VALUES (497, 46, 18);
INSERT INTO public.word_semantic VALUES (498, 46, 15);
INSERT INTO public.word_semantic VALUES (501, 47, 7);
INSERT INTO public.word_semantic VALUES (502, 47, 8);
INSERT INTO public.word_semantic VALUES (503, 47, 9);
INSERT INTO public.word_semantic VALUES (504, 47, 10);
INSERT INTO public.word_semantic VALUES (505, 47, 11);
INSERT INTO public.word_semantic VALUES (506, 47, 12);
INSERT INTO public.word_semantic VALUES (507, 47, 13);
INSERT INTO public.word_semantic VALUES (508, 47, 17);
INSERT INTO public.word_semantic VALUES (509, 47, 18);
INSERT INTO public.word_semantic VALUES (510, 47, 15);
INSERT INTO public.word_semantic VALUES (513, 48, 7);
INSERT INTO public.word_semantic VALUES (514, 48, 8);
INSERT INTO public.word_semantic VALUES (515, 48, 9);
INSERT INTO public.word_semantic VALUES (516, 48, 10);
INSERT INTO public.word_semantic VALUES (517, 48, 11);
INSERT INTO public.word_semantic VALUES (518, 48, 12);
INSERT INTO public.word_semantic VALUES (519, 48, 13);
INSERT INTO public.word_semantic VALUES (520, 48, 17);
INSERT INTO public.word_semantic VALUES (521, 48, 18);
INSERT INTO public.word_semantic VALUES (522, 48, 15);
INSERT INTO public.word_semantic VALUES (525, 49, 7);
INSERT INTO public.word_semantic VALUES (526, 49, 8);
INSERT INTO public.word_semantic VALUES (527, 49, 9);
INSERT INTO public.word_semantic VALUES (528, 49, 10);
INSERT INTO public.word_semantic VALUES (529, 49, 11);
INSERT INTO public.word_semantic VALUES (530, 49, 12);
INSERT INTO public.word_semantic VALUES (531, 49, 13);
INSERT INTO public.word_semantic VALUES (532, 49, 17);
INSERT INTO public.word_semantic VALUES (533, 49, 18);
INSERT INTO public.word_semantic VALUES (534, 49, 15);
INSERT INTO public.word_semantic VALUES (537, 50, 7);
INSERT INTO public.word_semantic VALUES (538, 50, 8);
INSERT INTO public.word_semantic VALUES (539, 50, 9);
INSERT INTO public.word_semantic VALUES (540, 50, 10);
INSERT INTO public.word_semantic VALUES (541, 50, 11);
INSERT INTO public.word_semantic VALUES (542, 50, 12);
INSERT INTO public.word_semantic VALUES (543, 50, 13);
INSERT INTO public.word_semantic VALUES (544, 50, 17);
INSERT INTO public.word_semantic VALUES (545, 50, 15);
INSERT INTO public.word_semantic VALUES (4765, 660, 67);
INSERT INTO public.word_semantic VALUES (4766, 660, 52);
INSERT INTO public.word_semantic VALUES (548, 51, 7);
INSERT INTO public.word_semantic VALUES (549, 51, 8);
INSERT INTO public.word_semantic VALUES (550, 51, 9);
INSERT INTO public.word_semantic VALUES (551, 51, 10);
INSERT INTO public.word_semantic VALUES (552, 51, 11);
INSERT INTO public.word_semantic VALUES (553, 51, 12);
INSERT INTO public.word_semantic VALUES (554, 51, 13);
INSERT INTO public.word_semantic VALUES (555, 51, 17);
INSERT INTO public.word_semantic VALUES (556, 51, 19);
INSERT INTO public.word_semantic VALUES (557, 51, 15);
INSERT INTO public.word_semantic VALUES (560, 52, 7);
INSERT INTO public.word_semantic VALUES (561, 52, 8);
INSERT INTO public.word_semantic VALUES (562, 52, 9);
INSERT INTO public.word_semantic VALUES (563, 52, 10);
INSERT INTO public.word_semantic VALUES (564, 52, 11);
INSERT INTO public.word_semantic VALUES (565, 52, 12);
INSERT INTO public.word_semantic VALUES (566, 52, 13);
INSERT INTO public.word_semantic VALUES (567, 52, 20);
INSERT INTO public.word_semantic VALUES (568, 52, 15);
INSERT INTO public.word_semantic VALUES (571, 53, 7);
INSERT INTO public.word_semantic VALUES (572, 53, 8);
INSERT INTO public.word_semantic VALUES (573, 53, 9);
INSERT INTO public.word_semantic VALUES (574, 53, 10);
INSERT INTO public.word_semantic VALUES (575, 53, 11);
INSERT INTO public.word_semantic VALUES (576, 53, 12);
INSERT INTO public.word_semantic VALUES (577, 53, 13);
INSERT INTO public.word_semantic VALUES (578, 53, 20);
INSERT INTO public.word_semantic VALUES (579, 53, 15);
INSERT INTO public.word_semantic VALUES (582, 54, 7);
INSERT INTO public.word_semantic VALUES (583, 54, 8);
INSERT INTO public.word_semantic VALUES (584, 54, 9);
INSERT INTO public.word_semantic VALUES (585, 54, 10);
INSERT INTO public.word_semantic VALUES (586, 54, 11);
INSERT INTO public.word_semantic VALUES (587, 54, 12);
INSERT INTO public.word_semantic VALUES (588, 54, 13);
INSERT INTO public.word_semantic VALUES (589, 54, 20);
INSERT INTO public.word_semantic VALUES (590, 54, 15);
INSERT INTO public.word_semantic VALUES (593, 55, 7);
INSERT INTO public.word_semantic VALUES (594, 55, 8);
INSERT INTO public.word_semantic VALUES (595, 55, 9);
INSERT INTO public.word_semantic VALUES (596, 55, 10);
INSERT INTO public.word_semantic VALUES (597, 55, 11);
INSERT INTO public.word_semantic VALUES (598, 55, 12);
INSERT INTO public.word_semantic VALUES (599, 55, 13);
INSERT INTO public.word_semantic VALUES (600, 55, 20);
INSERT INTO public.word_semantic VALUES (601, 55, 15);
INSERT INTO public.word_semantic VALUES (604, 56, 7);
INSERT INTO public.word_semantic VALUES (605, 56, 8);
INSERT INTO public.word_semantic VALUES (606, 56, 9);
INSERT INTO public.word_semantic VALUES (607, 56, 10);
INSERT INTO public.word_semantic VALUES (608, 56, 11);
INSERT INTO public.word_semantic VALUES (609, 56, 12);
INSERT INTO public.word_semantic VALUES (610, 56, 13);
INSERT INTO public.word_semantic VALUES (611, 56, 20);
INSERT INTO public.word_semantic VALUES (612, 56, 15);
INSERT INTO public.word_semantic VALUES (615, 57, 7);
INSERT INTO public.word_semantic VALUES (616, 57, 8);
INSERT INTO public.word_semantic VALUES (617, 57, 9);
INSERT INTO public.word_semantic VALUES (618, 57, 10);
INSERT INTO public.word_semantic VALUES (619, 57, 11);
INSERT INTO public.word_semantic VALUES (620, 57, 12);
INSERT INTO public.word_semantic VALUES (621, 57, 13);
INSERT INTO public.word_semantic VALUES (622, 57, 20);
INSERT INTO public.word_semantic VALUES (623, 57, 15);
INSERT INTO public.word_semantic VALUES (626, 58, 7);
INSERT INTO public.word_semantic VALUES (627, 58, 8);
INSERT INTO public.word_semantic VALUES (628, 58, 9);
INSERT INTO public.word_semantic VALUES (629, 58, 10);
INSERT INTO public.word_semantic VALUES (630, 58, 11);
INSERT INTO public.word_semantic VALUES (631, 58, 12);
INSERT INTO public.word_semantic VALUES (632, 58, 13);
INSERT INTO public.word_semantic VALUES (633, 58, 20);
INSERT INTO public.word_semantic VALUES (634, 58, 15);
INSERT INTO public.word_semantic VALUES (637, 59, 7);
INSERT INTO public.word_semantic VALUES (638, 59, 8);
INSERT INTO public.word_semantic VALUES (639, 59, 9);
INSERT INTO public.word_semantic VALUES (640, 59, 10);
INSERT INTO public.word_semantic VALUES (641, 59, 11);
INSERT INTO public.word_semantic VALUES (642, 59, 12);
INSERT INTO public.word_semantic VALUES (643, 59, 13);
INSERT INTO public.word_semantic VALUES (644, 59, 20);
INSERT INTO public.word_semantic VALUES (645, 59, 15);
INSERT INTO public.word_semantic VALUES (648, 60, 7);
INSERT INTO public.word_semantic VALUES (649, 60, 8);
INSERT INTO public.word_semantic VALUES (650, 60, 9);
INSERT INTO public.word_semantic VALUES (651, 60, 10);
INSERT INTO public.word_semantic VALUES (652, 60, 11);
INSERT INTO public.word_semantic VALUES (653, 60, 12);
INSERT INTO public.word_semantic VALUES (654, 60, 13);
INSERT INTO public.word_semantic VALUES (655, 60, 14);
INSERT INTO public.word_semantic VALUES (656, 60, 15);
INSERT INTO public.word_semantic VALUES (659, 61, 7);
INSERT INTO public.word_semantic VALUES (660, 61, 8);
INSERT INTO public.word_semantic VALUES (661, 61, 9);
INSERT INTO public.word_semantic VALUES (662, 61, 10);
INSERT INTO public.word_semantic VALUES (663, 61, 11);
INSERT INTO public.word_semantic VALUES (664, 61, 12);
INSERT INTO public.word_semantic VALUES (665, 61, 13);
INSERT INTO public.word_semantic VALUES (666, 61, 14);
INSERT INTO public.word_semantic VALUES (667, 61, 15);
INSERT INTO public.word_semantic VALUES (670, 62, 7);
INSERT INTO public.word_semantic VALUES (671, 62, 8);
INSERT INTO public.word_semantic VALUES (672, 62, 9);
INSERT INTO public.word_semantic VALUES (673, 62, 21);
INSERT INTO public.word_semantic VALUES (674, 62, 11);
INSERT INTO public.word_semantic VALUES (675, 62, 12);
INSERT INTO public.word_semantic VALUES (676, 62, 22);
INSERT INTO public.word_semantic VALUES (677, 62, 17);
INSERT INTO public.word_semantic VALUES (678, 62, 15);
INSERT INTO public.word_semantic VALUES (681, 63, 7);
INSERT INTO public.word_semantic VALUES (682, 63, 8);
INSERT INTO public.word_semantic VALUES (683, 63, 9);
INSERT INTO public.word_semantic VALUES (684, 63, 21);
INSERT INTO public.word_semantic VALUES (685, 63, 11);
INSERT INTO public.word_semantic VALUES (686, 63, 12);
INSERT INTO public.word_semantic VALUES (687, 63, 22);
INSERT INTO public.word_semantic VALUES (688, 63, 17);
INSERT INTO public.word_semantic VALUES (689, 63, 15);
INSERT INTO public.word_semantic VALUES (692, 64, 7);
INSERT INTO public.word_semantic VALUES (693, 64, 8);
INSERT INTO public.word_semantic VALUES (694, 64, 9);
INSERT INTO public.word_semantic VALUES (695, 64, 21);
INSERT INTO public.word_semantic VALUES (696, 64, 11);
INSERT INTO public.word_semantic VALUES (697, 64, 12);
INSERT INTO public.word_semantic VALUES (698, 64, 22);
INSERT INTO public.word_semantic VALUES (699, 64, 17);
INSERT INTO public.word_semantic VALUES (700, 64, 15);
INSERT INTO public.word_semantic VALUES (703, 65, 7);
INSERT INTO public.word_semantic VALUES (704, 65, 8);
INSERT INTO public.word_semantic VALUES (705, 65, 9);
INSERT INTO public.word_semantic VALUES (706, 65, 21);
INSERT INTO public.word_semantic VALUES (707, 65, 11);
INSERT INTO public.word_semantic VALUES (708, 65, 12);
INSERT INTO public.word_semantic VALUES (709, 65, 22);
INSERT INTO public.word_semantic VALUES (710, 65, 17);
INSERT INTO public.word_semantic VALUES (711, 65, 15);
INSERT INTO public.word_semantic VALUES (714, 66, 7);
INSERT INTO public.word_semantic VALUES (715, 66, 8);
INSERT INTO public.word_semantic VALUES (716, 66, 9);
INSERT INTO public.word_semantic VALUES (717, 66, 11);
INSERT INTO public.word_semantic VALUES (718, 66, 23);
INSERT INTO public.word_semantic VALUES (719, 66, 24);
INSERT INTO public.word_semantic VALUES (720, 66, 14);
INSERT INTO public.word_semantic VALUES (721, 66, 15);
INSERT INTO public.word_semantic VALUES (724, 67, 7);
INSERT INTO public.word_semantic VALUES (725, 67, 8);
INSERT INTO public.word_semantic VALUES (726, 67, 9);
INSERT INTO public.word_semantic VALUES (727, 67, 11);
INSERT INTO public.word_semantic VALUES (728, 67, 23);
INSERT INTO public.word_semantic VALUES (729, 67, 24);
INSERT INTO public.word_semantic VALUES (730, 67, 14);
INSERT INTO public.word_semantic VALUES (731, 67, 15);
INSERT INTO public.word_semantic VALUES (734, 68, 7);
INSERT INTO public.word_semantic VALUES (735, 68, 8);
INSERT INTO public.word_semantic VALUES (736, 68, 9);
INSERT INTO public.word_semantic VALUES (737, 68, 25);
INSERT INTO public.word_semantic VALUES (738, 68, 26);
INSERT INTO public.word_semantic VALUES (739, 68, 27);
INSERT INTO public.word_semantic VALUES (740, 68, 20);
INSERT INTO public.word_semantic VALUES (741, 68, 15);
INSERT INTO public.word_semantic VALUES (744, 69, 7);
INSERT INTO public.word_semantic VALUES (745, 69, 8);
INSERT INTO public.word_semantic VALUES (746, 69, 9);
INSERT INTO public.word_semantic VALUES (747, 69, 25);
INSERT INTO public.word_semantic VALUES (748, 69, 26);
INSERT INTO public.word_semantic VALUES (749, 69, 27);
INSERT INTO public.word_semantic VALUES (750, 69, 20);
INSERT INTO public.word_semantic VALUES (751, 69, 15);
INSERT INTO public.word_semantic VALUES (754, 70, 7);
INSERT INTO public.word_semantic VALUES (755, 70, 8);
INSERT INTO public.word_semantic VALUES (756, 70, 9);
INSERT INTO public.word_semantic VALUES (757, 70, 25);
INSERT INTO public.word_semantic VALUES (758, 70, 26);
INSERT INTO public.word_semantic VALUES (759, 70, 27);
INSERT INTO public.word_semantic VALUES (760, 70, 14);
INSERT INTO public.word_semantic VALUES (761, 70, 15);
INSERT INTO public.word_semantic VALUES (4768, 661, 67);
INSERT INTO public.word_semantic VALUES (764, 71, 7);
INSERT INTO public.word_semantic VALUES (765, 71, 8);
INSERT INTO public.word_semantic VALUES (766, 71, 9);
INSERT INTO public.word_semantic VALUES (767, 71, 25);
INSERT INTO public.word_semantic VALUES (768, 71, 26);
INSERT INTO public.word_semantic VALUES (769, 71, 27);
INSERT INTO public.word_semantic VALUES (770, 71, 14);
INSERT INTO public.word_semantic VALUES (771, 71, 15);
INSERT INTO public.word_semantic VALUES (774, 72, 7);
INSERT INTO public.word_semantic VALUES (775, 72, 8);
INSERT INTO public.word_semantic VALUES (776, 72, 9);
INSERT INTO public.word_semantic VALUES (777, 72, 25);
INSERT INTO public.word_semantic VALUES (778, 72, 26);
INSERT INTO public.word_semantic VALUES (779, 72, 27);
INSERT INTO public.word_semantic VALUES (780, 72, 14);
INSERT INTO public.word_semantic VALUES (781, 72, 15);
INSERT INTO public.word_semantic VALUES (784, 73, 7);
INSERT INTO public.word_semantic VALUES (785, 73, 8);
INSERT INTO public.word_semantic VALUES (786, 73, 9);
INSERT INTO public.word_semantic VALUES (787, 73, 25);
INSERT INTO public.word_semantic VALUES (788, 73, 26);
INSERT INTO public.word_semantic VALUES (789, 73, 27);
INSERT INTO public.word_semantic VALUES (790, 73, 14);
INSERT INTO public.word_semantic VALUES (791, 73, 15);
INSERT INTO public.word_semantic VALUES (794, 74, 7);
INSERT INTO public.word_semantic VALUES (795, 74, 8);
INSERT INTO public.word_semantic VALUES (796, 74, 9);
INSERT INTO public.word_semantic VALUES (797, 74, 25);
INSERT INTO public.word_semantic VALUES (798, 74, 26);
INSERT INTO public.word_semantic VALUES (799, 74, 14);
INSERT INTO public.word_semantic VALUES (800, 74, 15);
INSERT INTO public.word_semantic VALUES (803, 75, 7);
INSERT INTO public.word_semantic VALUES (804, 75, 8);
INSERT INTO public.word_semantic VALUES (805, 75, 9);
INSERT INTO public.word_semantic VALUES (806, 75, 25);
INSERT INTO public.word_semantic VALUES (807, 75, 26);
INSERT INTO public.word_semantic VALUES (808, 75, 14);
INSERT INTO public.word_semantic VALUES (809, 75, 15);
INSERT INTO public.word_semantic VALUES (812, 76, 7);
INSERT INTO public.word_semantic VALUES (813, 76, 8);
INSERT INTO public.word_semantic VALUES (814, 76, 9);
INSERT INTO public.word_semantic VALUES (815, 76, 25);
INSERT INTO public.word_semantic VALUES (816, 76, 26);
INSERT INTO public.word_semantic VALUES (817, 76, 14);
INSERT INTO public.word_semantic VALUES (818, 76, 15);
INSERT INTO public.word_semantic VALUES (821, 77, 7);
INSERT INTO public.word_semantic VALUES (822, 77, 8);
INSERT INTO public.word_semantic VALUES (823, 77, 9);
INSERT INTO public.word_semantic VALUES (824, 77, 25);
INSERT INTO public.word_semantic VALUES (825, 77, 26);
INSERT INTO public.word_semantic VALUES (826, 77, 14);
INSERT INTO public.word_semantic VALUES (827, 77, 15);
INSERT INTO public.word_semantic VALUES (830, 78, 7);
INSERT INTO public.word_semantic VALUES (831, 78, 8);
INSERT INTO public.word_semantic VALUES (832, 78, 9);
INSERT INTO public.word_semantic VALUES (833, 78, 25);
INSERT INTO public.word_semantic VALUES (834, 78, 26);
INSERT INTO public.word_semantic VALUES (835, 78, 14);
INSERT INTO public.word_semantic VALUES (836, 78, 15);
INSERT INTO public.word_semantic VALUES (839, 79, 7);
INSERT INTO public.word_semantic VALUES (840, 79, 8);
INSERT INTO public.word_semantic VALUES (841, 79, 9);
INSERT INTO public.word_semantic VALUES (842, 79, 25);
INSERT INTO public.word_semantic VALUES (843, 79, 26);
INSERT INTO public.word_semantic VALUES (844, 79, 14);
INSERT INTO public.word_semantic VALUES (845, 79, 15);
INSERT INTO public.word_semantic VALUES (848, 80, 7);
INSERT INTO public.word_semantic VALUES (849, 80, 8);
INSERT INTO public.word_semantic VALUES (850, 80, 9);
INSERT INTO public.word_semantic VALUES (851, 80, 11);
INSERT INTO public.word_semantic VALUES (852, 80, 23);
INSERT INTO public.word_semantic VALUES (853, 80, 24);
INSERT INTO public.word_semantic VALUES (854, 80, 14);
INSERT INTO public.word_semantic VALUES (855, 80, 15);
INSERT INTO public.word_semantic VALUES (858, 81, 7);
INSERT INTO public.word_semantic VALUES (859, 81, 8);
INSERT INTO public.word_semantic VALUES (860, 81, 9);
INSERT INTO public.word_semantic VALUES (861, 81, 11);
INSERT INTO public.word_semantic VALUES (862, 81, 23);
INSERT INTO public.word_semantic VALUES (863, 81, 24);
INSERT INTO public.word_semantic VALUES (864, 81, 14);
INSERT INTO public.word_semantic VALUES (865, 81, 15);
INSERT INTO public.word_semantic VALUES (868, 82, 7);
INSERT INTO public.word_semantic VALUES (869, 82, 8);
INSERT INTO public.word_semantic VALUES (870, 82, 9);
INSERT INTO public.word_semantic VALUES (871, 82, 11);
INSERT INTO public.word_semantic VALUES (872, 82, 23);
INSERT INTO public.word_semantic VALUES (873, 82, 24);
INSERT INTO public.word_semantic VALUES (874, 82, 14);
INSERT INTO public.word_semantic VALUES (875, 82, 15);
INSERT INTO public.word_semantic VALUES (878, 83, 7);
INSERT INTO public.word_semantic VALUES (879, 83, 8);
INSERT INTO public.word_semantic VALUES (880, 83, 9);
INSERT INTO public.word_semantic VALUES (881, 83, 11);
INSERT INTO public.word_semantic VALUES (882, 83, 23);
INSERT INTO public.word_semantic VALUES (883, 83, 24);
INSERT INTO public.word_semantic VALUES (884, 83, 14);
INSERT INTO public.word_semantic VALUES (885, 83, 15);
INSERT INTO public.word_semantic VALUES (888, 84, 7);
INSERT INTO public.word_semantic VALUES (889, 84, 8);
INSERT INTO public.word_semantic VALUES (890, 84, 9);
INSERT INTO public.word_semantic VALUES (891, 84, 11);
INSERT INTO public.word_semantic VALUES (892, 84, 23);
INSERT INTO public.word_semantic VALUES (893, 84, 24);
INSERT INTO public.word_semantic VALUES (894, 84, 14);
INSERT INTO public.word_semantic VALUES (895, 84, 15);
INSERT INTO public.word_semantic VALUES (898, 85, 7);
INSERT INTO public.word_semantic VALUES (899, 85, 8);
INSERT INTO public.word_semantic VALUES (900, 85, 9);
INSERT INTO public.word_semantic VALUES (901, 85, 11);
INSERT INTO public.word_semantic VALUES (902, 85, 23);
INSERT INTO public.word_semantic VALUES (903, 85, 24);
INSERT INTO public.word_semantic VALUES (904, 85, 14);
INSERT INTO public.word_semantic VALUES (905, 85, 15);
INSERT INTO public.word_semantic VALUES (908, 86, 7);
INSERT INTO public.word_semantic VALUES (909, 86, 8);
INSERT INTO public.word_semantic VALUES (910, 86, 9);
INSERT INTO public.word_semantic VALUES (911, 86, 11);
INSERT INTO public.word_semantic VALUES (912, 86, 23);
INSERT INTO public.word_semantic VALUES (913, 86, 24);
INSERT INTO public.word_semantic VALUES (914, 86, 14);
INSERT INTO public.word_semantic VALUES (915, 86, 15);
INSERT INTO public.word_semantic VALUES (918, 87, 7);
INSERT INTO public.word_semantic VALUES (919, 87, 8);
INSERT INTO public.word_semantic VALUES (920, 87, 9);
INSERT INTO public.word_semantic VALUES (921, 87, 11);
INSERT INTO public.word_semantic VALUES (922, 87, 23);
INSERT INTO public.word_semantic VALUES (923, 87, 24);
INSERT INTO public.word_semantic VALUES (924, 87, 14);
INSERT INTO public.word_semantic VALUES (925, 87, 15);
INSERT INTO public.word_semantic VALUES (928, 88, 7);
INSERT INTO public.word_semantic VALUES (929, 88, 8);
INSERT INTO public.word_semantic VALUES (930, 88, 9);
INSERT INTO public.word_semantic VALUES (931, 88, 11);
INSERT INTO public.word_semantic VALUES (932, 88, 23);
INSERT INTO public.word_semantic VALUES (933, 88, 24);
INSERT INTO public.word_semantic VALUES (934, 88, 14);
INSERT INTO public.word_semantic VALUES (935, 88, 15);
INSERT INTO public.word_semantic VALUES (938, 89, 7);
INSERT INTO public.word_semantic VALUES (939, 89, 8);
INSERT INTO public.word_semantic VALUES (940, 89, 9);
INSERT INTO public.word_semantic VALUES (941, 89, 11);
INSERT INTO public.word_semantic VALUES (942, 89, 23);
INSERT INTO public.word_semantic VALUES (943, 89, 24);
INSERT INTO public.word_semantic VALUES (944, 89, 14);
INSERT INTO public.word_semantic VALUES (945, 89, 15);
INSERT INTO public.word_semantic VALUES (948, 90, 7);
INSERT INTO public.word_semantic VALUES (949, 90, 8);
INSERT INTO public.word_semantic VALUES (950, 90, 9);
INSERT INTO public.word_semantic VALUES (951, 90, 11);
INSERT INTO public.word_semantic VALUES (952, 90, 23);
INSERT INTO public.word_semantic VALUES (953, 90, 24);
INSERT INTO public.word_semantic VALUES (954, 90, 14);
INSERT INTO public.word_semantic VALUES (955, 90, 15);
INSERT INTO public.word_semantic VALUES (958, 91, 7);
INSERT INTO public.word_semantic VALUES (959, 91, 8);
INSERT INTO public.word_semantic VALUES (960, 91, 9);
INSERT INTO public.word_semantic VALUES (961, 91, 11);
INSERT INTO public.word_semantic VALUES (962, 91, 23);
INSERT INTO public.word_semantic VALUES (963, 91, 24);
INSERT INTO public.word_semantic VALUES (964, 91, 14);
INSERT INTO public.word_semantic VALUES (965, 91, 15);
INSERT INTO public.word_semantic VALUES (968, 92, 7);
INSERT INTO public.word_semantic VALUES (969, 92, 8);
INSERT INTO public.word_semantic VALUES (970, 92, 9);
INSERT INTO public.word_semantic VALUES (971, 92, 11);
INSERT INTO public.word_semantic VALUES (972, 92, 28);
INSERT INTO public.word_semantic VALUES (973, 92, 29);
INSERT INTO public.word_semantic VALUES (976, 93, 7);
INSERT INTO public.word_semantic VALUES (977, 93, 8);
INSERT INTO public.word_semantic VALUES (978, 93, 9);
INSERT INTO public.word_semantic VALUES (979, 93, 11);
INSERT INTO public.word_semantic VALUES (980, 93, 28);
INSERT INTO public.word_semantic VALUES (981, 93, 29);
INSERT INTO public.word_semantic VALUES (984, 94, 7);
INSERT INTO public.word_semantic VALUES (985, 94, 8);
INSERT INTO public.word_semantic VALUES (986, 94, 9);
INSERT INTO public.word_semantic VALUES (987, 94, 11);
INSERT INTO public.word_semantic VALUES (988, 94, 28);
INSERT INTO public.word_semantic VALUES (989, 94, 29);
INSERT INTO public.word_semantic VALUES (4769, 661, 52);
INSERT INTO public.word_semantic VALUES (992, 95, 7);
INSERT INTO public.word_semantic VALUES (993, 95, 8);
INSERT INTO public.word_semantic VALUES (994, 95, 9);
INSERT INTO public.word_semantic VALUES (995, 95, 11);
INSERT INTO public.word_semantic VALUES (996, 95, 28);
INSERT INTO public.word_semantic VALUES (997, 95, 29);
INSERT INTO public.word_semantic VALUES (1000, 96, 7);
INSERT INTO public.word_semantic VALUES (1001, 96, 8);
INSERT INTO public.word_semantic VALUES (1002, 96, 9);
INSERT INTO public.word_semantic VALUES (1003, 96, 11);
INSERT INTO public.word_semantic VALUES (1004, 96, 28);
INSERT INTO public.word_semantic VALUES (1005, 96, 29);
INSERT INTO public.word_semantic VALUES (1008, 97, 7);
INSERT INTO public.word_semantic VALUES (1009, 97, 8);
INSERT INTO public.word_semantic VALUES (1010, 97, 9);
INSERT INTO public.word_semantic VALUES (1011, 97, 11);
INSERT INTO public.word_semantic VALUES (1012, 97, 28);
INSERT INTO public.word_semantic VALUES (1013, 97, 29);
INSERT INTO public.word_semantic VALUES (1016, 98, 7);
INSERT INTO public.word_semantic VALUES (1017, 98, 8);
INSERT INTO public.word_semantic VALUES (1018, 98, 9);
INSERT INTO public.word_semantic VALUES (1019, 98, 11);
INSERT INTO public.word_semantic VALUES (1020, 98, 28);
INSERT INTO public.word_semantic VALUES (1021, 98, 29);
INSERT INTO public.word_semantic VALUES (1024, 99, 7);
INSERT INTO public.word_semantic VALUES (1025, 99, 8);
INSERT INTO public.word_semantic VALUES (1026, 99, 9);
INSERT INTO public.word_semantic VALUES (1027, 99, 11);
INSERT INTO public.word_semantic VALUES (1028, 99, 28);
INSERT INTO public.word_semantic VALUES (1029, 99, 29);
INSERT INTO public.word_semantic VALUES (1032, 100, 7);
INSERT INTO public.word_semantic VALUES (1033, 100, 8);
INSERT INTO public.word_semantic VALUES (1034, 100, 9);
INSERT INTO public.word_semantic VALUES (1035, 100, 11);
INSERT INTO public.word_semantic VALUES (1036, 100, 30);
INSERT INTO public.word_semantic VALUES (1039, 101, 7);
INSERT INTO public.word_semantic VALUES (1040, 101, 8);
INSERT INTO public.word_semantic VALUES (1041, 101, 9);
INSERT INTO public.word_semantic VALUES (1042, 101, 11);
INSERT INTO public.word_semantic VALUES (1043, 101, 30);
INSERT INTO public.word_semantic VALUES (1046, 102, 7);
INSERT INTO public.word_semantic VALUES (1047, 102, 8);
INSERT INTO public.word_semantic VALUES (1048, 102, 9);
INSERT INTO public.word_semantic VALUES (1049, 102, 11);
INSERT INTO public.word_semantic VALUES (1050, 102, 30);
INSERT INTO public.word_semantic VALUES (1053, 103, 7);
INSERT INTO public.word_semantic VALUES (1054, 103, 8);
INSERT INTO public.word_semantic VALUES (1055, 103, 9);
INSERT INTO public.word_semantic VALUES (1056, 103, 11);
INSERT INTO public.word_semantic VALUES (1057, 103, 30);
INSERT INTO public.word_semantic VALUES (1060, 104, 7);
INSERT INTO public.word_semantic VALUES (1061, 104, 8);
INSERT INTO public.word_semantic VALUES (1062, 104, 9);
INSERT INTO public.word_semantic VALUES (1063, 104, 11);
INSERT INTO public.word_semantic VALUES (1064, 104, 30);
INSERT INTO public.word_semantic VALUES (1067, 105, 7);
INSERT INTO public.word_semantic VALUES (1068, 105, 8);
INSERT INTO public.word_semantic VALUES (1069, 105, 9);
INSERT INTO public.word_semantic VALUES (1070, 105, 11);
INSERT INTO public.word_semantic VALUES (1071, 105, 30);
INSERT INTO public.word_semantic VALUES (1074, 106, 7);
INSERT INTO public.word_semantic VALUES (1075, 106, 8);
INSERT INTO public.word_semantic VALUES (1076, 106, 9);
INSERT INTO public.word_semantic VALUES (1077, 106, 11);
INSERT INTO public.word_semantic VALUES (1078, 106, 30);
INSERT INTO public.word_semantic VALUES (1081, 107, 7);
INSERT INTO public.word_semantic VALUES (1082, 107, 8);
INSERT INTO public.word_semantic VALUES (1083, 107, 9);
INSERT INTO public.word_semantic VALUES (1084, 107, 11);
INSERT INTO public.word_semantic VALUES (1085, 107, 30);
INSERT INTO public.word_semantic VALUES (1088, 108, 7);
INSERT INTO public.word_semantic VALUES (1089, 108, 8);
INSERT INTO public.word_semantic VALUES (1090, 108, 9);
INSERT INTO public.word_semantic VALUES (1091, 108, 11);
INSERT INTO public.word_semantic VALUES (1092, 108, 30);
INSERT INTO public.word_semantic VALUES (1095, 109, 7);
INSERT INTO public.word_semantic VALUES (1096, 109, 8);
INSERT INTO public.word_semantic VALUES (1097, 109, 9);
INSERT INTO public.word_semantic VALUES (1098, 109, 11);
INSERT INTO public.word_semantic VALUES (1099, 109, 30);
INSERT INTO public.word_semantic VALUES (1102, 110, 7);
INSERT INTO public.word_semantic VALUES (1103, 110, 8);
INSERT INTO public.word_semantic VALUES (1104, 110, 9);
INSERT INTO public.word_semantic VALUES (1105, 110, 11);
INSERT INTO public.word_semantic VALUES (1106, 110, 28);
INSERT INTO public.word_semantic VALUES (1107, 110, 29);
INSERT INTO public.word_semantic VALUES (1108, 110, 27);
INSERT INTO public.word_semantic VALUES (1111, 111, 7);
INSERT INTO public.word_semantic VALUES (1112, 111, 8);
INSERT INTO public.word_semantic VALUES (1113, 111, 9);
INSERT INTO public.word_semantic VALUES (1114, 111, 11);
INSERT INTO public.word_semantic VALUES (1115, 111, 28);
INSERT INTO public.word_semantic VALUES (1116, 111, 29);
INSERT INTO public.word_semantic VALUES (1117, 111, 27);
INSERT INTO public.word_semantic VALUES (1120, 112, 7);
INSERT INTO public.word_semantic VALUES (1121, 112, 8);
INSERT INTO public.word_semantic VALUES (1122, 112, 9);
INSERT INTO public.word_semantic VALUES (1123, 112, 11);
INSERT INTO public.word_semantic VALUES (1124, 112, 28);
INSERT INTO public.word_semantic VALUES (1125, 112, 29);
INSERT INTO public.word_semantic VALUES (1126, 112, 27);
INSERT INTO public.word_semantic VALUES (1129, 113, 7);
INSERT INTO public.word_semantic VALUES (1130, 113, 8);
INSERT INTO public.word_semantic VALUES (1131, 113, 9);
INSERT INTO public.word_semantic VALUES (1132, 113, 11);
INSERT INTO public.word_semantic VALUES (1133, 113, 28);
INSERT INTO public.word_semantic VALUES (1134, 113, 29);
INSERT INTO public.word_semantic VALUES (1135, 113, 27);
INSERT INTO public.word_semantic VALUES (1138, 114, 7);
INSERT INTO public.word_semantic VALUES (1139, 114, 8);
INSERT INTO public.word_semantic VALUES (1140, 114, 9);
INSERT INTO public.word_semantic VALUES (1141, 114, 11);
INSERT INTO public.word_semantic VALUES (1142, 114, 28);
INSERT INTO public.word_semantic VALUES (1143, 114, 29);
INSERT INTO public.word_semantic VALUES (1144, 114, 27);
INSERT INTO public.word_semantic VALUES (1147, 115, 7);
INSERT INTO public.word_semantic VALUES (1148, 115, 8);
INSERT INTO public.word_semantic VALUES (1149, 115, 9);
INSERT INTO public.word_semantic VALUES (1150, 115, 11);
INSERT INTO public.word_semantic VALUES (1151, 115, 28);
INSERT INTO public.word_semantic VALUES (1152, 115, 29);
INSERT INTO public.word_semantic VALUES (1153, 115, 27);
INSERT INTO public.word_semantic VALUES (1156, 116, 7);
INSERT INTO public.word_semantic VALUES (1157, 116, 8);
INSERT INTO public.word_semantic VALUES (1158, 116, 9);
INSERT INTO public.word_semantic VALUES (1159, 116, 11);
INSERT INTO public.word_semantic VALUES (1160, 116, 28);
INSERT INTO public.word_semantic VALUES (1161, 116, 29);
INSERT INTO public.word_semantic VALUES (1162, 116, 27);
INSERT INTO public.word_semantic VALUES (1165, 117, 7);
INSERT INTO public.word_semantic VALUES (1166, 117, 8);
INSERT INTO public.word_semantic VALUES (1167, 117, 9);
INSERT INTO public.word_semantic VALUES (1168, 117, 11);
INSERT INTO public.word_semantic VALUES (1169, 117, 28);
INSERT INTO public.word_semantic VALUES (1170, 117, 29);
INSERT INTO public.word_semantic VALUES (1171, 117, 27);
INSERT INTO public.word_semantic VALUES (1174, 118, 7);
INSERT INTO public.word_semantic VALUES (1175, 118, 8);
INSERT INTO public.word_semantic VALUES (1176, 118, 9);
INSERT INTO public.word_semantic VALUES (1177, 118, 11);
INSERT INTO public.word_semantic VALUES (1178, 118, 28);
INSERT INTO public.word_semantic VALUES (1179, 118, 29);
INSERT INTO public.word_semantic VALUES (1180, 118, 27);
INSERT INTO public.word_semantic VALUES (1183, 119, 7);
INSERT INTO public.word_semantic VALUES (1184, 119, 8);
INSERT INTO public.word_semantic VALUES (1185, 119, 9);
INSERT INTO public.word_semantic VALUES (1186, 119, 11);
INSERT INTO public.word_semantic VALUES (1187, 119, 28);
INSERT INTO public.word_semantic VALUES (1188, 119, 29);
INSERT INTO public.word_semantic VALUES (1189, 119, 27);
INSERT INTO public.word_semantic VALUES (1192, 120, 7);
INSERT INTO public.word_semantic VALUES (1193, 120, 8);
INSERT INTO public.word_semantic VALUES (1194, 120, 9);
INSERT INTO public.word_semantic VALUES (1195, 120, 11);
INSERT INTO public.word_semantic VALUES (1196, 120, 28);
INSERT INTO public.word_semantic VALUES (1197, 120, 29);
INSERT INTO public.word_semantic VALUES (1198, 120, 31);
INSERT INTO public.word_semantic VALUES (1201, 121, 7);
INSERT INTO public.word_semantic VALUES (1202, 121, 8);
INSERT INTO public.word_semantic VALUES (1203, 121, 9);
INSERT INTO public.word_semantic VALUES (1204, 121, 11);
INSERT INTO public.word_semantic VALUES (1205, 121, 28);
INSERT INTO public.word_semantic VALUES (1206, 121, 29);
INSERT INTO public.word_semantic VALUES (1207, 121, 31);
INSERT INTO public.word_semantic VALUES (1210, 122, 7);
INSERT INTO public.word_semantic VALUES (1211, 122, 8);
INSERT INTO public.word_semantic VALUES (1212, 122, 9);
INSERT INTO public.word_semantic VALUES (1213, 122, 11);
INSERT INTO public.word_semantic VALUES (1214, 122, 28);
INSERT INTO public.word_semantic VALUES (1215, 122, 29);
INSERT INTO public.word_semantic VALUES (1218, 123, 7);
INSERT INTO public.word_semantic VALUES (1219, 123, 8);
INSERT INTO public.word_semantic VALUES (1220, 123, 9);
INSERT INTO public.word_semantic VALUES (1221, 123, 11);
INSERT INTO public.word_semantic VALUES (1222, 123, 28);
INSERT INTO public.word_semantic VALUES (1223, 123, 29);
INSERT INTO public.word_semantic VALUES (4771, 662, 67);
INSERT INTO public.word_semantic VALUES (4772, 662, 52);
INSERT INTO public.word_semantic VALUES (1226, 124, 7);
INSERT INTO public.word_semantic VALUES (1227, 124, 8);
INSERT INTO public.word_semantic VALUES (1228, 124, 9);
INSERT INTO public.word_semantic VALUES (1229, 124, 11);
INSERT INTO public.word_semantic VALUES (1230, 124, 28);
INSERT INTO public.word_semantic VALUES (1231, 124, 29);
INSERT INTO public.word_semantic VALUES (1232, 124, 31);
INSERT INTO public.word_semantic VALUES (1235, 125, 7);
INSERT INTO public.word_semantic VALUES (1236, 125, 8);
INSERT INTO public.word_semantic VALUES (1237, 125, 9);
INSERT INTO public.word_semantic VALUES (1238, 125, 11);
INSERT INTO public.word_semantic VALUES (1239, 125, 28);
INSERT INTO public.word_semantic VALUES (1240, 125, 29);
INSERT INTO public.word_semantic VALUES (1241, 125, 31);
INSERT INTO public.word_semantic VALUES (1244, 126, 7);
INSERT INTO public.word_semantic VALUES (1245, 126, 8);
INSERT INTO public.word_semantic VALUES (1246, 126, 9);
INSERT INTO public.word_semantic VALUES (1247, 126, 11);
INSERT INTO public.word_semantic VALUES (1248, 126, 28);
INSERT INTO public.word_semantic VALUES (1249, 126, 29);
INSERT INTO public.word_semantic VALUES (1250, 126, 31);
INSERT INTO public.word_semantic VALUES (1253, 127, 7);
INSERT INTO public.word_semantic VALUES (1254, 127, 8);
INSERT INTO public.word_semantic VALUES (1255, 127, 9);
INSERT INTO public.word_semantic VALUES (1256, 127, 11);
INSERT INTO public.word_semantic VALUES (1257, 127, 28);
INSERT INTO public.word_semantic VALUES (1258, 127, 29);
INSERT INTO public.word_semantic VALUES (1259, 127, 31);
INSERT INTO public.word_semantic VALUES (1262, 128, 7);
INSERT INTO public.word_semantic VALUES (1263, 128, 8);
INSERT INTO public.word_semantic VALUES (1264, 128, 9);
INSERT INTO public.word_semantic VALUES (1265, 128, 11);
INSERT INTO public.word_semantic VALUES (1266, 128, 28);
INSERT INTO public.word_semantic VALUES (1267, 128, 29);
INSERT INTO public.word_semantic VALUES (1268, 128, 31);
INSERT INTO public.word_semantic VALUES (1271, 129, 7);
INSERT INTO public.word_semantic VALUES (1272, 129, 8);
INSERT INTO public.word_semantic VALUES (1273, 129, 9);
INSERT INTO public.word_semantic VALUES (1274, 129, 11);
INSERT INTO public.word_semantic VALUES (1275, 129, 28);
INSERT INTO public.word_semantic VALUES (1276, 129, 29);
INSERT INTO public.word_semantic VALUES (1277, 129, 31);
INSERT INTO public.word_semantic VALUES (1280, 130, 7);
INSERT INTO public.word_semantic VALUES (1281, 130, 8);
INSERT INTO public.word_semantic VALUES (1282, 130, 9);
INSERT INTO public.word_semantic VALUES (1283, 130, 11);
INSERT INTO public.word_semantic VALUES (1284, 130, 28);
INSERT INTO public.word_semantic VALUES (1285, 130, 29);
INSERT INTO public.word_semantic VALUES (1288, 131, 7);
INSERT INTO public.word_semantic VALUES (1289, 131, 8);
INSERT INTO public.word_semantic VALUES (1290, 131, 9);
INSERT INTO public.word_semantic VALUES (1291, 131, 11);
INSERT INTO public.word_semantic VALUES (1292, 131, 28);
INSERT INTO public.word_semantic VALUES (1293, 131, 29);
INSERT INTO public.word_semantic VALUES (1296, 132, 7);
INSERT INTO public.word_semantic VALUES (1297, 132, 8);
INSERT INTO public.word_semantic VALUES (1298, 132, 9);
INSERT INTO public.word_semantic VALUES (1299, 132, 11);
INSERT INTO public.word_semantic VALUES (1300, 132, 28);
INSERT INTO public.word_semantic VALUES (1301, 132, 29);
INSERT INTO public.word_semantic VALUES (1302, 132, 27);
INSERT INTO public.word_semantic VALUES (1305, 133, 7);
INSERT INTO public.word_semantic VALUES (1306, 133, 8);
INSERT INTO public.word_semantic VALUES (1307, 133, 9);
INSERT INTO public.word_semantic VALUES (1308, 133, 11);
INSERT INTO public.word_semantic VALUES (1309, 133, 28);
INSERT INTO public.word_semantic VALUES (1310, 133, 29);
INSERT INTO public.word_semantic VALUES (1311, 133, 27);
INSERT INTO public.word_semantic VALUES (1314, 134, 7);
INSERT INTO public.word_semantic VALUES (1315, 134, 8);
INSERT INTO public.word_semantic VALUES (1316, 134, 9);
INSERT INTO public.word_semantic VALUES (1317, 134, 11);
INSERT INTO public.word_semantic VALUES (1318, 134, 28);
INSERT INTO public.word_semantic VALUES (1319, 134, 29);
INSERT INTO public.word_semantic VALUES (1320, 134, 27);
INSERT INTO public.word_semantic VALUES (1323, 135, 7);
INSERT INTO public.word_semantic VALUES (1324, 135, 8);
INSERT INTO public.word_semantic VALUES (1325, 135, 9);
INSERT INTO public.word_semantic VALUES (1326, 135, 11);
INSERT INTO public.word_semantic VALUES (1327, 135, 28);
INSERT INTO public.word_semantic VALUES (1328, 135, 29);
INSERT INTO public.word_semantic VALUES (1329, 135, 27);
INSERT INTO public.word_semantic VALUES (1332, 136, 7);
INSERT INTO public.word_semantic VALUES (1333, 136, 8);
INSERT INTO public.word_semantic VALUES (1334, 136, 9);
INSERT INTO public.word_semantic VALUES (1335, 136, 11);
INSERT INTO public.word_semantic VALUES (1336, 136, 28);
INSERT INTO public.word_semantic VALUES (1337, 136, 29);
INSERT INTO public.word_semantic VALUES (1338, 136, 27);
INSERT INTO public.word_semantic VALUES (1341, 137, 7);
INSERT INTO public.word_semantic VALUES (1342, 137, 8);
INSERT INTO public.word_semantic VALUES (1343, 137, 9);
INSERT INTO public.word_semantic VALUES (1344, 137, 11);
INSERT INTO public.word_semantic VALUES (1345, 137, 28);
INSERT INTO public.word_semantic VALUES (1346, 137, 29);
INSERT INTO public.word_semantic VALUES (1347, 137, 27);
INSERT INTO public.word_semantic VALUES (1350, 138, 7);
INSERT INTO public.word_semantic VALUES (1351, 138, 8);
INSERT INTO public.word_semantic VALUES (1352, 138, 9);
INSERT INTO public.word_semantic VALUES (1353, 138, 11);
INSERT INTO public.word_semantic VALUES (1354, 138, 28);
INSERT INTO public.word_semantic VALUES (1355, 138, 29);
INSERT INTO public.word_semantic VALUES (1356, 138, 27);
INSERT INTO public.word_semantic VALUES (1357, 138, 31);
INSERT INTO public.word_semantic VALUES (1360, 139, 7);
INSERT INTO public.word_semantic VALUES (1361, 139, 8);
INSERT INTO public.word_semantic VALUES (1362, 139, 9);
INSERT INTO public.word_semantic VALUES (1363, 139, 11);
INSERT INTO public.word_semantic VALUES (1364, 139, 28);
INSERT INTO public.word_semantic VALUES (1365, 139, 29);
INSERT INTO public.word_semantic VALUES (1366, 139, 27);
INSERT INTO public.word_semantic VALUES (1367, 139, 31);
INSERT INTO public.word_semantic VALUES (1370, 140, 7);
INSERT INTO public.word_semantic VALUES (1371, 140, 8);
INSERT INTO public.word_semantic VALUES (1372, 140, 5);
INSERT INTO public.word_semantic VALUES (1373, 140, 15);
INSERT INTO public.word_semantic VALUES (1374, 140, 32);
INSERT INTO public.word_semantic VALUES (1377, 141, 7);
INSERT INTO public.word_semantic VALUES (1378, 141, 8);
INSERT INTO public.word_semantic VALUES (1379, 141, 5);
INSERT INTO public.word_semantic VALUES (1380, 141, 15);
INSERT INTO public.word_semantic VALUES (1381, 141, 32);
INSERT INTO public.word_semantic VALUES (1384, 142, 7);
INSERT INTO public.word_semantic VALUES (1385, 142, 8);
INSERT INTO public.word_semantic VALUES (1386, 142, 5);
INSERT INTO public.word_semantic VALUES (1387, 142, 15);
INSERT INTO public.word_semantic VALUES (1388, 142, 33);
INSERT INTO public.word_semantic VALUES (1391, 143, 7);
INSERT INTO public.word_semantic VALUES (1392, 143, 8);
INSERT INTO public.word_semantic VALUES (1393, 143, 5);
INSERT INTO public.word_semantic VALUES (1394, 143, 15);
INSERT INTO public.word_semantic VALUES (1395, 143, 33);
INSERT INTO public.word_semantic VALUES (1398, 144, 7);
INSERT INTO public.word_semantic VALUES (1399, 144, 8);
INSERT INTO public.word_semantic VALUES (1400, 144, 5);
INSERT INTO public.word_semantic VALUES (1401, 144, 15);
INSERT INTO public.word_semantic VALUES (1402, 144, 32);
INSERT INTO public.word_semantic VALUES (1405, 145, 7);
INSERT INTO public.word_semantic VALUES (1406, 145, 8);
INSERT INTO public.word_semantic VALUES (1407, 145, 5);
INSERT INTO public.word_semantic VALUES (1408, 145, 15);
INSERT INTO public.word_semantic VALUES (1409, 145, 32);
INSERT INTO public.word_semantic VALUES (1412, 146, 7);
INSERT INTO public.word_semantic VALUES (1413, 146, 8);
INSERT INTO public.word_semantic VALUES (1414, 146, 5);
INSERT INTO public.word_semantic VALUES (1415, 146, 15);
INSERT INTO public.word_semantic VALUES (1416, 146, 32);
INSERT INTO public.word_semantic VALUES (1419, 147, 7);
INSERT INTO public.word_semantic VALUES (1420, 147, 8);
INSERT INTO public.word_semantic VALUES (1421, 147, 5);
INSERT INTO public.word_semantic VALUES (1422, 147, 15);
INSERT INTO public.word_semantic VALUES (1423, 147, 32);
INSERT INTO public.word_semantic VALUES (1426, 148, 7);
INSERT INTO public.word_semantic VALUES (1427, 148, 8);
INSERT INTO public.word_semantic VALUES (1428, 148, 5);
INSERT INTO public.word_semantic VALUES (1429, 148, 15);
INSERT INTO public.word_semantic VALUES (1430, 148, 32);
INSERT INTO public.word_semantic VALUES (1433, 149, 7);
INSERT INTO public.word_semantic VALUES (1434, 149, 8);
INSERT INTO public.word_semantic VALUES (1435, 149, 5);
INSERT INTO public.word_semantic VALUES (1436, 149, 15);
INSERT INTO public.word_semantic VALUES (1437, 149, 32);
INSERT INTO public.word_semantic VALUES (1440, 150, 7);
INSERT INTO public.word_semantic VALUES (1441, 150, 8);
INSERT INTO public.word_semantic VALUES (1442, 150, 5);
INSERT INTO public.word_semantic VALUES (1443, 150, 15);
INSERT INTO public.word_semantic VALUES (1444, 150, 32);
INSERT INTO public.word_semantic VALUES (1447, 151, 7);
INSERT INTO public.word_semantic VALUES (1448, 151, 8);
INSERT INTO public.word_semantic VALUES (1449, 151, 5);
INSERT INTO public.word_semantic VALUES (1450, 151, 15);
INSERT INTO public.word_semantic VALUES (1451, 151, 32);
INSERT INTO public.word_semantic VALUES (1454, 152, 7);
INSERT INTO public.word_semantic VALUES (1455, 152, 8);
INSERT INTO public.word_semantic VALUES (1456, 152, 5);
INSERT INTO public.word_semantic VALUES (1457, 152, 15);
INSERT INTO public.word_semantic VALUES (1458, 152, 32);
INSERT INTO public.word_semantic VALUES (1459, 152, 16);
INSERT INTO public.word_semantic VALUES (4774, 663, 67);
INSERT INTO public.word_semantic VALUES (1462, 153, 7);
INSERT INTO public.word_semantic VALUES (1463, 153, 8);
INSERT INTO public.word_semantic VALUES (1464, 153, 5);
INSERT INTO public.word_semantic VALUES (1465, 153, 15);
INSERT INTO public.word_semantic VALUES (1466, 153, 32);
INSERT INTO public.word_semantic VALUES (1467, 153, 16);
INSERT INTO public.word_semantic VALUES (1470, 154, 7);
INSERT INTO public.word_semantic VALUES (1471, 154, 8);
INSERT INTO public.word_semantic VALUES (1472, 154, 5);
INSERT INTO public.word_semantic VALUES (1473, 154, 15);
INSERT INTO public.word_semantic VALUES (1474, 154, 32);
INSERT INTO public.word_semantic VALUES (1475, 154, 16);
INSERT INTO public.word_semantic VALUES (1478, 155, 7);
INSERT INTO public.word_semantic VALUES (1479, 155, 8);
INSERT INTO public.word_semantic VALUES (1480, 155, 5);
INSERT INTO public.word_semantic VALUES (1481, 155, 15);
INSERT INTO public.word_semantic VALUES (1482, 155, 32);
INSERT INTO public.word_semantic VALUES (1483, 155, 16);
INSERT INTO public.word_semantic VALUES (1486, 156, 7);
INSERT INTO public.word_semantic VALUES (1487, 156, 8);
INSERT INTO public.word_semantic VALUES (1488, 156, 5);
INSERT INTO public.word_semantic VALUES (1489, 156, 15);
INSERT INTO public.word_semantic VALUES (1490, 156, 32);
INSERT INTO public.word_semantic VALUES (1491, 156, 16);
INSERT INTO public.word_semantic VALUES (1492, 156, 34);
INSERT INTO public.word_semantic VALUES (1493, 156, 35);
INSERT INTO public.word_semantic VALUES (1496, 157, 7);
INSERT INTO public.word_semantic VALUES (1497, 157, 8);
INSERT INTO public.word_semantic VALUES (1498, 157, 5);
INSERT INTO public.word_semantic VALUES (1499, 157, 15);
INSERT INTO public.word_semantic VALUES (1500, 157, 32);
INSERT INTO public.word_semantic VALUES (1501, 157, 16);
INSERT INTO public.word_semantic VALUES (1502, 157, 34);
INSERT INTO public.word_semantic VALUES (1503, 157, 35);
INSERT INTO public.word_semantic VALUES (1506, 158, 7);
INSERT INTO public.word_semantic VALUES (1507, 158, 8);
INSERT INTO public.word_semantic VALUES (1508, 158, 5);
INSERT INTO public.word_semantic VALUES (1509, 158, 15);
INSERT INTO public.word_semantic VALUES (1510, 158, 32);
INSERT INTO public.word_semantic VALUES (1511, 158, 16);
INSERT INTO public.word_semantic VALUES (1512, 158, 34);
INSERT INTO public.word_semantic VALUES (1513, 158, 35);
INSERT INTO public.word_semantic VALUES (1516, 159, 7);
INSERT INTO public.word_semantic VALUES (1517, 159, 8);
INSERT INTO public.word_semantic VALUES (1518, 159, 5);
INSERT INTO public.word_semantic VALUES (1519, 159, 15);
INSERT INTO public.word_semantic VALUES (1520, 159, 32);
INSERT INTO public.word_semantic VALUES (1521, 159, 16);
INSERT INTO public.word_semantic VALUES (1522, 159, 34);
INSERT INTO public.word_semantic VALUES (1523, 159, 35);
INSERT INTO public.word_semantic VALUES (1526, 160, 7);
INSERT INTO public.word_semantic VALUES (1527, 160, 8);
INSERT INTO public.word_semantic VALUES (1528, 160, 5);
INSERT INTO public.word_semantic VALUES (1529, 160, 15);
INSERT INTO public.word_semantic VALUES (1530, 160, 32);
INSERT INTO public.word_semantic VALUES (1531, 160, 16);
INSERT INTO public.word_semantic VALUES (1532, 160, 34);
INSERT INTO public.word_semantic VALUES (1533, 160, 35);
INSERT INTO public.word_semantic VALUES (1536, 161, 7);
INSERT INTO public.word_semantic VALUES (1537, 161, 8);
INSERT INTO public.word_semantic VALUES (1538, 161, 5);
INSERT INTO public.word_semantic VALUES (1539, 161, 15);
INSERT INTO public.word_semantic VALUES (1540, 161, 32);
INSERT INTO public.word_semantic VALUES (1541, 161, 16);
INSERT INTO public.word_semantic VALUES (1542, 161, 34);
INSERT INTO public.word_semantic VALUES (1543, 161, 35);
INSERT INTO public.word_semantic VALUES (1546, 162, 7);
INSERT INTO public.word_semantic VALUES (1547, 162, 8);
INSERT INTO public.word_semantic VALUES (1548, 162, 5);
INSERT INTO public.word_semantic VALUES (1549, 162, 15);
INSERT INTO public.word_semantic VALUES (1550, 162, 32);
INSERT INTO public.word_semantic VALUES (1551, 162, 16);
INSERT INTO public.word_semantic VALUES (1552, 162, 34);
INSERT INTO public.word_semantic VALUES (1553, 162, 35);
INSERT INTO public.word_semantic VALUES (1556, 163, 7);
INSERT INTO public.word_semantic VALUES (1557, 163, 8);
INSERT INTO public.word_semantic VALUES (1558, 163, 5);
INSERT INTO public.word_semantic VALUES (1559, 163, 15);
INSERT INTO public.word_semantic VALUES (1560, 163, 32);
INSERT INTO public.word_semantic VALUES (1561, 163, 16);
INSERT INTO public.word_semantic VALUES (1562, 163, 34);
INSERT INTO public.word_semantic VALUES (1563, 163, 35);
INSERT INTO public.word_semantic VALUES (1566, 164, 7);
INSERT INTO public.word_semantic VALUES (1567, 164, 8);
INSERT INTO public.word_semantic VALUES (1568, 164, 5);
INSERT INTO public.word_semantic VALUES (1569, 164, 15);
INSERT INTO public.word_semantic VALUES (1570, 164, 32);
INSERT INTO public.word_semantic VALUES (1571, 164, 16);
INSERT INTO public.word_semantic VALUES (1572, 164, 34);
INSERT INTO public.word_semantic VALUES (1573, 164, 35);
INSERT INTO public.word_semantic VALUES (1576, 165, 7);
INSERT INTO public.word_semantic VALUES (1577, 165, 8);
INSERT INTO public.word_semantic VALUES (1578, 165, 5);
INSERT INTO public.word_semantic VALUES (1579, 165, 15);
INSERT INTO public.word_semantic VALUES (1580, 165, 32);
INSERT INTO public.word_semantic VALUES (1581, 165, 16);
INSERT INTO public.word_semantic VALUES (1582, 165, 34);
INSERT INTO public.word_semantic VALUES (1583, 165, 35);
INSERT INTO public.word_semantic VALUES (1586, 166, 7);
INSERT INTO public.word_semantic VALUES (1587, 166, 8);
INSERT INTO public.word_semantic VALUES (1588, 166, 5);
INSERT INTO public.word_semantic VALUES (1589, 166, 15);
INSERT INTO public.word_semantic VALUES (1590, 166, 32);
INSERT INTO public.word_semantic VALUES (1591, 166, 16);
INSERT INTO public.word_semantic VALUES (1592, 166, 34);
INSERT INTO public.word_semantic VALUES (1593, 166, 35);
INSERT INTO public.word_semantic VALUES (1596, 167, 7);
INSERT INTO public.word_semantic VALUES (1597, 167, 8);
INSERT INTO public.word_semantic VALUES (1598, 167, 5);
INSERT INTO public.word_semantic VALUES (1599, 167, 15);
INSERT INTO public.word_semantic VALUES (1600, 167, 32);
INSERT INTO public.word_semantic VALUES (1601, 167, 16);
INSERT INTO public.word_semantic VALUES (1602, 167, 34);
INSERT INTO public.word_semantic VALUES (1603, 167, 35);
INSERT INTO public.word_semantic VALUES (1606, 168, 7);
INSERT INTO public.word_semantic VALUES (1607, 168, 8);
INSERT INTO public.word_semantic VALUES (1608, 168, 5);
INSERT INTO public.word_semantic VALUES (1609, 168, 15);
INSERT INTO public.word_semantic VALUES (1610, 168, 32);
INSERT INTO public.word_semantic VALUES (1611, 168, 16);
INSERT INTO public.word_semantic VALUES (1612, 168, 34);
INSERT INTO public.word_semantic VALUES (1613, 168, 35);
INSERT INTO public.word_semantic VALUES (1616, 169, 7);
INSERT INTO public.word_semantic VALUES (1617, 169, 8);
INSERT INTO public.word_semantic VALUES (1618, 169, 5);
INSERT INTO public.word_semantic VALUES (1619, 169, 15);
INSERT INTO public.word_semantic VALUES (1620, 169, 32);
INSERT INTO public.word_semantic VALUES (1621, 169, 16);
INSERT INTO public.word_semantic VALUES (1622, 169, 34);
INSERT INTO public.word_semantic VALUES (1623, 169, 35);
INSERT INTO public.word_semantic VALUES (1626, 170, 7);
INSERT INTO public.word_semantic VALUES (1627, 170, 8);
INSERT INTO public.word_semantic VALUES (1628, 170, 5);
INSERT INTO public.word_semantic VALUES (1629, 170, 15);
INSERT INTO public.word_semantic VALUES (1630, 170, 32);
INSERT INTO public.word_semantic VALUES (1631, 170, 16);
INSERT INTO public.word_semantic VALUES (1632, 170, 34);
INSERT INTO public.word_semantic VALUES (1633, 170, 35);
INSERT INTO public.word_semantic VALUES (1636, 171, 7);
INSERT INTO public.word_semantic VALUES (1637, 171, 8);
INSERT INTO public.word_semantic VALUES (1638, 171, 5);
INSERT INTO public.word_semantic VALUES (1639, 171, 15);
INSERT INTO public.word_semantic VALUES (1640, 171, 32);
INSERT INTO public.word_semantic VALUES (1641, 171, 16);
INSERT INTO public.word_semantic VALUES (1642, 171, 34);
INSERT INTO public.word_semantic VALUES (1643, 171, 35);
INSERT INTO public.word_semantic VALUES (1646, 172, 7);
INSERT INTO public.word_semantic VALUES (1647, 172, 8);
INSERT INTO public.word_semantic VALUES (1648, 172, 5);
INSERT INTO public.word_semantic VALUES (1649, 172, 15);
INSERT INTO public.word_semantic VALUES (1650, 172, 32);
INSERT INTO public.word_semantic VALUES (1651, 172, 16);
INSERT INTO public.word_semantic VALUES (1654, 173, 7);
INSERT INTO public.word_semantic VALUES (1655, 173, 8);
INSERT INTO public.word_semantic VALUES (1656, 173, 5);
INSERT INTO public.word_semantic VALUES (1657, 173, 15);
INSERT INTO public.word_semantic VALUES (1658, 173, 32);
INSERT INTO public.word_semantic VALUES (1659, 173, 16);
INSERT INTO public.word_semantic VALUES (1662, 174, 7);
INSERT INTO public.word_semantic VALUES (1663, 174, 8);
INSERT INTO public.word_semantic VALUES (1664, 174, 5);
INSERT INTO public.word_semantic VALUES (1665, 174, 15);
INSERT INTO public.word_semantic VALUES (1666, 174, 32);
INSERT INTO public.word_semantic VALUES (1667, 174, 16);
INSERT INTO public.word_semantic VALUES (1670, 175, 7);
INSERT INTO public.word_semantic VALUES (1671, 175, 8);
INSERT INTO public.word_semantic VALUES (1672, 175, 5);
INSERT INTO public.word_semantic VALUES (1673, 175, 15);
INSERT INTO public.word_semantic VALUES (1674, 175, 32);
INSERT INTO public.word_semantic VALUES (1675, 175, 16);
INSERT INTO public.word_semantic VALUES (1678, 176, 7);
INSERT INTO public.word_semantic VALUES (1679, 176, 8);
INSERT INTO public.word_semantic VALUES (1680, 176, 5);
INSERT INTO public.word_semantic VALUES (1681, 176, 15);
INSERT INTO public.word_semantic VALUES (1682, 176, 32);
INSERT INTO public.word_semantic VALUES (1685, 177, 7);
INSERT INTO public.word_semantic VALUES (1686, 177, 8);
INSERT INTO public.word_semantic VALUES (1687, 177, 5);
INSERT INTO public.word_semantic VALUES (1688, 177, 15);
INSERT INTO public.word_semantic VALUES (1689, 177, 32);
INSERT INTO public.word_semantic VALUES (4775, 663, 52);
INSERT INTO public.word_semantic VALUES (1692, 178, 7);
INSERT INTO public.word_semantic VALUES (1693, 178, 8);
INSERT INTO public.word_semantic VALUES (1694, 178, 5);
INSERT INTO public.word_semantic VALUES (1695, 178, 15);
INSERT INTO public.word_semantic VALUES (1696, 178, 32);
INSERT INTO public.word_semantic VALUES (1699, 179, 7);
INSERT INTO public.word_semantic VALUES (1700, 179, 8);
INSERT INTO public.word_semantic VALUES (1701, 179, 5);
INSERT INTO public.word_semantic VALUES (1702, 179, 15);
INSERT INTO public.word_semantic VALUES (1703, 179, 32);
INSERT INTO public.word_semantic VALUES (1706, 180, 7);
INSERT INTO public.word_semantic VALUES (1707, 180, 8);
INSERT INTO public.word_semantic VALUES (1708, 180, 5);
INSERT INTO public.word_semantic VALUES (1709, 180, 15);
INSERT INTO public.word_semantic VALUES (1710, 180, 32);
INSERT INTO public.word_semantic VALUES (1713, 181, 7);
INSERT INTO public.word_semantic VALUES (1714, 181, 8);
INSERT INTO public.word_semantic VALUES (1715, 181, 5);
INSERT INTO public.word_semantic VALUES (1716, 181, 15);
INSERT INTO public.word_semantic VALUES (1717, 181, 32);
INSERT INTO public.word_semantic VALUES (1720, 182, 7);
INSERT INTO public.word_semantic VALUES (1721, 182, 8);
INSERT INTO public.word_semantic VALUES (1722, 182, 5);
INSERT INTO public.word_semantic VALUES (1723, 182, 15);
INSERT INTO public.word_semantic VALUES (1724, 182, 32);
INSERT INTO public.word_semantic VALUES (1727, 183, 7);
INSERT INTO public.word_semantic VALUES (1728, 183, 8);
INSERT INTO public.word_semantic VALUES (1729, 183, 5);
INSERT INTO public.word_semantic VALUES (1730, 183, 15);
INSERT INTO public.word_semantic VALUES (1731, 183, 32);
INSERT INTO public.word_semantic VALUES (1734, 184, 7);
INSERT INTO public.word_semantic VALUES (1735, 184, 8);
INSERT INTO public.word_semantic VALUES (1736, 184, 5);
INSERT INTO public.word_semantic VALUES (1737, 184, 15);
INSERT INTO public.word_semantic VALUES (1738, 184, 32);
INSERT INTO public.word_semantic VALUES (1741, 185, 7);
INSERT INTO public.word_semantic VALUES (1742, 185, 8);
INSERT INTO public.word_semantic VALUES (1743, 185, 5);
INSERT INTO public.word_semantic VALUES (1744, 185, 15);
INSERT INTO public.word_semantic VALUES (1745, 185, 32);
INSERT INTO public.word_semantic VALUES (1748, 186, 7);
INSERT INTO public.word_semantic VALUES (1749, 186, 8);
INSERT INTO public.word_semantic VALUES (1750, 186, 5);
INSERT INTO public.word_semantic VALUES (1751, 186, 15);
INSERT INTO public.word_semantic VALUES (1752, 186, 32);
INSERT INTO public.word_semantic VALUES (1755, 187, 7);
INSERT INTO public.word_semantic VALUES (1756, 187, 8);
INSERT INTO public.word_semantic VALUES (1757, 187, 5);
INSERT INTO public.word_semantic VALUES (1758, 187, 15);
INSERT INTO public.word_semantic VALUES (1759, 187, 32);
INSERT INTO public.word_semantic VALUES (1762, 188, 7);
INSERT INTO public.word_semantic VALUES (1763, 188, 8);
INSERT INTO public.word_semantic VALUES (1764, 188, 5);
INSERT INTO public.word_semantic VALUES (1765, 188, 15);
INSERT INTO public.word_semantic VALUES (1766, 188, 32);
INSERT INTO public.word_semantic VALUES (1769, 189, 7);
INSERT INTO public.word_semantic VALUES (1770, 189, 8);
INSERT INTO public.word_semantic VALUES (1771, 189, 5);
INSERT INTO public.word_semantic VALUES (1772, 189, 15);
INSERT INTO public.word_semantic VALUES (1773, 189, 32);
INSERT INTO public.word_semantic VALUES (1776, 190, 7);
INSERT INTO public.word_semantic VALUES (1777, 190, 8);
INSERT INTO public.word_semantic VALUES (1778, 190, 5);
INSERT INTO public.word_semantic VALUES (1779, 190, 15);
INSERT INTO public.word_semantic VALUES (1780, 190, 32);
INSERT INTO public.word_semantic VALUES (1783, 191, 7);
INSERT INTO public.word_semantic VALUES (1784, 191, 8);
INSERT INTO public.word_semantic VALUES (1785, 191, 5);
INSERT INTO public.word_semantic VALUES (1786, 191, 15);
INSERT INTO public.word_semantic VALUES (1787, 191, 32);
INSERT INTO public.word_semantic VALUES (1790, 192, 7);
INSERT INTO public.word_semantic VALUES (1791, 192, 8);
INSERT INTO public.word_semantic VALUES (1792, 192, 5);
INSERT INTO public.word_semantic VALUES (1793, 192, 15);
INSERT INTO public.word_semantic VALUES (1794, 192, 32);
INSERT INTO public.word_semantic VALUES (1797, 193, 7);
INSERT INTO public.word_semantic VALUES (1798, 193, 8);
INSERT INTO public.word_semantic VALUES (1799, 193, 5);
INSERT INTO public.word_semantic VALUES (1800, 193, 15);
INSERT INTO public.word_semantic VALUES (1801, 193, 32);
INSERT INTO public.word_semantic VALUES (1804, 194, 7);
INSERT INTO public.word_semantic VALUES (1805, 194, 8);
INSERT INTO public.word_semantic VALUES (1806, 194, 5);
INSERT INTO public.word_semantic VALUES (1807, 194, 15);
INSERT INTO public.word_semantic VALUES (1808, 194, 32);
INSERT INTO public.word_semantic VALUES (1811, 195, 7);
INSERT INTO public.word_semantic VALUES (1812, 195, 8);
INSERT INTO public.word_semantic VALUES (1813, 195, 5);
INSERT INTO public.word_semantic VALUES (1814, 195, 15);
INSERT INTO public.word_semantic VALUES (1815, 195, 32);
INSERT INTO public.word_semantic VALUES (1818, 196, 7);
INSERT INTO public.word_semantic VALUES (1819, 196, 8);
INSERT INTO public.word_semantic VALUES (1820, 196, 5);
INSERT INTO public.word_semantic VALUES (1821, 196, 15);
INSERT INTO public.word_semantic VALUES (1822, 196, 32);
INSERT INTO public.word_semantic VALUES (1823, 196, 16);
INSERT INTO public.word_semantic VALUES (1826, 197, 7);
INSERT INTO public.word_semantic VALUES (1827, 197, 8);
INSERT INTO public.word_semantic VALUES (1828, 197, 5);
INSERT INTO public.word_semantic VALUES (1829, 197, 15);
INSERT INTO public.word_semantic VALUES (1830, 197, 32);
INSERT INTO public.word_semantic VALUES (1831, 197, 16);
INSERT INTO public.word_semantic VALUES (1834, 198, 7);
INSERT INTO public.word_semantic VALUES (1835, 198, 8);
INSERT INTO public.word_semantic VALUES (1836, 198, 5);
INSERT INTO public.word_semantic VALUES (1837, 198, 15);
INSERT INTO public.word_semantic VALUES (1838, 198, 32);
INSERT INTO public.word_semantic VALUES (1839, 198, 16);
INSERT INTO public.word_semantic VALUES (1842, 199, 7);
INSERT INTO public.word_semantic VALUES (1843, 199, 8);
INSERT INTO public.word_semantic VALUES (1844, 199, 5);
INSERT INTO public.word_semantic VALUES (1845, 199, 15);
INSERT INTO public.word_semantic VALUES (1846, 199, 32);
INSERT INTO public.word_semantic VALUES (1847, 199, 16);
INSERT INTO public.word_semantic VALUES (1850, 200, 7);
INSERT INTO public.word_semantic VALUES (1851, 200, 8);
INSERT INTO public.word_semantic VALUES (1852, 200, 5);
INSERT INTO public.word_semantic VALUES (1853, 200, 15);
INSERT INTO public.word_semantic VALUES (1854, 200, 32);
INSERT INTO public.word_semantic VALUES (1855, 200, 16);
INSERT INTO public.word_semantic VALUES (1858, 201, 7);
INSERT INTO public.word_semantic VALUES (1859, 201, 8);
INSERT INTO public.word_semantic VALUES (1860, 201, 5);
INSERT INTO public.word_semantic VALUES (1861, 201, 15);
INSERT INTO public.word_semantic VALUES (1862, 201, 32);
INSERT INTO public.word_semantic VALUES (1863, 201, 16);
INSERT INTO public.word_semantic VALUES (1866, 202, 7);
INSERT INTO public.word_semantic VALUES (1867, 202, 8);
INSERT INTO public.word_semantic VALUES (1868, 202, 5);
INSERT INTO public.word_semantic VALUES (1869, 202, 15);
INSERT INTO public.word_semantic VALUES (1870, 202, 32);
INSERT INTO public.word_semantic VALUES (1871, 202, 16);
INSERT INTO public.word_semantic VALUES (1874, 203, 7);
INSERT INTO public.word_semantic VALUES (1875, 203, 8);
INSERT INTO public.word_semantic VALUES (1876, 203, 5);
INSERT INTO public.word_semantic VALUES (1877, 203, 15);
INSERT INTO public.word_semantic VALUES (1878, 203, 32);
INSERT INTO public.word_semantic VALUES (1879, 203, 16);
INSERT INTO public.word_semantic VALUES (1882, 204, 7);
INSERT INTO public.word_semantic VALUES (1883, 204, 8);
INSERT INTO public.word_semantic VALUES (1884, 204, 5);
INSERT INTO public.word_semantic VALUES (1885, 204, 15);
INSERT INTO public.word_semantic VALUES (1886, 204, 32);
INSERT INTO public.word_semantic VALUES (1887, 204, 16);
INSERT INTO public.word_semantic VALUES (1890, 205, 7);
INSERT INTO public.word_semantic VALUES (1891, 205, 8);
INSERT INTO public.word_semantic VALUES (1892, 205, 5);
INSERT INTO public.word_semantic VALUES (1893, 205, 15);
INSERT INTO public.word_semantic VALUES (1894, 205, 32);
INSERT INTO public.word_semantic VALUES (1895, 205, 16);
INSERT INTO public.word_semantic VALUES (1898, 206, 7);
INSERT INTO public.word_semantic VALUES (1899, 206, 8);
INSERT INTO public.word_semantic VALUES (1900, 206, 5);
INSERT INTO public.word_semantic VALUES (1901, 206, 15);
INSERT INTO public.word_semantic VALUES (1902, 206, 32);
INSERT INTO public.word_semantic VALUES (1903, 206, 16);
INSERT INTO public.word_semantic VALUES (1906, 207, 7);
INSERT INTO public.word_semantic VALUES (1907, 207, 8);
INSERT INTO public.word_semantic VALUES (1908, 207, 5);
INSERT INTO public.word_semantic VALUES (1909, 207, 15);
INSERT INTO public.word_semantic VALUES (1910, 207, 32);
INSERT INTO public.word_semantic VALUES (1911, 207, 16);
INSERT INTO public.word_semantic VALUES (1914, 208, 7);
INSERT INTO public.word_semantic VALUES (1915, 208, 8);
INSERT INTO public.word_semantic VALUES (1916, 208, 5);
INSERT INTO public.word_semantic VALUES (1917, 208, 15);
INSERT INTO public.word_semantic VALUES (1918, 208, 32);
INSERT INTO public.word_semantic VALUES (1919, 208, 16);
INSERT INTO public.word_semantic VALUES (1922, 209, 7);
INSERT INTO public.word_semantic VALUES (1923, 209, 8);
INSERT INTO public.word_semantic VALUES (1924, 209, 5);
INSERT INTO public.word_semantic VALUES (1925, 209, 15);
INSERT INTO public.word_semantic VALUES (1926, 209, 32);
INSERT INTO public.word_semantic VALUES (1927, 209, 16);
INSERT INTO public.word_semantic VALUES (1930, 210, 7);
INSERT INTO public.word_semantic VALUES (1931, 210, 8);
INSERT INTO public.word_semantic VALUES (1932, 210, 5);
INSERT INTO public.word_semantic VALUES (1933, 210, 16);
INSERT INTO public.word_semantic VALUES (4777, 664, 67);
INSERT INTO public.word_semantic VALUES (4778, 664, 52);
INSERT INTO public.word_semantic VALUES (1936, 211, 7);
INSERT INTO public.word_semantic VALUES (1937, 211, 8);
INSERT INTO public.word_semantic VALUES (1938, 211, 5);
INSERT INTO public.word_semantic VALUES (1939, 211, 16);
INSERT INTO public.word_semantic VALUES (1942, 212, 7);
INSERT INTO public.word_semantic VALUES (1943, 212, 8);
INSERT INTO public.word_semantic VALUES (1944, 212, 5);
INSERT INTO public.word_semantic VALUES (1945, 212, 16);
INSERT INTO public.word_semantic VALUES (1948, 213, 7);
INSERT INTO public.word_semantic VALUES (1949, 213, 8);
INSERT INTO public.word_semantic VALUES (1950, 213, 5);
INSERT INTO public.word_semantic VALUES (1951, 213, 16);
INSERT INTO public.word_semantic VALUES (1954, 214, 7);
INSERT INTO public.word_semantic VALUES (1955, 214, 8);
INSERT INTO public.word_semantic VALUES (1956, 214, 5);
INSERT INTO public.word_semantic VALUES (1957, 214, 16);
INSERT INTO public.word_semantic VALUES (1960, 215, 7);
INSERT INTO public.word_semantic VALUES (1961, 215, 8);
INSERT INTO public.word_semantic VALUES (1962, 215, 5);
INSERT INTO public.word_semantic VALUES (1963, 215, 16);
INSERT INTO public.word_semantic VALUES (1966, 216, 7);
INSERT INTO public.word_semantic VALUES (1967, 216, 8);
INSERT INTO public.word_semantic VALUES (1968, 216, 5);
INSERT INTO public.word_semantic VALUES (1969, 216, 16);
INSERT INTO public.word_semantic VALUES (1972, 217, 7);
INSERT INTO public.word_semantic VALUES (1973, 217, 8);
INSERT INTO public.word_semantic VALUES (1974, 217, 5);
INSERT INTO public.word_semantic VALUES (1975, 217, 16);
INSERT INTO public.word_semantic VALUES (1978, 218, 7);
INSERT INTO public.word_semantic VALUES (1979, 218, 8);
INSERT INTO public.word_semantic VALUES (1980, 218, 5);
INSERT INTO public.word_semantic VALUES (1981, 218, 16);
INSERT INTO public.word_semantic VALUES (1984, 219, 7);
INSERT INTO public.word_semantic VALUES (1985, 219, 8);
INSERT INTO public.word_semantic VALUES (1986, 219, 5);
INSERT INTO public.word_semantic VALUES (1987, 219, 16);
INSERT INTO public.word_semantic VALUES (1990, 220, 7);
INSERT INTO public.word_semantic VALUES (1991, 220, 8);
INSERT INTO public.word_semantic VALUES (1992, 220, 5);
INSERT INTO public.word_semantic VALUES (1993, 220, 16);
INSERT INTO public.word_semantic VALUES (1996, 221, 7);
INSERT INTO public.word_semantic VALUES (1997, 221, 8);
INSERT INTO public.word_semantic VALUES (1998, 221, 5);
INSERT INTO public.word_semantic VALUES (1999, 221, 16);
INSERT INTO public.word_semantic VALUES (2002, 222, 36);
INSERT INTO public.word_semantic VALUES (2003, 222, 8);
INSERT INTO public.word_semantic VALUES (2004, 222, 37);
INSERT INTO public.word_semantic VALUES (2007, 223, 36);
INSERT INTO public.word_semantic VALUES (2008, 223, 8);
INSERT INTO public.word_semantic VALUES (2009, 223, 37);
INSERT INTO public.word_semantic VALUES (2012, 224, 36);
INSERT INTO public.word_semantic VALUES (2013, 224, 8);
INSERT INTO public.word_semantic VALUES (2014, 224, 37);
INSERT INTO public.word_semantic VALUES (2017, 225, 36);
INSERT INTO public.word_semantic VALUES (2018, 225, 8);
INSERT INTO public.word_semantic VALUES (2019, 225, 37);
INSERT INTO public.word_semantic VALUES (2022, 226, 36);
INSERT INTO public.word_semantic VALUES (2023, 226, 8);
INSERT INTO public.word_semantic VALUES (2024, 226, 34);
INSERT INTO public.word_semantic VALUES (2025, 226, 38);
INSERT INTO public.word_semantic VALUES (2026, 226, 5);
INSERT INTO public.word_semantic VALUES (2029, 227, 36);
INSERT INTO public.word_semantic VALUES (2030, 227, 8);
INSERT INTO public.word_semantic VALUES (2031, 227, 34);
INSERT INTO public.word_semantic VALUES (2032, 227, 38);
INSERT INTO public.word_semantic VALUES (2033, 227, 5);
INSERT INTO public.word_semantic VALUES (2036, 228, 36);
INSERT INTO public.word_semantic VALUES (2037, 228, 8);
INSERT INTO public.word_semantic VALUES (2038, 228, 34);
INSERT INTO public.word_semantic VALUES (2039, 228, 38);
INSERT INTO public.word_semantic VALUES (2040, 228, 5);
INSERT INTO public.word_semantic VALUES (2043, 229, 36);
INSERT INTO public.word_semantic VALUES (2044, 229, 8);
INSERT INTO public.word_semantic VALUES (2045, 229, 34);
INSERT INTO public.word_semantic VALUES (2046, 229, 38);
INSERT INTO public.word_semantic VALUES (2047, 229, 5);
INSERT INTO public.word_semantic VALUES (2050, 230, 36);
INSERT INTO public.word_semantic VALUES (2051, 230, 8);
INSERT INTO public.word_semantic VALUES (2052, 230, 35);
INSERT INTO public.word_semantic VALUES (2053, 230, 39);
INSERT INTO public.word_semantic VALUES (2054, 230, 40);
INSERT INTO public.word_semantic VALUES (2057, 231, 36);
INSERT INTO public.word_semantic VALUES (2058, 231, 8);
INSERT INTO public.word_semantic VALUES (2059, 231, 35);
INSERT INTO public.word_semantic VALUES (2060, 231, 39);
INSERT INTO public.word_semantic VALUES (2061, 231, 40);
INSERT INTO public.word_semantic VALUES (2064, 232, 36);
INSERT INTO public.word_semantic VALUES (2065, 232, 8);
INSERT INTO public.word_semantic VALUES (2066, 232, 35);
INSERT INTO public.word_semantic VALUES (2067, 232, 39);
INSERT INTO public.word_semantic VALUES (2068, 232, 40);
INSERT INTO public.word_semantic VALUES (2071, 233, 36);
INSERT INTO public.word_semantic VALUES (2072, 233, 8);
INSERT INTO public.word_semantic VALUES (2073, 233, 35);
INSERT INTO public.word_semantic VALUES (2074, 233, 39);
INSERT INTO public.word_semantic VALUES (2075, 233, 40);
INSERT INTO public.word_semantic VALUES (2078, 234, 36);
INSERT INTO public.word_semantic VALUES (2079, 234, 8);
INSERT INTO public.word_semantic VALUES (2080, 234, 35);
INSERT INTO public.word_semantic VALUES (2081, 234, 39);
INSERT INTO public.word_semantic VALUES (2082, 234, 40);
INSERT INTO public.word_semantic VALUES (2085, 235, 36);
INSERT INTO public.word_semantic VALUES (2086, 235, 8);
INSERT INTO public.word_semantic VALUES (2087, 235, 35);
INSERT INTO public.word_semantic VALUES (2088, 235, 39);
INSERT INTO public.word_semantic VALUES (2089, 235, 40);
INSERT INTO public.word_semantic VALUES (2092, 236, 36);
INSERT INTO public.word_semantic VALUES (2093, 236, 8);
INSERT INTO public.word_semantic VALUES (2094, 236, 35);
INSERT INTO public.word_semantic VALUES (2095, 236, 39);
INSERT INTO public.word_semantic VALUES (2096, 236, 40);
INSERT INTO public.word_semantic VALUES (2099, 237, 36);
INSERT INTO public.word_semantic VALUES (2100, 237, 8);
INSERT INTO public.word_semantic VALUES (2101, 237, 35);
INSERT INTO public.word_semantic VALUES (2102, 237, 39);
INSERT INTO public.word_semantic VALUES (2103, 237, 40);
INSERT INTO public.word_semantic VALUES (2106, 238, 36);
INSERT INTO public.word_semantic VALUES (2107, 238, 8);
INSERT INTO public.word_semantic VALUES (2108, 238, 35);
INSERT INTO public.word_semantic VALUES (2109, 238, 39);
INSERT INTO public.word_semantic VALUES (2110, 238, 40);
INSERT INTO public.word_semantic VALUES (2113, 239, 36);
INSERT INTO public.word_semantic VALUES (2114, 239, 8);
INSERT INTO public.word_semantic VALUES (2115, 239, 35);
INSERT INTO public.word_semantic VALUES (2116, 239, 39);
INSERT INTO public.word_semantic VALUES (2117, 239, 40);
INSERT INTO public.word_semantic VALUES (2120, 240, 36);
INSERT INTO public.word_semantic VALUES (2121, 240, 8);
INSERT INTO public.word_semantic VALUES (2122, 240, 35);
INSERT INTO public.word_semantic VALUES (2123, 240, 39);
INSERT INTO public.word_semantic VALUES (2124, 240, 40);
INSERT INTO public.word_semantic VALUES (2127, 241, 36);
INSERT INTO public.word_semantic VALUES (2128, 241, 8);
INSERT INTO public.word_semantic VALUES (2129, 241, 35);
INSERT INTO public.word_semantic VALUES (2130, 241, 39);
INSERT INTO public.word_semantic VALUES (2131, 241, 40);
INSERT INTO public.word_semantic VALUES (2134, 242, 36);
INSERT INTO public.word_semantic VALUES (2135, 242, 8);
INSERT INTO public.word_semantic VALUES (2136, 242, 35);
INSERT INTO public.word_semantic VALUES (2137, 242, 40);
INSERT INTO public.word_semantic VALUES (2140, 243, 36);
INSERT INTO public.word_semantic VALUES (2141, 243, 8);
INSERT INTO public.word_semantic VALUES (2142, 243, 35);
INSERT INTO public.word_semantic VALUES (2143, 243, 40);
INSERT INTO public.word_semantic VALUES (2146, 244, 36);
INSERT INTO public.word_semantic VALUES (2147, 244, 8);
INSERT INTO public.word_semantic VALUES (2148, 244, 35);
INSERT INTO public.word_semantic VALUES (2149, 244, 40);
INSERT INTO public.word_semantic VALUES (2152, 245, 36);
INSERT INTO public.word_semantic VALUES (2153, 245, 8);
INSERT INTO public.word_semantic VALUES (2154, 245, 35);
INSERT INTO public.word_semantic VALUES (2155, 245, 40);
INSERT INTO public.word_semantic VALUES (2158, 246, 36);
INSERT INTO public.word_semantic VALUES (2159, 246, 8);
INSERT INTO public.word_semantic VALUES (2160, 246, 35);
INSERT INTO public.word_semantic VALUES (2161, 246, 40);
INSERT INTO public.word_semantic VALUES (2164, 247, 36);
INSERT INTO public.word_semantic VALUES (2165, 247, 8);
INSERT INTO public.word_semantic VALUES (2166, 247, 35);
INSERT INTO public.word_semantic VALUES (2167, 247, 40);
INSERT INTO public.word_semantic VALUES (2170, 248, 36);
INSERT INTO public.word_semantic VALUES (2171, 248, 8);
INSERT INTO public.word_semantic VALUES (2172, 248, 35);
INSERT INTO public.word_semantic VALUES (2173, 248, 40);
INSERT INTO public.word_semantic VALUES (2176, 249, 36);
INSERT INTO public.word_semantic VALUES (2177, 249, 8);
INSERT INTO public.word_semantic VALUES (2178, 249, 35);
INSERT INTO public.word_semantic VALUES (2179, 249, 40);
INSERT INTO public.word_semantic VALUES (2182, 250, 36);
INSERT INTO public.word_semantic VALUES (2183, 250, 8);
INSERT INTO public.word_semantic VALUES (2184, 250, 35);
INSERT INTO public.word_semantic VALUES (2185, 250, 40);
INSERT INTO public.word_semantic VALUES (2188, 251, 36);
INSERT INTO public.word_semantic VALUES (2189, 251, 8);
INSERT INTO public.word_semantic VALUES (2190, 251, 35);
INSERT INTO public.word_semantic VALUES (2191, 251, 40);
INSERT INTO public.word_semantic VALUES (4780, 665, 67);
INSERT INTO public.word_semantic VALUES (2194, 252, 36);
INSERT INTO public.word_semantic VALUES (2195, 252, 8);
INSERT INTO public.word_semantic VALUES (2196, 252, 35);
INSERT INTO public.word_semantic VALUES (2197, 252, 40);
INSERT INTO public.word_semantic VALUES (4781, 665, 52);
INSERT INTO public.word_semantic VALUES (2200, 253, 36);
INSERT INTO public.word_semantic VALUES (2201, 253, 8);
INSERT INTO public.word_semantic VALUES (2202, 253, 35);
INSERT INTO public.word_semantic VALUES (2203, 253, 40);
INSERT INTO public.word_semantic VALUES (4783, 666, 67);
INSERT INTO public.word_semantic VALUES (4784, 666, 52);
INSERT INTO public.word_semantic VALUES (2206, 254, 36);
INSERT INTO public.word_semantic VALUES (2207, 254, 8);
INSERT INTO public.word_semantic VALUES (2208, 254, 5);
INSERT INTO public.word_semantic VALUES (4786, 667, 68);
INSERT INTO public.word_semantic VALUES (2211, 255, 36);
INSERT INTO public.word_semantic VALUES (2212, 255, 8);
INSERT INTO public.word_semantic VALUES (2213, 255, 5);
INSERT INTO public.word_semantic VALUES (2216, 256, 36);
INSERT INTO public.word_semantic VALUES (2217, 256, 8);
INSERT INTO public.word_semantic VALUES (2218, 256, 5);
INSERT INTO public.word_semantic VALUES (2221, 257, 36);
INSERT INTO public.word_semantic VALUES (2222, 257, 8);
INSERT INTO public.word_semantic VALUES (2223, 257, 5);
INSERT INTO public.word_semantic VALUES (2226, 258, 36);
INSERT INTO public.word_semantic VALUES (2227, 258, 8);
INSERT INTO public.word_semantic VALUES (2228, 258, 33);
INSERT INTO public.word_semantic VALUES (2231, 259, 36);
INSERT INTO public.word_semantic VALUES (2232, 259, 8);
INSERT INTO public.word_semantic VALUES (2233, 259, 33);
INSERT INTO public.word_semantic VALUES (2236, 260, 36);
INSERT INTO public.word_semantic VALUES (2237, 260, 8);
INSERT INTO public.word_semantic VALUES (2238, 260, 33);
INSERT INTO public.word_semantic VALUES (2241, 261, 36);
INSERT INTO public.word_semantic VALUES (2242, 261, 8);
INSERT INTO public.word_semantic VALUES (2243, 261, 33);
INSERT INTO public.word_semantic VALUES (2246, 262, 36);
INSERT INTO public.word_semantic VALUES (2247, 262, 8);
INSERT INTO public.word_semantic VALUES (2248, 262, 33);
INSERT INTO public.word_semantic VALUES (2249, 262, 41);
INSERT INTO public.word_semantic VALUES (2252, 263, 36);
INSERT INTO public.word_semantic VALUES (2253, 263, 8);
INSERT INTO public.word_semantic VALUES (2254, 263, 33);
INSERT INTO public.word_semantic VALUES (2255, 263, 41);
INSERT INTO public.word_semantic VALUES (2258, 264, 36);
INSERT INTO public.word_semantic VALUES (2259, 264, 8);
INSERT INTO public.word_semantic VALUES (2260, 264, 33);
INSERT INTO public.word_semantic VALUES (2261, 264, 41);
INSERT INTO public.word_semantic VALUES (2264, 265, 36);
INSERT INTO public.word_semantic VALUES (2265, 265, 8);
INSERT INTO public.word_semantic VALUES (2266, 265, 33);
INSERT INTO public.word_semantic VALUES (2267, 265, 41);
INSERT INTO public.word_semantic VALUES (2270, 266, 36);
INSERT INTO public.word_semantic VALUES (2271, 266, 8);
INSERT INTO public.word_semantic VALUES (2272, 266, 13);
INSERT INTO public.word_semantic VALUES (2275, 267, 36);
INSERT INTO public.word_semantic VALUES (2276, 267, 8);
INSERT INTO public.word_semantic VALUES (2277, 267, 13);
INSERT INTO public.word_semantic VALUES (2280, 268, 36);
INSERT INTO public.word_semantic VALUES (2281, 268, 8);
INSERT INTO public.word_semantic VALUES (2282, 268, 13);
INSERT INTO public.word_semantic VALUES (2285, 269, 36);
INSERT INTO public.word_semantic VALUES (2286, 269, 8);
INSERT INTO public.word_semantic VALUES (2287, 269, 13);
INSERT INTO public.word_semantic VALUES (2290, 270, 36);
INSERT INTO public.word_semantic VALUES (2291, 270, 8);
INSERT INTO public.word_semantic VALUES (2292, 270, 5);
INSERT INTO public.word_semantic VALUES (2295, 271, 36);
INSERT INTO public.word_semantic VALUES (2296, 271, 8);
INSERT INTO public.word_semantic VALUES (2297, 271, 5);
INSERT INTO public.word_semantic VALUES (2300, 272, 36);
INSERT INTO public.word_semantic VALUES (2301, 272, 8);
INSERT INTO public.word_semantic VALUES (2302, 272, 5);
INSERT INTO public.word_semantic VALUES (2305, 273, 36);
INSERT INTO public.word_semantic VALUES (2306, 273, 8);
INSERT INTO public.word_semantic VALUES (2307, 273, 5);
INSERT INTO public.word_semantic VALUES (2310, 274, 36);
INSERT INTO public.word_semantic VALUES (2311, 274, 8);
INSERT INTO public.word_semantic VALUES (2312, 274, 5);
INSERT INTO public.word_semantic VALUES (2315, 275, 36);
INSERT INTO public.word_semantic VALUES (2316, 275, 8);
INSERT INTO public.word_semantic VALUES (2317, 275, 5);
INSERT INTO public.word_semantic VALUES (2320, 276, 36);
INSERT INTO public.word_semantic VALUES (2321, 276, 8);
INSERT INTO public.word_semantic VALUES (2322, 276, 5);
INSERT INTO public.word_semantic VALUES (2325, 277, 36);
INSERT INTO public.word_semantic VALUES (2326, 277, 8);
INSERT INTO public.word_semantic VALUES (2327, 277, 5);
INSERT INTO public.word_semantic VALUES (2330, 278, 36);
INSERT INTO public.word_semantic VALUES (2331, 278, 8);
INSERT INTO public.word_semantic VALUES (2332, 278, 5);
INSERT INTO public.word_semantic VALUES (2335, 279, 36);
INSERT INTO public.word_semantic VALUES (2336, 279, 8);
INSERT INTO public.word_semantic VALUES (2337, 279, 5);
INSERT INTO public.word_semantic VALUES (2340, 280, 36);
INSERT INTO public.word_semantic VALUES (2341, 280, 8);
INSERT INTO public.word_semantic VALUES (2342, 280, 5);
INSERT INTO public.word_semantic VALUES (2345, 281, 36);
INSERT INTO public.word_semantic VALUES (2346, 281, 8);
INSERT INTO public.word_semantic VALUES (2347, 281, 5);
INSERT INTO public.word_semantic VALUES (2350, 282, 36);
INSERT INTO public.word_semantic VALUES (2351, 282, 8);
INSERT INTO public.word_semantic VALUES (2352, 282, 5);
INSERT INTO public.word_semantic VALUES (2355, 283, 36);
INSERT INTO public.word_semantic VALUES (2356, 283, 8);
INSERT INTO public.word_semantic VALUES (2357, 283, 5);
INSERT INTO public.word_semantic VALUES (2360, 284, 36);
INSERT INTO public.word_semantic VALUES (2361, 284, 8);
INSERT INTO public.word_semantic VALUES (2362, 284, 5);
INSERT INTO public.word_semantic VALUES (2365, 285, 36);
INSERT INTO public.word_semantic VALUES (2366, 285, 8);
INSERT INTO public.word_semantic VALUES (2367, 285, 5);
INSERT INTO public.word_semantic VALUES (2370, 286, 36);
INSERT INTO public.word_semantic VALUES (2371, 286, 8);
INSERT INTO public.word_semantic VALUES (2372, 286, 5);
INSERT INTO public.word_semantic VALUES (2375, 287, 36);
INSERT INTO public.word_semantic VALUES (2376, 287, 8);
INSERT INTO public.word_semantic VALUES (2377, 287, 5);
INSERT INTO public.word_semantic VALUES (2380, 288, 36);
INSERT INTO public.word_semantic VALUES (2381, 288, 8);
INSERT INTO public.word_semantic VALUES (2382, 288, 5);
INSERT INTO public.word_semantic VALUES (2385, 289, 36);
INSERT INTO public.word_semantic VALUES (2386, 289, 8);
INSERT INTO public.word_semantic VALUES (2387, 289, 5);
INSERT INTO public.word_semantic VALUES (2390, 290, 36);
INSERT INTO public.word_semantic VALUES (2391, 290, 8);
INSERT INTO public.word_semantic VALUES (2392, 290, 5);
INSERT INTO public.word_semantic VALUES (2395, 291, 36);
INSERT INTO public.word_semantic VALUES (2396, 291, 8);
INSERT INTO public.word_semantic VALUES (2397, 291, 5);
INSERT INTO public.word_semantic VALUES (2400, 292, 36);
INSERT INTO public.word_semantic VALUES (2401, 292, 8);
INSERT INTO public.word_semantic VALUES (2402, 292, 5);
INSERT INTO public.word_semantic VALUES (2405, 293, 36);
INSERT INTO public.word_semantic VALUES (2406, 293, 8);
INSERT INTO public.word_semantic VALUES (2407, 293, 5);
INSERT INTO public.word_semantic VALUES (2410, 294, 36);
INSERT INTO public.word_semantic VALUES (2411, 294, 8);
INSERT INTO public.word_semantic VALUES (2412, 294, 5);
INSERT INTO public.word_semantic VALUES (2415, 295, 36);
INSERT INTO public.word_semantic VALUES (2416, 295, 8);
INSERT INTO public.word_semantic VALUES (2417, 295, 5);
INSERT INTO public.word_semantic VALUES (2420, 296, 36);
INSERT INTO public.word_semantic VALUES (2421, 296, 8);
INSERT INTO public.word_semantic VALUES (2422, 296, 5);
INSERT INTO public.word_semantic VALUES (2425, 297, 36);
INSERT INTO public.word_semantic VALUES (2426, 297, 8);
INSERT INTO public.word_semantic VALUES (2427, 297, 5);
INSERT INTO public.word_semantic VALUES (2430, 298, 36);
INSERT INTO public.word_semantic VALUES (2431, 298, 8);
INSERT INTO public.word_semantic VALUES (2432, 298, 5);
INSERT INTO public.word_semantic VALUES (2435, 299, 36);
INSERT INTO public.word_semantic VALUES (2436, 299, 8);
INSERT INTO public.word_semantic VALUES (2437, 299, 5);
INSERT INTO public.word_semantic VALUES (2440, 300, 36);
INSERT INTO public.word_semantic VALUES (2441, 300, 8);
INSERT INTO public.word_semantic VALUES (2442, 300, 5);
INSERT INTO public.word_semantic VALUES (2445, 301, 36);
INSERT INTO public.word_semantic VALUES (2446, 301, 8);
INSERT INTO public.word_semantic VALUES (2447, 301, 5);
INSERT INTO public.word_semantic VALUES (2452, 302, 36);
INSERT INTO public.word_semantic VALUES (2453, 302, 8);
INSERT INTO public.word_semantic VALUES (2454, 302, 9);
INSERT INTO public.word_semantic VALUES (2455, 302, 5);
INSERT INTO public.word_semantic VALUES (2456, 302, 42);
INSERT INTO public.word_semantic VALUES (2457, 302, 43);
INSERT INTO public.word_semantic VALUES (2462, 303, 36);
INSERT INTO public.word_semantic VALUES (2463, 303, 8);
INSERT INTO public.word_semantic VALUES (2464, 303, 9);
INSERT INTO public.word_semantic VALUES (2465, 303, 5);
INSERT INTO public.word_semantic VALUES (2466, 303, 42);
INSERT INTO public.word_semantic VALUES (2467, 303, 43);
INSERT INTO public.word_semantic VALUES (4787, 667, 52);
INSERT INTO public.word_semantic VALUES (2472, 304, 36);
INSERT INTO public.word_semantic VALUES (2473, 304, 8);
INSERT INTO public.word_semantic VALUES (2474, 304, 9);
INSERT INTO public.word_semantic VALUES (2475, 304, 5);
INSERT INTO public.word_semantic VALUES (2476, 304, 42);
INSERT INTO public.word_semantic VALUES (2477, 304, 43);
INSERT INTO public.word_semantic VALUES (4789, 668, 57);
INSERT INTO public.word_semantic VALUES (2482, 305, 36);
INSERT INTO public.word_semantic VALUES (2483, 305, 8);
INSERT INTO public.word_semantic VALUES (2484, 305, 9);
INSERT INTO public.word_semantic VALUES (2485, 305, 5);
INSERT INTO public.word_semantic VALUES (2486, 305, 42);
INSERT INTO public.word_semantic VALUES (2487, 305, 43);
INSERT INTO public.word_semantic VALUES (2492, 306, 36);
INSERT INTO public.word_semantic VALUES (2493, 306, 8);
INSERT INTO public.word_semantic VALUES (2494, 306, 9);
INSERT INTO public.word_semantic VALUES (2495, 306, 5);
INSERT INTO public.word_semantic VALUES (2496, 306, 42);
INSERT INTO public.word_semantic VALUES (2497, 306, 43);
INSERT INTO public.word_semantic VALUES (2502, 307, 36);
INSERT INTO public.word_semantic VALUES (2503, 307, 8);
INSERT INTO public.word_semantic VALUES (2504, 307, 9);
INSERT INTO public.word_semantic VALUES (2505, 307, 5);
INSERT INTO public.word_semantic VALUES (2506, 307, 42);
INSERT INTO public.word_semantic VALUES (2507, 307, 43);
INSERT INTO public.word_semantic VALUES (2512, 308, 36);
INSERT INTO public.word_semantic VALUES (2513, 308, 8);
INSERT INTO public.word_semantic VALUES (2514, 308, 9);
INSERT INTO public.word_semantic VALUES (2515, 308, 5);
INSERT INTO public.word_semantic VALUES (2516, 308, 42);
INSERT INTO public.word_semantic VALUES (2517, 308, 43);
INSERT INTO public.word_semantic VALUES (2522, 309, 36);
INSERT INTO public.word_semantic VALUES (2523, 309, 8);
INSERT INTO public.word_semantic VALUES (2524, 309, 9);
INSERT INTO public.word_semantic VALUES (2525, 309, 5);
INSERT INTO public.word_semantic VALUES (2526, 309, 42);
INSERT INTO public.word_semantic VALUES (2527, 309, 43);
INSERT INTO public.word_semantic VALUES (2532, 310, 36);
INSERT INTO public.word_semantic VALUES (2533, 310, 8);
INSERT INTO public.word_semantic VALUES (2534, 310, 9);
INSERT INTO public.word_semantic VALUES (2535, 310, 5);
INSERT INTO public.word_semantic VALUES (2536, 310, 42);
INSERT INTO public.word_semantic VALUES (2537, 310, 43);
INSERT INTO public.word_semantic VALUES (2542, 311, 36);
INSERT INTO public.word_semantic VALUES (2543, 311, 8);
INSERT INTO public.word_semantic VALUES (2544, 311, 9);
INSERT INTO public.word_semantic VALUES (2545, 311, 5);
INSERT INTO public.word_semantic VALUES (2546, 311, 42);
INSERT INTO public.word_semantic VALUES (2547, 311, 43);
INSERT INTO public.word_semantic VALUES (2552, 312, 36);
INSERT INTO public.word_semantic VALUES (2553, 312, 8);
INSERT INTO public.word_semantic VALUES (2554, 312, 9);
INSERT INTO public.word_semantic VALUES (2555, 312, 5);
INSERT INTO public.word_semantic VALUES (2556, 312, 42);
INSERT INTO public.word_semantic VALUES (2557, 312, 43);
INSERT INTO public.word_semantic VALUES (2562, 313, 36);
INSERT INTO public.word_semantic VALUES (2563, 313, 8);
INSERT INTO public.word_semantic VALUES (2564, 313, 9);
INSERT INTO public.word_semantic VALUES (2565, 313, 5);
INSERT INTO public.word_semantic VALUES (2566, 313, 42);
INSERT INTO public.word_semantic VALUES (2567, 313, 43);
INSERT INTO public.word_semantic VALUES (2572, 314, 36);
INSERT INTO public.word_semantic VALUES (2573, 314, 8);
INSERT INTO public.word_semantic VALUES (2574, 314, 9);
INSERT INTO public.word_semantic VALUES (2575, 314, 5);
INSERT INTO public.word_semantic VALUES (2576, 314, 42);
INSERT INTO public.word_semantic VALUES (2577, 314, 43);
INSERT INTO public.word_semantic VALUES (2582, 315, 36);
INSERT INTO public.word_semantic VALUES (2583, 315, 8);
INSERT INTO public.word_semantic VALUES (2584, 315, 9);
INSERT INTO public.word_semantic VALUES (2585, 315, 5);
INSERT INTO public.word_semantic VALUES (2586, 315, 42);
INSERT INTO public.word_semantic VALUES (2587, 315, 43);
INSERT INTO public.word_semantic VALUES (2592, 316, 36);
INSERT INTO public.word_semantic VALUES (2593, 316, 8);
INSERT INTO public.word_semantic VALUES (2594, 316, 9);
INSERT INTO public.word_semantic VALUES (2595, 316, 5);
INSERT INTO public.word_semantic VALUES (2596, 316, 42);
INSERT INTO public.word_semantic VALUES (2597, 316, 43);
INSERT INTO public.word_semantic VALUES (2602, 317, 36);
INSERT INTO public.word_semantic VALUES (2603, 317, 8);
INSERT INTO public.word_semantic VALUES (2604, 317, 9);
INSERT INTO public.word_semantic VALUES (2605, 317, 5);
INSERT INTO public.word_semantic VALUES (2606, 317, 42);
INSERT INTO public.word_semantic VALUES (2607, 317, 43);
INSERT INTO public.word_semantic VALUES (2610, 318, 36);
INSERT INTO public.word_semantic VALUES (2611, 318, 8);
INSERT INTO public.word_semantic VALUES (2612, 318, 5);
INSERT INTO public.word_semantic VALUES (2615, 319, 36);
INSERT INTO public.word_semantic VALUES (2616, 319, 8);
INSERT INTO public.word_semantic VALUES (2617, 319, 5);
INSERT INTO public.word_semantic VALUES (2620, 320, 36);
INSERT INTO public.word_semantic VALUES (2621, 320, 8);
INSERT INTO public.word_semantic VALUES (2622, 320, 5);
INSERT INTO public.word_semantic VALUES (2625, 321, 36);
INSERT INTO public.word_semantic VALUES (2626, 321, 8);
INSERT INTO public.word_semantic VALUES (2627, 321, 5);
INSERT INTO public.word_semantic VALUES (2630, 322, 36);
INSERT INTO public.word_semantic VALUES (2631, 322, 8);
INSERT INTO public.word_semantic VALUES (2632, 322, 5);
INSERT INTO public.word_semantic VALUES (2635, 323, 36);
INSERT INTO public.word_semantic VALUES (2636, 323, 8);
INSERT INTO public.word_semantic VALUES (2637, 323, 5);
INSERT INTO public.word_semantic VALUES (2640, 324, 36);
INSERT INTO public.word_semantic VALUES (2641, 324, 8);
INSERT INTO public.word_semantic VALUES (2642, 324, 5);
INSERT INTO public.word_semantic VALUES (2645, 325, 36);
INSERT INTO public.word_semantic VALUES (2646, 325, 8);
INSERT INTO public.word_semantic VALUES (2647, 325, 5);
INSERT INTO public.word_semantic VALUES (2650, 326, 36);
INSERT INTO public.word_semantic VALUES (2651, 326, 8);
INSERT INTO public.word_semantic VALUES (2652, 326, 5);
INSERT INTO public.word_semantic VALUES (2653, 326, 9);
INSERT INTO public.word_semantic VALUES (2656, 327, 36);
INSERT INTO public.word_semantic VALUES (2657, 327, 8);
INSERT INTO public.word_semantic VALUES (2658, 327, 5);
INSERT INTO public.word_semantic VALUES (2659, 327, 9);
INSERT INTO public.word_semantic VALUES (2662, 328, 36);
INSERT INTO public.word_semantic VALUES (2663, 328, 8);
INSERT INTO public.word_semantic VALUES (2664, 328, 5);
INSERT INTO public.word_semantic VALUES (2665, 328, 9);
INSERT INTO public.word_semantic VALUES (2668, 329, 36);
INSERT INTO public.word_semantic VALUES (2669, 329, 8);
INSERT INTO public.word_semantic VALUES (2670, 329, 5);
INSERT INTO public.word_semantic VALUES (2671, 329, 9);
INSERT INTO public.word_semantic VALUES (2674, 330, 36);
INSERT INTO public.word_semantic VALUES (2675, 330, 8);
INSERT INTO public.word_semantic VALUES (2676, 330, 5);
INSERT INTO public.word_semantic VALUES (2677, 330, 9);
INSERT INTO public.word_semantic VALUES (2680, 331, 36);
INSERT INTO public.word_semantic VALUES (2681, 331, 8);
INSERT INTO public.word_semantic VALUES (2682, 331, 5);
INSERT INTO public.word_semantic VALUES (2683, 331, 9);
INSERT INTO public.word_semantic VALUES (2686, 332, 36);
INSERT INTO public.word_semantic VALUES (2687, 332, 8);
INSERT INTO public.word_semantic VALUES (2688, 332, 5);
INSERT INTO public.word_semantic VALUES (2689, 332, 9);
INSERT INTO public.word_semantic VALUES (2692, 333, 36);
INSERT INTO public.word_semantic VALUES (2693, 333, 8);
INSERT INTO public.word_semantic VALUES (2694, 333, 5);
INSERT INTO public.word_semantic VALUES (2695, 333, 9);
INSERT INTO public.word_semantic VALUES (2698, 334, 36);
INSERT INTO public.word_semantic VALUES (2699, 334, 8);
INSERT INTO public.word_semantic VALUES (2700, 334, 5);
INSERT INTO public.word_semantic VALUES (2703, 335, 36);
INSERT INTO public.word_semantic VALUES (2704, 335, 8);
INSERT INTO public.word_semantic VALUES (2705, 335, 5);
INSERT INTO public.word_semantic VALUES (2708, 336, 36);
INSERT INTO public.word_semantic VALUES (2709, 336, 8);
INSERT INTO public.word_semantic VALUES (2710, 336, 5);
INSERT INTO public.word_semantic VALUES (2713, 337, 36);
INSERT INTO public.word_semantic VALUES (2714, 337, 8);
INSERT INTO public.word_semantic VALUES (2715, 337, 5);
INSERT INTO public.word_semantic VALUES (2718, 338, 36);
INSERT INTO public.word_semantic VALUES (2719, 338, 8);
INSERT INTO public.word_semantic VALUES (2720, 338, 5);
INSERT INTO public.word_semantic VALUES (2721, 338, 16);
INSERT INTO public.word_semantic VALUES (2724, 339, 36);
INSERT INTO public.word_semantic VALUES (2725, 339, 8);
INSERT INTO public.word_semantic VALUES (2726, 339, 5);
INSERT INTO public.word_semantic VALUES (2727, 339, 16);
INSERT INTO public.word_semantic VALUES (2730, 340, 36);
INSERT INTO public.word_semantic VALUES (2731, 340, 8);
INSERT INTO public.word_semantic VALUES (2732, 340, 5);
INSERT INTO public.word_semantic VALUES (2733, 340, 16);
INSERT INTO public.word_semantic VALUES (2736, 341, 36);
INSERT INTO public.word_semantic VALUES (2737, 341, 8);
INSERT INTO public.word_semantic VALUES (2738, 341, 5);
INSERT INTO public.word_semantic VALUES (2739, 341, 16);
INSERT INTO public.word_semantic VALUES (2742, 342, 36);
INSERT INTO public.word_semantic VALUES (2743, 342, 8);
INSERT INTO public.word_semantic VALUES (2744, 342, 5);
INSERT INTO public.word_semantic VALUES (2745, 342, 16);
INSERT INTO public.word_semantic VALUES (2746, 342, 9);
INSERT INTO public.word_semantic VALUES (4790, 668, 52);
INSERT INTO public.word_semantic VALUES (2749, 343, 36);
INSERT INTO public.word_semantic VALUES (2750, 343, 8);
INSERT INTO public.word_semantic VALUES (2751, 343, 5);
INSERT INTO public.word_semantic VALUES (2752, 343, 16);
INSERT INTO public.word_semantic VALUES (2753, 343, 9);
INSERT INTO public.word_semantic VALUES (4792, 669, 57);
INSERT INTO public.word_semantic VALUES (2756, 344, 36);
INSERT INTO public.word_semantic VALUES (2757, 344, 8);
INSERT INTO public.word_semantic VALUES (2758, 344, 5);
INSERT INTO public.word_semantic VALUES (2759, 344, 16);
INSERT INTO public.word_semantic VALUES (2760, 344, 9);
INSERT INTO public.word_semantic VALUES (2763, 345, 36);
INSERT INTO public.word_semantic VALUES (2764, 345, 8);
INSERT INTO public.word_semantic VALUES (2765, 345, 5);
INSERT INTO public.word_semantic VALUES (2766, 345, 16);
INSERT INTO public.word_semantic VALUES (2767, 345, 9);
INSERT INTO public.word_semantic VALUES (2770, 346, 36);
INSERT INTO public.word_semantic VALUES (2771, 346, 8);
INSERT INTO public.word_semantic VALUES (2772, 346, 5);
INSERT INTO public.word_semantic VALUES (2773, 346, 16);
INSERT INTO public.word_semantic VALUES (2774, 346, 9);
INSERT INTO public.word_semantic VALUES (2777, 347, 36);
INSERT INTO public.word_semantic VALUES (2778, 347, 8);
INSERT INTO public.word_semantic VALUES (2779, 347, 5);
INSERT INTO public.word_semantic VALUES (2780, 347, 16);
INSERT INTO public.word_semantic VALUES (2781, 347, 9);
INSERT INTO public.word_semantic VALUES (2784, 348, 36);
INSERT INTO public.word_semantic VALUES (2785, 348, 8);
INSERT INTO public.word_semantic VALUES (2786, 348, 5);
INSERT INTO public.word_semantic VALUES (2787, 348, 16);
INSERT INTO public.word_semantic VALUES (2788, 348, 9);
INSERT INTO public.word_semantic VALUES (2791, 349, 36);
INSERT INTO public.word_semantic VALUES (2792, 349, 8);
INSERT INTO public.word_semantic VALUES (2793, 349, 5);
INSERT INTO public.word_semantic VALUES (2794, 349, 16);
INSERT INTO public.word_semantic VALUES (2795, 349, 9);
INSERT INTO public.word_semantic VALUES (2798, 350, 36);
INSERT INTO public.word_semantic VALUES (2799, 350, 8);
INSERT INTO public.word_semantic VALUES (2800, 350, 5);
INSERT INTO public.word_semantic VALUES (2801, 350, 16);
INSERT INTO public.word_semantic VALUES (2802, 350, 9);
INSERT INTO public.word_semantic VALUES (2805, 351, 36);
INSERT INTO public.word_semantic VALUES (2806, 351, 8);
INSERT INTO public.word_semantic VALUES (2807, 351, 5);
INSERT INTO public.word_semantic VALUES (2808, 351, 16);
INSERT INTO public.word_semantic VALUES (2809, 351, 9);
INSERT INTO public.word_semantic VALUES (2812, 352, 36);
INSERT INTO public.word_semantic VALUES (2813, 352, 8);
INSERT INTO public.word_semantic VALUES (2814, 352, 5);
INSERT INTO public.word_semantic VALUES (2815, 352, 16);
INSERT INTO public.word_semantic VALUES (2816, 352, 9);
INSERT INTO public.word_semantic VALUES (2819, 353, 36);
INSERT INTO public.word_semantic VALUES (2820, 353, 8);
INSERT INTO public.word_semantic VALUES (2821, 353, 5);
INSERT INTO public.word_semantic VALUES (2822, 353, 16);
INSERT INTO public.word_semantic VALUES (2823, 353, 9);
INSERT INTO public.word_semantic VALUES (2826, 354, 36);
INSERT INTO public.word_semantic VALUES (2827, 354, 8);
INSERT INTO public.word_semantic VALUES (2828, 354, 5);
INSERT INTO public.word_semantic VALUES (2829, 354, 34);
INSERT INTO public.word_semantic VALUES (2832, 355, 36);
INSERT INTO public.word_semantic VALUES (2833, 355, 8);
INSERT INTO public.word_semantic VALUES (2834, 355, 5);
INSERT INTO public.word_semantic VALUES (2835, 355, 34);
INSERT INTO public.word_semantic VALUES (2838, 356, 36);
INSERT INTO public.word_semantic VALUES (2839, 356, 8);
INSERT INTO public.word_semantic VALUES (2840, 356, 5);
INSERT INTO public.word_semantic VALUES (2841, 356, 34);
INSERT INTO public.word_semantic VALUES (2844, 357, 36);
INSERT INTO public.word_semantic VALUES (2845, 357, 8);
INSERT INTO public.word_semantic VALUES (2846, 357, 5);
INSERT INTO public.word_semantic VALUES (2847, 357, 34);
INSERT INTO public.word_semantic VALUES (2850, 358, 36);
INSERT INTO public.word_semantic VALUES (2851, 358, 8);
INSERT INTO public.word_semantic VALUES (2852, 358, 15);
INSERT INTO public.word_semantic VALUES (2853, 358, 34);
INSERT INTO public.word_semantic VALUES (2854, 358, 44);
INSERT INTO public.word_semantic VALUES (2857, 359, 36);
INSERT INTO public.word_semantic VALUES (2858, 359, 8);
INSERT INTO public.word_semantic VALUES (2859, 359, 15);
INSERT INTO public.word_semantic VALUES (2860, 359, 34);
INSERT INTO public.word_semantic VALUES (2861, 359, 44);
INSERT INTO public.word_semantic VALUES (2864, 360, 36);
INSERT INTO public.word_semantic VALUES (2865, 360, 8);
INSERT INTO public.word_semantic VALUES (2866, 360, 15);
INSERT INTO public.word_semantic VALUES (2867, 360, 34);
INSERT INTO public.word_semantic VALUES (2868, 360, 44);
INSERT INTO public.word_semantic VALUES (2871, 361, 36);
INSERT INTO public.word_semantic VALUES (2872, 361, 8);
INSERT INTO public.word_semantic VALUES (2873, 361, 15);
INSERT INTO public.word_semantic VALUES (2874, 361, 34);
INSERT INTO public.word_semantic VALUES (2875, 361, 44);
INSERT INTO public.word_semantic VALUES (2878, 362, 36);
INSERT INTO public.word_semantic VALUES (2879, 362, 8);
INSERT INTO public.word_semantic VALUES (2880, 362, 15);
INSERT INTO public.word_semantic VALUES (2881, 362, 34);
INSERT INTO public.word_semantic VALUES (2882, 362, 44);
INSERT INTO public.word_semantic VALUES (2885, 363, 36);
INSERT INTO public.word_semantic VALUES (2886, 363, 8);
INSERT INTO public.word_semantic VALUES (2887, 363, 15);
INSERT INTO public.word_semantic VALUES (2888, 363, 34);
INSERT INTO public.word_semantic VALUES (2889, 363, 44);
INSERT INTO public.word_semantic VALUES (2892, 364, 36);
INSERT INTO public.word_semantic VALUES (2893, 364, 8);
INSERT INTO public.word_semantic VALUES (2894, 364, 15);
INSERT INTO public.word_semantic VALUES (2895, 364, 34);
INSERT INTO public.word_semantic VALUES (2896, 364, 44);
INSERT INTO public.word_semantic VALUES (2899, 365, 36);
INSERT INTO public.word_semantic VALUES (2900, 365, 8);
INSERT INTO public.word_semantic VALUES (2901, 365, 15);
INSERT INTO public.word_semantic VALUES (2902, 365, 34);
INSERT INTO public.word_semantic VALUES (2903, 365, 44);
INSERT INTO public.word_semantic VALUES (2906, 366, 36);
INSERT INTO public.word_semantic VALUES (2907, 366, 8);
INSERT INTO public.word_semantic VALUES (2908, 366, 15);
INSERT INTO public.word_semantic VALUES (2909, 366, 34);
INSERT INTO public.word_semantic VALUES (2910, 366, 44);
INSERT INTO public.word_semantic VALUES (2913, 367, 36);
INSERT INTO public.word_semantic VALUES (2914, 367, 8);
INSERT INTO public.word_semantic VALUES (2915, 367, 15);
INSERT INTO public.word_semantic VALUES (2916, 367, 34);
INSERT INTO public.word_semantic VALUES (2917, 367, 44);
INSERT INTO public.word_semantic VALUES (2920, 368, 36);
INSERT INTO public.word_semantic VALUES (2921, 368, 8);
INSERT INTO public.word_semantic VALUES (2922, 368, 15);
INSERT INTO public.word_semantic VALUES (2923, 368, 34);
INSERT INTO public.word_semantic VALUES (2924, 368, 44);
INSERT INTO public.word_semantic VALUES (2927, 369, 36);
INSERT INTO public.word_semantic VALUES (2928, 369, 8);
INSERT INTO public.word_semantic VALUES (2929, 369, 15);
INSERT INTO public.word_semantic VALUES (2930, 369, 34);
INSERT INTO public.word_semantic VALUES (2931, 369, 44);
INSERT INTO public.word_semantic VALUES (2934, 370, 36);
INSERT INTO public.word_semantic VALUES (2935, 370, 8);
INSERT INTO public.word_semantic VALUES (2936, 370, 5);
INSERT INTO public.word_semantic VALUES (2939, 371, 36);
INSERT INTO public.word_semantic VALUES (2940, 371, 8);
INSERT INTO public.word_semantic VALUES (2941, 371, 5);
INSERT INTO public.word_semantic VALUES (2944, 372, 36);
INSERT INTO public.word_semantic VALUES (2945, 372, 8);
INSERT INTO public.word_semantic VALUES (2946, 372, 5);
INSERT INTO public.word_semantic VALUES (2949, 373, 36);
INSERT INTO public.word_semantic VALUES (2950, 373, 8);
INSERT INTO public.word_semantic VALUES (2951, 373, 5);
INSERT INTO public.word_semantic VALUES (2954, 374, 36);
INSERT INTO public.word_semantic VALUES (2955, 374, 8);
INSERT INTO public.word_semantic VALUES (2956, 374, 5);
INSERT INTO public.word_semantic VALUES (2959, 375, 36);
INSERT INTO public.word_semantic VALUES (2960, 375, 8);
INSERT INTO public.word_semantic VALUES (2961, 375, 5);
INSERT INTO public.word_semantic VALUES (2964, 376, 36);
INSERT INTO public.word_semantic VALUES (2965, 376, 8);
INSERT INTO public.word_semantic VALUES (2966, 376, 5);
INSERT INTO public.word_semantic VALUES (2969, 377, 36);
INSERT INTO public.word_semantic VALUES (2970, 377, 8);
INSERT INTO public.word_semantic VALUES (2971, 377, 5);
INSERT INTO public.word_semantic VALUES (2974, 378, 36);
INSERT INTO public.word_semantic VALUES (2975, 378, 8);
INSERT INTO public.word_semantic VALUES (2976, 378, 5);
INSERT INTO public.word_semantic VALUES (2979, 379, 36);
INSERT INTO public.word_semantic VALUES (2980, 379, 8);
INSERT INTO public.word_semantic VALUES (2981, 379, 5);
INSERT INTO public.word_semantic VALUES (2984, 380, 36);
INSERT INTO public.word_semantic VALUES (2985, 380, 8);
INSERT INTO public.word_semantic VALUES (2986, 380, 5);
INSERT INTO public.word_semantic VALUES (2989, 381, 36);
INSERT INTO public.word_semantic VALUES (2990, 381, 8);
INSERT INTO public.word_semantic VALUES (2991, 381, 5);
INSERT INTO public.word_semantic VALUES (2994, 382, 36);
INSERT INTO public.word_semantic VALUES (2995, 382, 8);
INSERT INTO public.word_semantic VALUES (2996, 382, 5);
INSERT INTO public.word_semantic VALUES (2997, 382, 34);
INSERT INTO public.word_semantic VALUES (3000, 383, 36);
INSERT INTO public.word_semantic VALUES (3001, 383, 8);
INSERT INTO public.word_semantic VALUES (3002, 383, 5);
INSERT INTO public.word_semantic VALUES (3003, 383, 34);
INSERT INTO public.word_semantic VALUES (4793, 669, 52);
INSERT INTO public.word_semantic VALUES (3006, 384, 36);
INSERT INTO public.word_semantic VALUES (3007, 384, 8);
INSERT INTO public.word_semantic VALUES (3008, 384, 5);
INSERT INTO public.word_semantic VALUES (3009, 384, 34);
INSERT INTO public.word_semantic VALUES (3012, 385, 36);
INSERT INTO public.word_semantic VALUES (3013, 385, 8);
INSERT INTO public.word_semantic VALUES (3014, 385, 5);
INSERT INTO public.word_semantic VALUES (3015, 385, 34);
INSERT INTO public.word_semantic VALUES (3018, 386, 36);
INSERT INTO public.word_semantic VALUES (3019, 386, 8);
INSERT INTO public.word_semantic VALUES (3020, 386, 5);
INSERT INTO public.word_semantic VALUES (3021, 386, 34);
INSERT INTO public.word_semantic VALUES (3024, 387, 36);
INSERT INTO public.word_semantic VALUES (3025, 387, 8);
INSERT INTO public.word_semantic VALUES (3026, 387, 5);
INSERT INTO public.word_semantic VALUES (3027, 387, 34);
INSERT INTO public.word_semantic VALUES (3030, 388, 36);
INSERT INTO public.word_semantic VALUES (3031, 388, 8);
INSERT INTO public.word_semantic VALUES (3032, 388, 5);
INSERT INTO public.word_semantic VALUES (3033, 388, 34);
INSERT INTO public.word_semantic VALUES (3036, 389, 36);
INSERT INTO public.word_semantic VALUES (3037, 389, 8);
INSERT INTO public.word_semantic VALUES (3038, 389, 5);
INSERT INTO public.word_semantic VALUES (3039, 389, 34);
INSERT INTO public.word_semantic VALUES (3042, 390, 36);
INSERT INTO public.word_semantic VALUES (3043, 390, 8);
INSERT INTO public.word_semantic VALUES (3044, 390, 5);
INSERT INTO public.word_semantic VALUES (3045, 390, 34);
INSERT INTO public.word_semantic VALUES (3046, 390, 45);
INSERT INTO public.word_semantic VALUES (3049, 391, 36);
INSERT INTO public.word_semantic VALUES (3050, 391, 8);
INSERT INTO public.word_semantic VALUES (3051, 391, 5);
INSERT INTO public.word_semantic VALUES (3052, 391, 34);
INSERT INTO public.word_semantic VALUES (3053, 391, 45);
INSERT INTO public.word_semantic VALUES (3056, 392, 36);
INSERT INTO public.word_semantic VALUES (3057, 392, 8);
INSERT INTO public.word_semantic VALUES (3058, 392, 5);
INSERT INTO public.word_semantic VALUES (3059, 392, 34);
INSERT INTO public.word_semantic VALUES (3060, 392, 45);
INSERT INTO public.word_semantic VALUES (3063, 393, 36);
INSERT INTO public.word_semantic VALUES (3064, 393, 8);
INSERT INTO public.word_semantic VALUES (3065, 393, 5);
INSERT INTO public.word_semantic VALUES (3066, 393, 34);
INSERT INTO public.word_semantic VALUES (3067, 393, 45);
INSERT INTO public.word_semantic VALUES (3070, 394, 36);
INSERT INTO public.word_semantic VALUES (3071, 394, 8);
INSERT INTO public.word_semantic VALUES (3072, 394, 34);
INSERT INTO public.word_semantic VALUES (3073, 394, 45);
INSERT INTO public.word_semantic VALUES (3076, 395, 36);
INSERT INTO public.word_semantic VALUES (3077, 395, 8);
INSERT INTO public.word_semantic VALUES (3078, 395, 34);
INSERT INTO public.word_semantic VALUES (3079, 395, 45);
INSERT INTO public.word_semantic VALUES (3082, 396, 36);
INSERT INTO public.word_semantic VALUES (3083, 396, 8);
INSERT INTO public.word_semantic VALUES (3084, 396, 34);
INSERT INTO public.word_semantic VALUES (3085, 396, 45);
INSERT INTO public.word_semantic VALUES (3088, 397, 36);
INSERT INTO public.word_semantic VALUES (3089, 397, 8);
INSERT INTO public.word_semantic VALUES (3090, 397, 34);
INSERT INTO public.word_semantic VALUES (3091, 397, 45);
INSERT INTO public.word_semantic VALUES (3094, 398, 36);
INSERT INTO public.word_semantic VALUES (3095, 398, 8);
INSERT INTO public.word_semantic VALUES (3096, 398, 34);
INSERT INTO public.word_semantic VALUES (3097, 398, 11);
INSERT INTO public.word_semantic VALUES (3100, 399, 36);
INSERT INTO public.word_semantic VALUES (3101, 399, 8);
INSERT INTO public.word_semantic VALUES (3102, 399, 34);
INSERT INTO public.word_semantic VALUES (3103, 399, 11);
INSERT INTO public.word_semantic VALUES (3106, 400, 36);
INSERT INTO public.word_semantic VALUES (3107, 400, 8);
INSERT INTO public.word_semantic VALUES (3108, 400, 34);
INSERT INTO public.word_semantic VALUES (3109, 400, 11);
INSERT INTO public.word_semantic VALUES (3112, 401, 36);
INSERT INTO public.word_semantic VALUES (3113, 401, 8);
INSERT INTO public.word_semantic VALUES (3114, 401, 34);
INSERT INTO public.word_semantic VALUES (3115, 401, 11);
INSERT INTO public.word_semantic VALUES (3118, 402, 36);
INSERT INTO public.word_semantic VALUES (3119, 402, 8);
INSERT INTO public.word_semantic VALUES (3120, 402, 34);
INSERT INTO public.word_semantic VALUES (3121, 402, 11);
INSERT INTO public.word_semantic VALUES (3124, 403, 36);
INSERT INTO public.word_semantic VALUES (3125, 403, 8);
INSERT INTO public.word_semantic VALUES (3126, 403, 34);
INSERT INTO public.word_semantic VALUES (3127, 403, 11);
INSERT INTO public.word_semantic VALUES (3130, 404, 36);
INSERT INTO public.word_semantic VALUES (3131, 404, 8);
INSERT INTO public.word_semantic VALUES (3132, 404, 34);
INSERT INTO public.word_semantic VALUES (3133, 404, 11);
INSERT INTO public.word_semantic VALUES (3136, 405, 36);
INSERT INTO public.word_semantic VALUES (3137, 405, 8);
INSERT INTO public.word_semantic VALUES (3138, 405, 34);
INSERT INTO public.word_semantic VALUES (3139, 405, 11);
INSERT INTO public.word_semantic VALUES (3142, 406, 36);
INSERT INTO public.word_semantic VALUES (3143, 406, 8);
INSERT INTO public.word_semantic VALUES (3144, 406, 34);
INSERT INTO public.word_semantic VALUES (3145, 406, 11);
INSERT INTO public.word_semantic VALUES (3146, 406, 46);
INSERT INTO public.word_semantic VALUES (3147, 406, 47);
INSERT INTO public.word_semantic VALUES (3150, 407, 36);
INSERT INTO public.word_semantic VALUES (3151, 407, 8);
INSERT INTO public.word_semantic VALUES (3152, 407, 34);
INSERT INTO public.word_semantic VALUES (3153, 407, 11);
INSERT INTO public.word_semantic VALUES (3154, 407, 46);
INSERT INTO public.word_semantic VALUES (3155, 407, 47);
INSERT INTO public.word_semantic VALUES (3158, 408, 36);
INSERT INTO public.word_semantic VALUES (3159, 408, 8);
INSERT INTO public.word_semantic VALUES (3160, 408, 34);
INSERT INTO public.word_semantic VALUES (3161, 408, 11);
INSERT INTO public.word_semantic VALUES (3162, 408, 46);
INSERT INTO public.word_semantic VALUES (3163, 408, 47);
INSERT INTO public.word_semantic VALUES (3166, 409, 36);
INSERT INTO public.word_semantic VALUES (3167, 409, 8);
INSERT INTO public.word_semantic VALUES (3168, 409, 34);
INSERT INTO public.word_semantic VALUES (3169, 409, 11);
INSERT INTO public.word_semantic VALUES (3170, 409, 46);
INSERT INTO public.word_semantic VALUES (3171, 409, 47);
INSERT INTO public.word_semantic VALUES (3174, 410, 36);
INSERT INTO public.word_semantic VALUES (3175, 410, 8);
INSERT INTO public.word_semantic VALUES (3176, 410, 34);
INSERT INTO public.word_semantic VALUES (3177, 410, 11);
INSERT INTO public.word_semantic VALUES (3180, 411, 36);
INSERT INTO public.word_semantic VALUES (3181, 411, 8);
INSERT INTO public.word_semantic VALUES (3182, 411, 34);
INSERT INTO public.word_semantic VALUES (3183, 411, 11);
INSERT INTO public.word_semantic VALUES (3186, 412, 36);
INSERT INTO public.word_semantic VALUES (3187, 412, 8);
INSERT INTO public.word_semantic VALUES (3188, 412, 34);
INSERT INTO public.word_semantic VALUES (3189, 412, 11);
INSERT INTO public.word_semantic VALUES (3192, 413, 36);
INSERT INTO public.word_semantic VALUES (3193, 413, 8);
INSERT INTO public.word_semantic VALUES (3194, 413, 34);
INSERT INTO public.word_semantic VALUES (3195, 413, 11);
INSERT INTO public.word_semantic VALUES (3198, 414, 36);
INSERT INTO public.word_semantic VALUES (3199, 414, 8);
INSERT INTO public.word_semantic VALUES (3200, 414, 35);
INSERT INTO public.word_semantic VALUES (3201, 414, 39);
INSERT INTO public.word_semantic VALUES (3204, 415, 36);
INSERT INTO public.word_semantic VALUES (3205, 415, 8);
INSERT INTO public.word_semantic VALUES (3206, 415, 35);
INSERT INTO public.word_semantic VALUES (3207, 415, 39);
INSERT INTO public.word_semantic VALUES (3210, 416, 36);
INSERT INTO public.word_semantic VALUES (3211, 416, 8);
INSERT INTO public.word_semantic VALUES (3212, 416, 35);
INSERT INTO public.word_semantic VALUES (3213, 416, 39);
INSERT INTO public.word_semantic VALUES (3216, 417, 36);
INSERT INTO public.word_semantic VALUES (3217, 417, 8);
INSERT INTO public.word_semantic VALUES (3218, 417, 35);
INSERT INTO public.word_semantic VALUES (3219, 417, 39);
INSERT INTO public.word_semantic VALUES (3222, 418, 36);
INSERT INTO public.word_semantic VALUES (3223, 418, 8);
INSERT INTO public.word_semantic VALUES (3224, 418, 35);
INSERT INTO public.word_semantic VALUES (3225, 418, 11);
INSERT INTO public.word_semantic VALUES (3226, 418, 34);
INSERT INTO public.word_semantic VALUES (3229, 419, 36);
INSERT INTO public.word_semantic VALUES (3230, 419, 8);
INSERT INTO public.word_semantic VALUES (3231, 419, 35);
INSERT INTO public.word_semantic VALUES (3232, 419, 11);
INSERT INTO public.word_semantic VALUES (3233, 419, 34);
INSERT INTO public.word_semantic VALUES (3236, 420, 36);
INSERT INTO public.word_semantic VALUES (3237, 420, 8);
INSERT INTO public.word_semantic VALUES (3238, 420, 35);
INSERT INTO public.word_semantic VALUES (3239, 420, 11);
INSERT INTO public.word_semantic VALUES (3240, 420, 34);
INSERT INTO public.word_semantic VALUES (3243, 421, 36);
INSERT INTO public.word_semantic VALUES (3244, 421, 8);
INSERT INTO public.word_semantic VALUES (3245, 421, 35);
INSERT INTO public.word_semantic VALUES (3246, 421, 11);
INSERT INTO public.word_semantic VALUES (3247, 421, 34);
INSERT INTO public.word_semantic VALUES (3250, 422, 36);
INSERT INTO public.word_semantic VALUES (3251, 422, 8);
INSERT INTO public.word_semantic VALUES (3252, 422, 35);
INSERT INTO public.word_semantic VALUES (3253, 422, 11);
INSERT INTO public.word_semantic VALUES (3254, 422, 34);
INSERT INTO public.word_semantic VALUES (3257, 423, 36);
INSERT INTO public.word_semantic VALUES (3258, 423, 8);
INSERT INTO public.word_semantic VALUES (3259, 423, 35);
INSERT INTO public.word_semantic VALUES (3260, 423, 11);
INSERT INTO public.word_semantic VALUES (3261, 423, 34);
INSERT INTO public.word_semantic VALUES (4795, 670, 57);
INSERT INTO public.word_semantic VALUES (4796, 670, 52);
INSERT INTO public.word_semantic VALUES (3264, 424, 36);
INSERT INTO public.word_semantic VALUES (3265, 424, 8);
INSERT INTO public.word_semantic VALUES (3266, 424, 35);
INSERT INTO public.word_semantic VALUES (3267, 424, 11);
INSERT INTO public.word_semantic VALUES (3268, 424, 34);
INSERT INTO public.word_semantic VALUES (3271, 425, 36);
INSERT INTO public.word_semantic VALUES (3272, 425, 8);
INSERT INTO public.word_semantic VALUES (3273, 425, 35);
INSERT INTO public.word_semantic VALUES (3274, 425, 11);
INSERT INTO public.word_semantic VALUES (3275, 425, 34);
INSERT INTO public.word_semantic VALUES (3278, 426, 36);
INSERT INTO public.word_semantic VALUES (3279, 426, 8);
INSERT INTO public.word_semantic VALUES (3280, 426, 35);
INSERT INTO public.word_semantic VALUES (3281, 426, 39);
INSERT INTO public.word_semantic VALUES (3284, 427, 36);
INSERT INTO public.word_semantic VALUES (3285, 427, 8);
INSERT INTO public.word_semantic VALUES (3286, 427, 35);
INSERT INTO public.word_semantic VALUES (3287, 427, 39);
INSERT INTO public.word_semantic VALUES (3290, 428, 36);
INSERT INTO public.word_semantic VALUES (3291, 428, 8);
INSERT INTO public.word_semantic VALUES (3292, 428, 35);
INSERT INTO public.word_semantic VALUES (3293, 428, 39);
INSERT INTO public.word_semantic VALUES (3296, 429, 36);
INSERT INTO public.word_semantic VALUES (3297, 429, 8);
INSERT INTO public.word_semantic VALUES (3298, 429, 35);
INSERT INTO public.word_semantic VALUES (3299, 429, 39);
INSERT INTO public.word_semantic VALUES (3302, 430, 36);
INSERT INTO public.word_semantic VALUES (3303, 430, 8);
INSERT INTO public.word_semantic VALUES (3304, 430, 35);
INSERT INTO public.word_semantic VALUES (3305, 430, 39);
INSERT INTO public.word_semantic VALUES (3306, 430, 48);
INSERT INTO public.word_semantic VALUES (3309, 431, 36);
INSERT INTO public.word_semantic VALUES (3310, 431, 8);
INSERT INTO public.word_semantic VALUES (3311, 431, 35);
INSERT INTO public.word_semantic VALUES (3312, 431, 39);
INSERT INTO public.word_semantic VALUES (3313, 431, 48);
INSERT INTO public.word_semantic VALUES (3316, 432, 36);
INSERT INTO public.word_semantic VALUES (3317, 432, 8);
INSERT INTO public.word_semantic VALUES (3318, 432, 35);
INSERT INTO public.word_semantic VALUES (3319, 432, 39);
INSERT INTO public.word_semantic VALUES (3320, 432, 48);
INSERT INTO public.word_semantic VALUES (3323, 433, 36);
INSERT INTO public.word_semantic VALUES (3324, 433, 8);
INSERT INTO public.word_semantic VALUES (3325, 433, 35);
INSERT INTO public.word_semantic VALUES (3326, 433, 39);
INSERT INTO public.word_semantic VALUES (3327, 433, 48);
INSERT INTO public.word_semantic VALUES (3330, 434, 36);
INSERT INTO public.word_semantic VALUES (3331, 434, 8);
INSERT INTO public.word_semantic VALUES (3332, 434, 35);
INSERT INTO public.word_semantic VALUES (3333, 434, 39);
INSERT INTO public.word_semantic VALUES (3334, 434, 49);
INSERT INTO public.word_semantic VALUES (3337, 435, 36);
INSERT INTO public.word_semantic VALUES (3338, 435, 8);
INSERT INTO public.word_semantic VALUES (3339, 435, 35);
INSERT INTO public.word_semantic VALUES (3340, 435, 39);
INSERT INTO public.word_semantic VALUES (3341, 435, 49);
INSERT INTO public.word_semantic VALUES (3344, 436, 36);
INSERT INTO public.word_semantic VALUES (3345, 436, 8);
INSERT INTO public.word_semantic VALUES (3346, 436, 35);
INSERT INTO public.word_semantic VALUES (3347, 436, 39);
INSERT INTO public.word_semantic VALUES (3348, 436, 49);
INSERT INTO public.word_semantic VALUES (3351, 437, 36);
INSERT INTO public.word_semantic VALUES (3352, 437, 8);
INSERT INTO public.word_semantic VALUES (3353, 437, 35);
INSERT INTO public.word_semantic VALUES (3354, 437, 39);
INSERT INTO public.word_semantic VALUES (3355, 437, 49);
INSERT INTO public.word_semantic VALUES (3358, 438, 36);
INSERT INTO public.word_semantic VALUES (3359, 438, 8);
INSERT INTO public.word_semantic VALUES (3360, 438, 35);
INSERT INTO public.word_semantic VALUES (3361, 438, 39);
INSERT INTO public.word_semantic VALUES (3364, 439, 36);
INSERT INTO public.word_semantic VALUES (3365, 439, 8);
INSERT INTO public.word_semantic VALUES (3366, 439, 35);
INSERT INTO public.word_semantic VALUES (3367, 439, 39);
INSERT INTO public.word_semantic VALUES (3370, 440, 36);
INSERT INTO public.word_semantic VALUES (3371, 440, 8);
INSERT INTO public.word_semantic VALUES (3372, 440, 35);
INSERT INTO public.word_semantic VALUES (3373, 440, 39);
INSERT INTO public.word_semantic VALUES (3376, 441, 36);
INSERT INTO public.word_semantic VALUES (3377, 441, 8);
INSERT INTO public.word_semantic VALUES (3378, 441, 35);
INSERT INTO public.word_semantic VALUES (3379, 441, 39);
INSERT INTO public.word_semantic VALUES (3382, 442, 36);
INSERT INTO public.word_semantic VALUES (3383, 442, 8);
INSERT INTO public.word_semantic VALUES (3384, 442, 35);
INSERT INTO public.word_semantic VALUES (3387, 443, 36);
INSERT INTO public.word_semantic VALUES (3388, 443, 8);
INSERT INTO public.word_semantic VALUES (3389, 443, 35);
INSERT INTO public.word_semantic VALUES (3392, 444, 36);
INSERT INTO public.word_semantic VALUES (3393, 444, 8);
INSERT INTO public.word_semantic VALUES (3394, 444, 35);
INSERT INTO public.word_semantic VALUES (3397, 445, 36);
INSERT INTO public.word_semantic VALUES (3398, 445, 8);
INSERT INTO public.word_semantic VALUES (3399, 445, 35);
INSERT INTO public.word_semantic VALUES (3402, 446, 36);
INSERT INTO public.word_semantic VALUES (3403, 446, 8);
INSERT INTO public.word_semantic VALUES (3404, 446, 35);
INSERT INTO public.word_semantic VALUES (3407, 447, 36);
INSERT INTO public.word_semantic VALUES (3408, 447, 8);
INSERT INTO public.word_semantic VALUES (3409, 447, 35);
INSERT INTO public.word_semantic VALUES (3412, 448, 36);
INSERT INTO public.word_semantic VALUES (3413, 448, 8);
INSERT INTO public.word_semantic VALUES (3414, 448, 35);
INSERT INTO public.word_semantic VALUES (3417, 449, 36);
INSERT INTO public.word_semantic VALUES (3418, 449, 8);
INSERT INTO public.word_semantic VALUES (3419, 449, 35);
INSERT INTO public.word_semantic VALUES (3422, 450, 36);
INSERT INTO public.word_semantic VALUES (3423, 450, 8);
INSERT INTO public.word_semantic VALUES (3424, 450, 35);
INSERT INTO public.word_semantic VALUES (3425, 450, 39);
INSERT INTO public.word_semantic VALUES (3428, 451, 36);
INSERT INTO public.word_semantic VALUES (3429, 451, 8);
INSERT INTO public.word_semantic VALUES (3430, 451, 35);
INSERT INTO public.word_semantic VALUES (3431, 451, 39);
INSERT INTO public.word_semantic VALUES (3434, 452, 36);
INSERT INTO public.word_semantic VALUES (3435, 452, 8);
INSERT INTO public.word_semantic VALUES (3436, 452, 35);
INSERT INTO public.word_semantic VALUES (3437, 452, 39);
INSERT INTO public.word_semantic VALUES (3440, 453, 36);
INSERT INTO public.word_semantic VALUES (3441, 453, 8);
INSERT INTO public.word_semantic VALUES (3442, 453, 35);
INSERT INTO public.word_semantic VALUES (3443, 453, 39);
INSERT INTO public.word_semantic VALUES (3446, 454, 36);
INSERT INTO public.word_semantic VALUES (3447, 454, 8);
INSERT INTO public.word_semantic VALUES (3448, 454, 35);
INSERT INTO public.word_semantic VALUES (3449, 454, 39);
INSERT INTO public.word_semantic VALUES (3450, 454, 40);
INSERT INTO public.word_semantic VALUES (3451, 454, 34);
INSERT INTO public.word_semantic VALUES (3454, 455, 36);
INSERT INTO public.word_semantic VALUES (3455, 455, 8);
INSERT INTO public.word_semantic VALUES (3456, 455, 35);
INSERT INTO public.word_semantic VALUES (3457, 455, 39);
INSERT INTO public.word_semantic VALUES (3458, 455, 40);
INSERT INTO public.word_semantic VALUES (3459, 455, 34);
INSERT INTO public.word_semantic VALUES (3462, 456, 36);
INSERT INTO public.word_semantic VALUES (3463, 456, 8);
INSERT INTO public.word_semantic VALUES (3464, 456, 35);
INSERT INTO public.word_semantic VALUES (3465, 456, 39);
INSERT INTO public.word_semantic VALUES (3466, 456, 40);
INSERT INTO public.word_semantic VALUES (3467, 456, 34);
INSERT INTO public.word_semantic VALUES (3470, 457, 36);
INSERT INTO public.word_semantic VALUES (3471, 457, 8);
INSERT INTO public.word_semantic VALUES (3472, 457, 35);
INSERT INTO public.word_semantic VALUES (3473, 457, 39);
INSERT INTO public.word_semantic VALUES (3474, 457, 40);
INSERT INTO public.word_semantic VALUES (3475, 457, 34);
INSERT INTO public.word_semantic VALUES (3478, 458, 36);
INSERT INTO public.word_semantic VALUES (3479, 458, 8);
INSERT INTO public.word_semantic VALUES (3480, 458, 35);
INSERT INTO public.word_semantic VALUES (3481, 458, 39);
INSERT INTO public.word_semantic VALUES (3482, 458, 40);
INSERT INTO public.word_semantic VALUES (3483, 458, 34);
INSERT INTO public.word_semantic VALUES (3486, 459, 36);
INSERT INTO public.word_semantic VALUES (3487, 459, 8);
INSERT INTO public.word_semantic VALUES (3488, 459, 35);
INSERT INTO public.word_semantic VALUES (3489, 459, 39);
INSERT INTO public.word_semantic VALUES (3490, 459, 40);
INSERT INTO public.word_semantic VALUES (3491, 459, 34);
INSERT INTO public.word_semantic VALUES (3494, 460, 36);
INSERT INTO public.word_semantic VALUES (3495, 460, 8);
INSERT INTO public.word_semantic VALUES (3496, 460, 35);
INSERT INTO public.word_semantic VALUES (3497, 460, 39);
INSERT INTO public.word_semantic VALUES (3498, 460, 40);
INSERT INTO public.word_semantic VALUES (3499, 460, 34);
INSERT INTO public.word_semantic VALUES (3502, 461, 36);
INSERT INTO public.word_semantic VALUES (3503, 461, 8);
INSERT INTO public.word_semantic VALUES (3504, 461, 35);
INSERT INTO public.word_semantic VALUES (3505, 461, 39);
INSERT INTO public.word_semantic VALUES (3506, 461, 40);
INSERT INTO public.word_semantic VALUES (3507, 461, 34);
INSERT INTO public.word_semantic VALUES (3510, 462, 36);
INSERT INTO public.word_semantic VALUES (3511, 462, 8);
INSERT INTO public.word_semantic VALUES (3512, 462, 35);
INSERT INTO public.word_semantic VALUES (3513, 462, 34);
INSERT INTO public.word_semantic VALUES (4798, 671, 57);
INSERT INTO public.word_semantic VALUES (3516, 463, 36);
INSERT INTO public.word_semantic VALUES (3517, 463, 8);
INSERT INTO public.word_semantic VALUES (3518, 463, 35);
INSERT INTO public.word_semantic VALUES (3519, 463, 34);
INSERT INTO public.word_semantic VALUES (4799, 671, 52);
INSERT INTO public.word_semantic VALUES (3522, 464, 36);
INSERT INTO public.word_semantic VALUES (3523, 464, 8);
INSERT INTO public.word_semantic VALUES (3524, 464, 35);
INSERT INTO public.word_semantic VALUES (3525, 464, 34);
INSERT INTO public.word_semantic VALUES (4801, 672, 57);
INSERT INTO public.word_semantic VALUES (4802, 672, 52);
INSERT INTO public.word_semantic VALUES (3528, 465, 36);
INSERT INTO public.word_semantic VALUES (3529, 465, 8);
INSERT INTO public.word_semantic VALUES (3530, 465, 35);
INSERT INTO public.word_semantic VALUES (3531, 465, 34);
INSERT INTO public.word_semantic VALUES (4804, 673, 57);
INSERT INTO public.word_semantic VALUES (3534, 466, 36);
INSERT INTO public.word_semantic VALUES (3535, 466, 8);
INSERT INTO public.word_semantic VALUES (3536, 466, 35);
INSERT INTO public.word_semantic VALUES (3537, 466, 49);
INSERT INTO public.word_semantic VALUES (4805, 673, 52);
INSERT INTO public.word_semantic VALUES (3540, 467, 36);
INSERT INTO public.word_semantic VALUES (3541, 467, 8);
INSERT INTO public.word_semantic VALUES (3542, 467, 35);
INSERT INTO public.word_semantic VALUES (3543, 467, 49);
INSERT INTO public.word_semantic VALUES (4807, 674, 57);
INSERT INTO public.word_semantic VALUES (4808, 674, 52);
INSERT INTO public.word_semantic VALUES (3546, 468, 36);
INSERT INTO public.word_semantic VALUES (3547, 468, 8);
INSERT INTO public.word_semantic VALUES (3548, 468, 35);
INSERT INTO public.word_semantic VALUES (3549, 468, 49);
INSERT INTO public.word_semantic VALUES (3552, 469, 36);
INSERT INTO public.word_semantic VALUES (3553, 469, 8);
INSERT INTO public.word_semantic VALUES (3554, 469, 35);
INSERT INTO public.word_semantic VALUES (3555, 469, 49);
INSERT INTO public.word_semantic VALUES (3558, 470, 36);
INSERT INTO public.word_semantic VALUES (3559, 470, 8);
INSERT INTO public.word_semantic VALUES (3560, 470, 5);
INSERT INTO public.word_semantic VALUES (3563, 471, 36);
INSERT INTO public.word_semantic VALUES (3564, 471, 8);
INSERT INTO public.word_semantic VALUES (3565, 471, 5);
INSERT INTO public.word_semantic VALUES (3568, 472, 36);
INSERT INTO public.word_semantic VALUES (3569, 472, 8);
INSERT INTO public.word_semantic VALUES (3570, 472, 5);
INSERT INTO public.word_semantic VALUES (3573, 473, 36);
INSERT INTO public.word_semantic VALUES (3574, 473, 8);
INSERT INTO public.word_semantic VALUES (3575, 473, 5);
INSERT INTO public.word_semantic VALUES (3578, 474, 36);
INSERT INTO public.word_semantic VALUES (3579, 474, 8);
INSERT INTO public.word_semantic VALUES (3580, 474, 5);
INSERT INTO public.word_semantic VALUES (3583, 475, 36);
INSERT INTO public.word_semantic VALUES (3584, 475, 8);
INSERT INTO public.word_semantic VALUES (3585, 475, 5);
INSERT INTO public.word_semantic VALUES (3588, 476, 36);
INSERT INTO public.word_semantic VALUES (3589, 476, 8);
INSERT INTO public.word_semantic VALUES (3590, 476, 5);
INSERT INTO public.word_semantic VALUES (3593, 477, 36);
INSERT INTO public.word_semantic VALUES (3594, 477, 8);
INSERT INTO public.word_semantic VALUES (3595, 477, 5);
INSERT INTO public.word_semantic VALUES (3598, 478, 36);
INSERT INTO public.word_semantic VALUES (3599, 478, 8);
INSERT INTO public.word_semantic VALUES (3600, 478, 5);
INSERT INTO public.word_semantic VALUES (3603, 479, 36);
INSERT INTO public.word_semantic VALUES (3604, 479, 8);
INSERT INTO public.word_semantic VALUES (3605, 479, 5);
INSERT INTO public.word_semantic VALUES (3608, 480, 36);
INSERT INTO public.word_semantic VALUES (3609, 480, 8);
INSERT INTO public.word_semantic VALUES (3610, 480, 5);
INSERT INTO public.word_semantic VALUES (3613, 481, 36);
INSERT INTO public.word_semantic VALUES (3614, 481, 8);
INSERT INTO public.word_semantic VALUES (3615, 481, 5);
INSERT INTO public.word_semantic VALUES (3618, 482, 36);
INSERT INTO public.word_semantic VALUES (3619, 482, 8);
INSERT INTO public.word_semantic VALUES (3620, 482, 5);
INSERT INTO public.word_semantic VALUES (3623, 483, 36);
INSERT INTO public.word_semantic VALUES (3624, 483, 8);
INSERT INTO public.word_semantic VALUES (3625, 483, 5);
INSERT INTO public.word_semantic VALUES (3628, 484, 36);
INSERT INTO public.word_semantic VALUES (3629, 484, 8);
INSERT INTO public.word_semantic VALUES (3630, 484, 5);
INSERT INTO public.word_semantic VALUES (3633, 485, 36);
INSERT INTO public.word_semantic VALUES (3634, 485, 8);
INSERT INTO public.word_semantic VALUES (3635, 485, 5);
INSERT INTO public.word_semantic VALUES (3638, 486, 36);
INSERT INTO public.word_semantic VALUES (3639, 486, 8);
INSERT INTO public.word_semantic VALUES (3640, 486, 5);
INSERT INTO public.word_semantic VALUES (3643, 487, 36);
INSERT INTO public.word_semantic VALUES (3644, 487, 8);
INSERT INTO public.word_semantic VALUES (3645, 487, 5);
INSERT INTO public.word_semantic VALUES (3648, 488, 36);
INSERT INTO public.word_semantic VALUES (3649, 488, 8);
INSERT INTO public.word_semantic VALUES (3650, 488, 5);
INSERT INTO public.word_semantic VALUES (3653, 489, 36);
INSERT INTO public.word_semantic VALUES (3654, 489, 8);
INSERT INTO public.word_semantic VALUES (3655, 489, 5);
INSERT INTO public.word_semantic VALUES (3658, 490, 36);
INSERT INTO public.word_semantic VALUES (3659, 490, 8);
INSERT INTO public.word_semantic VALUES (3660, 490, 5);
INSERT INTO public.word_semantic VALUES (3663, 491, 36);
INSERT INTO public.word_semantic VALUES (3664, 491, 8);
INSERT INTO public.word_semantic VALUES (3665, 491, 5);
INSERT INTO public.word_semantic VALUES (3668, 492, 36);
INSERT INTO public.word_semantic VALUES (3669, 492, 8);
INSERT INTO public.word_semantic VALUES (3670, 492, 5);
INSERT INTO public.word_semantic VALUES (3673, 493, 36);
INSERT INTO public.word_semantic VALUES (3674, 493, 8);
INSERT INTO public.word_semantic VALUES (3675, 493, 5);
INSERT INTO public.word_semantic VALUES (3678, 494, 36);
INSERT INTO public.word_semantic VALUES (3679, 494, 8);
INSERT INTO public.word_semantic VALUES (3680, 494, 5);
INSERT INTO public.word_semantic VALUES (3683, 495, 36);
INSERT INTO public.word_semantic VALUES (3684, 495, 8);
INSERT INTO public.word_semantic VALUES (3685, 495, 5);
INSERT INTO public.word_semantic VALUES (3688, 496, 36);
INSERT INTO public.word_semantic VALUES (3689, 496, 8);
INSERT INTO public.word_semantic VALUES (3690, 496, 5);
INSERT INTO public.word_semantic VALUES (3693, 497, 36);
INSERT INTO public.word_semantic VALUES (3694, 497, 8);
INSERT INTO public.word_semantic VALUES (3695, 497, 5);
INSERT INTO public.word_semantic VALUES (3698, 498, 36);
INSERT INTO public.word_semantic VALUES (3699, 498, 8);
INSERT INTO public.word_semantic VALUES (3700, 498, 5);
INSERT INTO public.word_semantic VALUES (3703, 499, 36);
INSERT INTO public.word_semantic VALUES (3704, 499, 8);
INSERT INTO public.word_semantic VALUES (3705, 499, 5);
INSERT INTO public.word_semantic VALUES (3708, 500, 36);
INSERT INTO public.word_semantic VALUES (3709, 500, 8);
INSERT INTO public.word_semantic VALUES (3710, 500, 5);
INSERT INTO public.word_semantic VALUES (3713, 501, 36);
INSERT INTO public.word_semantic VALUES (3714, 501, 8);
INSERT INTO public.word_semantic VALUES (3715, 501, 5);
INSERT INTO public.word_semantic VALUES (3722, 502, 50);
INSERT INTO public.word_semantic VALUES (3723, 502, 8);
INSERT INTO public.word_semantic VALUES (3724, 502, 5);
INSERT INTO public.word_semantic VALUES (3725, 502, 9);
INSERT INTO public.word_semantic VALUES (3726, 502, 15);
INSERT INTO public.word_semantic VALUES (3727, 502, 16);
INSERT INTO public.word_semantic VALUES (3734, 503, 50);
INSERT INTO public.word_semantic VALUES (3735, 503, 8);
INSERT INTO public.word_semantic VALUES (3736, 503, 5);
INSERT INTO public.word_semantic VALUES (3737, 503, 9);
INSERT INTO public.word_semantic VALUES (3738, 503, 15);
INSERT INTO public.word_semantic VALUES (3739, 503, 16);
INSERT INTO public.word_semantic VALUES (3746, 504, 50);
INSERT INTO public.word_semantic VALUES (3747, 504, 8);
INSERT INTO public.word_semantic VALUES (3748, 504, 5);
INSERT INTO public.word_semantic VALUES (3749, 504, 9);
INSERT INTO public.word_semantic VALUES (3750, 504, 15);
INSERT INTO public.word_semantic VALUES (3751, 504, 16);
INSERT INTO public.word_semantic VALUES (3758, 505, 50);
INSERT INTO public.word_semantic VALUES (3759, 505, 8);
INSERT INTO public.word_semantic VALUES (3760, 505, 5);
INSERT INTO public.word_semantic VALUES (3761, 505, 9);
INSERT INTO public.word_semantic VALUES (3762, 505, 15);
INSERT INTO public.word_semantic VALUES (3763, 505, 16);
INSERT INTO public.word_semantic VALUES (3770, 506, 50);
INSERT INTO public.word_semantic VALUES (3771, 506, 8);
INSERT INTO public.word_semantic VALUES (3772, 506, 5);
INSERT INTO public.word_semantic VALUES (3773, 506, 9);
INSERT INTO public.word_semantic VALUES (3774, 506, 15);
INSERT INTO public.word_semantic VALUES (3775, 506, 16);
INSERT INTO public.word_semantic VALUES (3782, 507, 50);
INSERT INTO public.word_semantic VALUES (3783, 507, 8);
INSERT INTO public.word_semantic VALUES (3784, 507, 5);
INSERT INTO public.word_semantic VALUES (3785, 507, 9);
INSERT INTO public.word_semantic VALUES (3786, 507, 15);
INSERT INTO public.word_semantic VALUES (3787, 507, 16);
INSERT INTO public.word_semantic VALUES (3794, 508, 50);
INSERT INTO public.word_semantic VALUES (3795, 508, 8);
INSERT INTO public.word_semantic VALUES (3796, 508, 5);
INSERT INTO public.word_semantic VALUES (3797, 508, 9);
INSERT INTO public.word_semantic VALUES (3798, 508, 15);
INSERT INTO public.word_semantic VALUES (3799, 508, 16);
INSERT INTO public.word_semantic VALUES (4810, 675, 58);
INSERT INTO public.word_semantic VALUES (4811, 675, 52);
INSERT INTO public.word_semantic VALUES (3806, 509, 50);
INSERT INTO public.word_semantic VALUES (3807, 509, 8);
INSERT INTO public.word_semantic VALUES (3808, 509, 5);
INSERT INTO public.word_semantic VALUES (3809, 509, 9);
INSERT INTO public.word_semantic VALUES (3810, 509, 15);
INSERT INTO public.word_semantic VALUES (3811, 509, 16);
INSERT INTO public.word_semantic VALUES (4813, 676, 58);
INSERT INTO public.word_semantic VALUES (4814, 676, 52);
INSERT INTO public.word_semantic VALUES (4816, 677, 58);
INSERT INTO public.word_semantic VALUES (4817, 677, 52);
INSERT INTO public.word_semantic VALUES (3818, 510, 50);
INSERT INTO public.word_semantic VALUES (3819, 510, 8);
INSERT INTO public.word_semantic VALUES (3820, 510, 5);
INSERT INTO public.word_semantic VALUES (3821, 510, 9);
INSERT INTO public.word_semantic VALUES (3822, 510, 15);
INSERT INTO public.word_semantic VALUES (3823, 510, 16);
INSERT INTO public.word_semantic VALUES (4819, 678, 58);
INSERT INTO public.word_semantic VALUES (4820, 678, 52);
INSERT INTO public.word_semantic VALUES (4822, 679, 58);
INSERT INTO public.word_semantic VALUES (4823, 679, 52);
INSERT INTO public.word_semantic VALUES (3830, 511, 50);
INSERT INTO public.word_semantic VALUES (3831, 511, 8);
INSERT INTO public.word_semantic VALUES (3832, 511, 5);
INSERT INTO public.word_semantic VALUES (3833, 511, 9);
INSERT INTO public.word_semantic VALUES (3834, 511, 15);
INSERT INTO public.word_semantic VALUES (3835, 511, 16);
INSERT INTO public.word_semantic VALUES (4825, 680, 69);
INSERT INTO public.word_semantic VALUES (4826, 680, 52);
INSERT INTO public.word_semantic VALUES (4828, 681, 69);
INSERT INTO public.word_semantic VALUES (4829, 681, 52);
INSERT INTO public.word_semantic VALUES (3842, 512, 50);
INSERT INTO public.word_semantic VALUES (3843, 512, 8);
INSERT INTO public.word_semantic VALUES (3844, 512, 5);
INSERT INTO public.word_semantic VALUES (3845, 512, 9);
INSERT INTO public.word_semantic VALUES (3846, 512, 15);
INSERT INTO public.word_semantic VALUES (3847, 512, 16);
INSERT INTO public.word_semantic VALUES (4831, 682, 69);
INSERT INTO public.word_semantic VALUES (4832, 682, 52);
INSERT INTO public.word_semantic VALUES (4834, 683, 69);
INSERT INTO public.word_semantic VALUES (4835, 683, 52);
INSERT INTO public.word_semantic VALUES (3854, 513, 50);
INSERT INTO public.word_semantic VALUES (3855, 513, 8);
INSERT INTO public.word_semantic VALUES (3856, 513, 5);
INSERT INTO public.word_semantic VALUES (3857, 513, 9);
INSERT INTO public.word_semantic VALUES (3858, 513, 15);
INSERT INTO public.word_semantic VALUES (3859, 513, 16);
INSERT INTO public.word_semantic VALUES (3866, 514, 50);
INSERT INTO public.word_semantic VALUES (3867, 514, 8);
INSERT INTO public.word_semantic VALUES (3868, 514, 5);
INSERT INTO public.word_semantic VALUES (3869, 514, 9);
INSERT INTO public.word_semantic VALUES (3870, 514, 15);
INSERT INTO public.word_semantic VALUES (3871, 514, 16);
INSERT INTO public.word_semantic VALUES (3878, 515, 50);
INSERT INTO public.word_semantic VALUES (3879, 515, 8);
INSERT INTO public.word_semantic VALUES (3880, 515, 5);
INSERT INTO public.word_semantic VALUES (3881, 515, 9);
INSERT INTO public.word_semantic VALUES (3882, 515, 15);
INSERT INTO public.word_semantic VALUES (3883, 515, 16);
INSERT INTO public.word_semantic VALUES (3890, 516, 50);
INSERT INTO public.word_semantic VALUES (3891, 516, 8);
INSERT INTO public.word_semantic VALUES (3892, 516, 5);
INSERT INTO public.word_semantic VALUES (3893, 516, 9);
INSERT INTO public.word_semantic VALUES (3894, 516, 15);
INSERT INTO public.word_semantic VALUES (3895, 516, 16);
INSERT INTO public.word_semantic VALUES (3902, 517, 50);
INSERT INTO public.word_semantic VALUES (3903, 517, 8);
INSERT INTO public.word_semantic VALUES (3904, 517, 5);
INSERT INTO public.word_semantic VALUES (3905, 517, 9);
INSERT INTO public.word_semantic VALUES (3906, 517, 15);
INSERT INTO public.word_semantic VALUES (3907, 517, 16);
INSERT INTO public.word_semantic VALUES (3914, 518, 50);
INSERT INTO public.word_semantic VALUES (3915, 518, 8);
INSERT INTO public.word_semantic VALUES (3916, 518, 5);
INSERT INTO public.word_semantic VALUES (3917, 518, 9);
INSERT INTO public.word_semantic VALUES (3918, 518, 15);
INSERT INTO public.word_semantic VALUES (3919, 518, 16);
INSERT INTO public.word_semantic VALUES (3926, 519, 50);
INSERT INTO public.word_semantic VALUES (3927, 519, 8);
INSERT INTO public.word_semantic VALUES (3928, 519, 5);
INSERT INTO public.word_semantic VALUES (3929, 519, 9);
INSERT INTO public.word_semantic VALUES (3930, 519, 15);
INSERT INTO public.word_semantic VALUES (3931, 519, 16);
INSERT INTO public.word_semantic VALUES (3938, 520, 50);
INSERT INTO public.word_semantic VALUES (3939, 520, 8);
INSERT INTO public.word_semantic VALUES (3940, 520, 5);
INSERT INTO public.word_semantic VALUES (3941, 520, 9);
INSERT INTO public.word_semantic VALUES (3942, 520, 15);
INSERT INTO public.word_semantic VALUES (3943, 520, 16);
INSERT INTO public.word_semantic VALUES (3950, 521, 50);
INSERT INTO public.word_semantic VALUES (3951, 521, 8);
INSERT INTO public.word_semantic VALUES (3952, 521, 5);
INSERT INTO public.word_semantic VALUES (3953, 521, 9);
INSERT INTO public.word_semantic VALUES (3954, 521, 15);
INSERT INTO public.word_semantic VALUES (3955, 521, 16);
INSERT INTO public.word_semantic VALUES (3961, 522, 50);
INSERT INTO public.word_semantic VALUES (3962, 522, 8);
INSERT INTO public.word_semantic VALUES (3963, 522, 5);
INSERT INTO public.word_semantic VALUES (3964, 522, 9);
INSERT INTO public.word_semantic VALUES (3965, 522, 15);
INSERT INTO public.word_semantic VALUES (3971, 523, 50);
INSERT INTO public.word_semantic VALUES (3972, 523, 8);
INSERT INTO public.word_semantic VALUES (3973, 523, 5);
INSERT INTO public.word_semantic VALUES (3974, 523, 9);
INSERT INTO public.word_semantic VALUES (3975, 523, 15);
INSERT INTO public.word_semantic VALUES (3981, 524, 50);
INSERT INTO public.word_semantic VALUES (3982, 524, 8);
INSERT INTO public.word_semantic VALUES (3983, 524, 5);
INSERT INTO public.word_semantic VALUES (3984, 524, 9);
INSERT INTO public.word_semantic VALUES (3985, 524, 15);
INSERT INTO public.word_semantic VALUES (3991, 525, 50);
INSERT INTO public.word_semantic VALUES (3992, 525, 8);
INSERT INTO public.word_semantic VALUES (3993, 525, 5);
INSERT INTO public.word_semantic VALUES (3994, 525, 9);
INSERT INTO public.word_semantic VALUES (3995, 525, 15);
INSERT INTO public.word_semantic VALUES (4001, 526, 50);
INSERT INTO public.word_semantic VALUES (4002, 526, 8);
INSERT INTO public.word_semantic VALUES (4003, 526, 5);
INSERT INTO public.word_semantic VALUES (4004, 526, 9);
INSERT INTO public.word_semantic VALUES (4005, 526, 15);
INSERT INTO public.word_semantic VALUES (4011, 527, 50);
INSERT INTO public.word_semantic VALUES (4012, 527, 8);
INSERT INTO public.word_semantic VALUES (4013, 527, 5);
INSERT INTO public.word_semantic VALUES (4014, 527, 9);
INSERT INTO public.word_semantic VALUES (4015, 527, 15);
INSERT INTO public.word_semantic VALUES (4021, 528, 50);
INSERT INTO public.word_semantic VALUES (4022, 528, 8);
INSERT INTO public.word_semantic VALUES (4023, 528, 5);
INSERT INTO public.word_semantic VALUES (4024, 528, 9);
INSERT INTO public.word_semantic VALUES (4025, 528, 15);
INSERT INTO public.word_semantic VALUES (4031, 529, 50);
INSERT INTO public.word_semantic VALUES (4032, 529, 8);
INSERT INTO public.word_semantic VALUES (4033, 529, 5);
INSERT INTO public.word_semantic VALUES (4034, 529, 9);
INSERT INTO public.word_semantic VALUES (4035, 529, 15);
INSERT INTO public.word_semantic VALUES (4041, 530, 50);
INSERT INTO public.word_semantic VALUES (4042, 530, 8);
INSERT INTO public.word_semantic VALUES (4043, 530, 5);
INSERT INTO public.word_semantic VALUES (4044, 530, 9);
INSERT INTO public.word_semantic VALUES (4045, 530, 15);
INSERT INTO public.word_semantic VALUES (4051, 531, 50);
INSERT INTO public.word_semantic VALUES (4052, 531, 8);
INSERT INTO public.word_semantic VALUES (4053, 531, 5);
INSERT INTO public.word_semantic VALUES (4054, 531, 9);
INSERT INTO public.word_semantic VALUES (4055, 531, 15);
INSERT INTO public.word_semantic VALUES (4061, 532, 50);
INSERT INTO public.word_semantic VALUES (4062, 532, 8);
INSERT INTO public.word_semantic VALUES (4063, 532, 5);
INSERT INTO public.word_semantic VALUES (4064, 532, 9);
INSERT INTO public.word_semantic VALUES (4065, 532, 15);
INSERT INTO public.word_semantic VALUES (4071, 533, 50);
INSERT INTO public.word_semantic VALUES (4072, 533, 8);
INSERT INTO public.word_semantic VALUES (4073, 533, 5);
INSERT INTO public.word_semantic VALUES (4074, 533, 9);
INSERT INTO public.word_semantic VALUES (4075, 533, 15);
INSERT INTO public.word_semantic VALUES (4081, 534, 50);
INSERT INTO public.word_semantic VALUES (4082, 534, 8);
INSERT INTO public.word_semantic VALUES (4083, 534, 5);
INSERT INTO public.word_semantic VALUES (4084, 534, 9);
INSERT INTO public.word_semantic VALUES (4085, 534, 15);
INSERT INTO public.word_semantic VALUES (4091, 535, 50);
INSERT INTO public.word_semantic VALUES (4092, 535, 8);
INSERT INTO public.word_semantic VALUES (4093, 535, 5);
INSERT INTO public.word_semantic VALUES (4094, 535, 9);
INSERT INTO public.word_semantic VALUES (4095, 535, 15);
INSERT INTO public.word_semantic VALUES (4101, 536, 50);
INSERT INTO public.word_semantic VALUES (4102, 536, 8);
INSERT INTO public.word_semantic VALUES (4103, 536, 5);
INSERT INTO public.word_semantic VALUES (4104, 536, 9);
INSERT INTO public.word_semantic VALUES (4105, 536, 15);
INSERT INTO public.word_semantic VALUES (4111, 537, 50);
INSERT INTO public.word_semantic VALUES (4112, 537, 8);
INSERT INTO public.word_semantic VALUES (4113, 537, 5);
INSERT INTO public.word_semantic VALUES (4114, 537, 9);
INSERT INTO public.word_semantic VALUES (4115, 537, 15);
INSERT INTO public.word_semantic VALUES (4121, 538, 50);
INSERT INTO public.word_semantic VALUES (4122, 538, 8);
INSERT INTO public.word_semantic VALUES (4123, 538, 5);
INSERT INTO public.word_semantic VALUES (4124, 538, 9);
INSERT INTO public.word_semantic VALUES (4125, 538, 15);
INSERT INTO public.word_semantic VALUES (4131, 539, 50);
INSERT INTO public.word_semantic VALUES (4132, 539, 8);
INSERT INTO public.word_semantic VALUES (4133, 539, 5);
INSERT INTO public.word_semantic VALUES (4134, 539, 9);
INSERT INTO public.word_semantic VALUES (4135, 539, 15);
INSERT INTO public.word_semantic VALUES (4141, 540, 50);
INSERT INTO public.word_semantic VALUES (4142, 540, 8);
INSERT INTO public.word_semantic VALUES (4143, 540, 5);
INSERT INTO public.word_semantic VALUES (4144, 540, 9);
INSERT INTO public.word_semantic VALUES (4145, 540, 15);
INSERT INTO public.word_semantic VALUES (4151, 541, 50);
INSERT INTO public.word_semantic VALUES (4152, 541, 8);
INSERT INTO public.word_semantic VALUES (4153, 541, 5);
INSERT INTO public.word_semantic VALUES (4154, 541, 9);
INSERT INTO public.word_semantic VALUES (4155, 541, 15);
INSERT INTO public.word_semantic VALUES (4161, 542, 50);
INSERT INTO public.word_semantic VALUES (4162, 542, 8);
INSERT INTO public.word_semantic VALUES (4163, 542, 5);
INSERT INTO public.word_semantic VALUES (4164, 542, 9);
INSERT INTO public.word_semantic VALUES (4165, 542, 15);
INSERT INTO public.word_semantic VALUES (4171, 543, 50);
INSERT INTO public.word_semantic VALUES (4172, 543, 8);
INSERT INTO public.word_semantic VALUES (4173, 543, 5);
INSERT INTO public.word_semantic VALUES (4174, 543, 9);
INSERT INTO public.word_semantic VALUES (4175, 543, 15);
INSERT INTO public.word_semantic VALUES (4181, 544, 50);
INSERT INTO public.word_semantic VALUES (4182, 544, 8);
INSERT INTO public.word_semantic VALUES (4183, 544, 5);
INSERT INTO public.word_semantic VALUES (4184, 544, 9);
INSERT INTO public.word_semantic VALUES (4185, 544, 15);
INSERT INTO public.word_semantic VALUES (4191, 545, 50);
INSERT INTO public.word_semantic VALUES (4192, 545, 8);
INSERT INTO public.word_semantic VALUES (4193, 545, 5);
INSERT INTO public.word_semantic VALUES (4194, 545, 9);
INSERT INTO public.word_semantic VALUES (4195, 545, 15);
INSERT INTO public.word_semantic VALUES (4201, 546, 50);
INSERT INTO public.word_semantic VALUES (4202, 546, 8);
INSERT INTO public.word_semantic VALUES (4203, 546, 5);
INSERT INTO public.word_semantic VALUES (4204, 546, 9);
INSERT INTO public.word_semantic VALUES (4205, 546, 15);
INSERT INTO public.word_semantic VALUES (4211, 547, 50);
INSERT INTO public.word_semantic VALUES (4212, 547, 8);
INSERT INTO public.word_semantic VALUES (4213, 547, 5);
INSERT INTO public.word_semantic VALUES (4214, 547, 9);
INSERT INTO public.word_semantic VALUES (4215, 547, 15);
INSERT INTO public.word_semantic VALUES (4221, 548, 50);
INSERT INTO public.word_semantic VALUES (4222, 548, 8);
INSERT INTO public.word_semantic VALUES (4223, 548, 5);
INSERT INTO public.word_semantic VALUES (4224, 548, 9);
INSERT INTO public.word_semantic VALUES (4225, 548, 15);
INSERT INTO public.word_semantic VALUES (4231, 549, 50);
INSERT INTO public.word_semantic VALUES (4232, 549, 8);
INSERT INTO public.word_semantic VALUES (4233, 549, 5);
INSERT INTO public.word_semantic VALUES (4234, 549, 9);
INSERT INTO public.word_semantic VALUES (4235, 549, 15);
INSERT INTO public.word_semantic VALUES (4241, 550, 50);
INSERT INTO public.word_semantic VALUES (4242, 550, 8);
INSERT INTO public.word_semantic VALUES (4243, 550, 5);
INSERT INTO public.word_semantic VALUES (4244, 550, 9);
INSERT INTO public.word_semantic VALUES (4245, 550, 15);
INSERT INTO public.word_semantic VALUES (4251, 551, 50);
INSERT INTO public.word_semantic VALUES (4252, 551, 8);
INSERT INTO public.word_semantic VALUES (4253, 551, 5);
INSERT INTO public.word_semantic VALUES (4254, 551, 9);
INSERT INTO public.word_semantic VALUES (4255, 551, 15);
INSERT INTO public.word_semantic VALUES (4261, 552, 50);
INSERT INTO public.word_semantic VALUES (4262, 552, 8);
INSERT INTO public.word_semantic VALUES (4263, 552, 5);
INSERT INTO public.word_semantic VALUES (4264, 552, 9);
INSERT INTO public.word_semantic VALUES (4265, 552, 15);
INSERT INTO public.word_semantic VALUES (4271, 553, 50);
INSERT INTO public.word_semantic VALUES (4272, 553, 8);
INSERT INTO public.word_semantic VALUES (4273, 553, 5);
INSERT INTO public.word_semantic VALUES (4274, 553, 9);
INSERT INTO public.word_semantic VALUES (4275, 553, 15);
INSERT INTO public.word_semantic VALUES (4281, 554, 50);
INSERT INTO public.word_semantic VALUES (4282, 554, 8);
INSERT INTO public.word_semantic VALUES (4283, 554, 5);
INSERT INTO public.word_semantic VALUES (4284, 554, 9);
INSERT INTO public.word_semantic VALUES (4285, 554, 15);
INSERT INTO public.word_semantic VALUES (4291, 555, 50);
INSERT INTO public.word_semantic VALUES (4292, 555, 8);
INSERT INTO public.word_semantic VALUES (4293, 555, 5);
INSERT INTO public.word_semantic VALUES (4294, 555, 9);
INSERT INTO public.word_semantic VALUES (4295, 555, 15);
INSERT INTO public.word_semantic VALUES (4301, 556, 50);
INSERT INTO public.word_semantic VALUES (4302, 556, 8);
INSERT INTO public.word_semantic VALUES (4303, 556, 5);
INSERT INTO public.word_semantic VALUES (4304, 556, 9);
INSERT INTO public.word_semantic VALUES (4305, 556, 15);
INSERT INTO public.word_semantic VALUES (4311, 557, 50);
INSERT INTO public.word_semantic VALUES (4312, 557, 8);
INSERT INTO public.word_semantic VALUES (4313, 557, 5);
INSERT INTO public.word_semantic VALUES (4314, 557, 9);
INSERT INTO public.word_semantic VALUES (4315, 557, 15);
INSERT INTO public.word_semantic VALUES (4321, 558, 50);
INSERT INTO public.word_semantic VALUES (4322, 558, 8);
INSERT INTO public.word_semantic VALUES (4323, 558, 5);
INSERT INTO public.word_semantic VALUES (4324, 558, 9);
INSERT INTO public.word_semantic VALUES (4325, 558, 15);
INSERT INTO public.word_semantic VALUES (4331, 559, 50);
INSERT INTO public.word_semantic VALUES (4332, 559, 8);
INSERT INTO public.word_semantic VALUES (4333, 559, 5);
INSERT INTO public.word_semantic VALUES (4334, 559, 9);
INSERT INTO public.word_semantic VALUES (4335, 559, 15);
INSERT INTO public.word_semantic VALUES (4341, 560, 50);
INSERT INTO public.word_semantic VALUES (4342, 560, 8);
INSERT INTO public.word_semantic VALUES (4343, 560, 5);
INSERT INTO public.word_semantic VALUES (4344, 560, 9);
INSERT INTO public.word_semantic VALUES (4345, 560, 15);
INSERT INTO public.word_semantic VALUES (4351, 561, 50);
INSERT INTO public.word_semantic VALUES (4352, 561, 8);
INSERT INTO public.word_semantic VALUES (4353, 561, 5);
INSERT INTO public.word_semantic VALUES (4354, 561, 9);
INSERT INTO public.word_semantic VALUES (4355, 561, 15);
INSERT INTO public.word_semantic VALUES (4361, 562, 50);
INSERT INTO public.word_semantic VALUES (4362, 562, 8);
INSERT INTO public.word_semantic VALUES (4363, 562, 5);
INSERT INTO public.word_semantic VALUES (4364, 562, 9);
INSERT INTO public.word_semantic VALUES (4365, 562, 15);
INSERT INTO public.word_semantic VALUES (4371, 563, 50);
INSERT INTO public.word_semantic VALUES (4372, 563, 8);
INSERT INTO public.word_semantic VALUES (4373, 563, 5);
INSERT INTO public.word_semantic VALUES (4374, 563, 9);
INSERT INTO public.word_semantic VALUES (4375, 563, 15);
INSERT INTO public.word_semantic VALUES (4381, 564, 50);
INSERT INTO public.word_semantic VALUES (4382, 564, 8);
INSERT INTO public.word_semantic VALUES (4383, 564, 5);
INSERT INTO public.word_semantic VALUES (4384, 564, 9);
INSERT INTO public.word_semantic VALUES (4385, 564, 15);
INSERT INTO public.word_semantic VALUES (4391, 565, 50);
INSERT INTO public.word_semantic VALUES (4392, 565, 8);
INSERT INTO public.word_semantic VALUES (4393, 565, 5);
INSERT INTO public.word_semantic VALUES (4394, 565, 9);
INSERT INTO public.word_semantic VALUES (4395, 565, 15);
INSERT INTO public.word_semantic VALUES (4401, 566, 50);
INSERT INTO public.word_semantic VALUES (4402, 566, 8);
INSERT INTO public.word_semantic VALUES (4403, 566, 5);
INSERT INTO public.word_semantic VALUES (4404, 566, 9);
INSERT INTO public.word_semantic VALUES (4405, 566, 15);
INSERT INTO public.word_semantic VALUES (4411, 567, 50);
INSERT INTO public.word_semantic VALUES (4412, 567, 8);
INSERT INTO public.word_semantic VALUES (4413, 567, 5);
INSERT INTO public.word_semantic VALUES (4414, 567, 9);
INSERT INTO public.word_semantic VALUES (4415, 567, 15);
INSERT INTO public.word_semantic VALUES (4421, 568, 50);
INSERT INTO public.word_semantic VALUES (4422, 568, 8);
INSERT INTO public.word_semantic VALUES (4423, 568, 5);
INSERT INTO public.word_semantic VALUES (4424, 568, 9);
INSERT INTO public.word_semantic VALUES (4425, 568, 15);
INSERT INTO public.word_semantic VALUES (4431, 569, 50);
INSERT INTO public.word_semantic VALUES (4432, 569, 8);
INSERT INTO public.word_semantic VALUES (4433, 569, 5);
INSERT INTO public.word_semantic VALUES (4434, 569, 9);
INSERT INTO public.word_semantic VALUES (4435, 569, 15);
INSERT INTO public.word_semantic VALUES (4441, 570, 50);
INSERT INTO public.word_semantic VALUES (4442, 570, 8);
INSERT INTO public.word_semantic VALUES (4443, 570, 5);
INSERT INTO public.word_semantic VALUES (4444, 570, 9);
INSERT INTO public.word_semantic VALUES (4445, 570, 15);
INSERT INTO public.word_semantic VALUES (4451, 571, 50);
INSERT INTO public.word_semantic VALUES (4452, 571, 8);
INSERT INTO public.word_semantic VALUES (4453, 571, 5);
INSERT INTO public.word_semantic VALUES (4454, 571, 9);
INSERT INTO public.word_semantic VALUES (4455, 571, 15);
INSERT INTO public.word_semantic VALUES (4461, 572, 50);
INSERT INTO public.word_semantic VALUES (4462, 572, 8);
INSERT INTO public.word_semantic VALUES (4463, 572, 5);
INSERT INTO public.word_semantic VALUES (4464, 572, 9);
INSERT INTO public.word_semantic VALUES (4465, 572, 15);
INSERT INTO public.word_semantic VALUES (4471, 573, 50);
INSERT INTO public.word_semantic VALUES (4472, 573, 8);
INSERT INTO public.word_semantic VALUES (4473, 573, 5);
INSERT INTO public.word_semantic VALUES (4474, 573, 9);
INSERT INTO public.word_semantic VALUES (4475, 573, 15);
INSERT INTO public.word_semantic VALUES (4477, 574, 51);
INSERT INTO public.word_semantic VALUES (4478, 574, 52);
INSERT INTO public.word_semantic VALUES (4480, 575, 51);
INSERT INTO public.word_semantic VALUES (4481, 575, 52);
INSERT INTO public.word_semantic VALUES (4483, 576, 53);
INSERT INTO public.word_semantic VALUES (4484, 576, 52);
INSERT INTO public.word_semantic VALUES (4486, 577, 53);
INSERT INTO public.word_semantic VALUES (4487, 577, 52);
INSERT INTO public.word_semantic VALUES (4489, 578, 53);
INSERT INTO public.word_semantic VALUES (4490, 578, 52);
INSERT INTO public.word_semantic VALUES (4492, 579, 53);
INSERT INTO public.word_semantic VALUES (4493, 579, 52);
INSERT INTO public.word_semantic VALUES (4495, 580, 53);
INSERT INTO public.word_semantic VALUES (4496, 580, 52);
INSERT INTO public.word_semantic VALUES (4498, 581, 53);
INSERT INTO public.word_semantic VALUES (4499, 581, 52);
INSERT INTO public.word_semantic VALUES (4501, 582, 53);
INSERT INTO public.word_semantic VALUES (4502, 582, 52);
INSERT INTO public.word_semantic VALUES (4508, 583, 54);
INSERT INTO public.word_semantic VALUES (4509, 583, 55);
INSERT INTO public.word_semantic VALUES (4510, 583, 56);
INSERT INTO public.word_semantic VALUES (4511, 583, 57);
INSERT INTO public.word_semantic VALUES (4512, 583, 58);
INSERT INTO public.word_semantic VALUES (4513, 583, 52);
INSERT INTO public.word_semantic VALUES (4516, 584, 54);
INSERT INTO public.word_semantic VALUES (4517, 584, 55);
INSERT INTO public.word_semantic VALUES (4518, 584, 52);
INSERT INTO public.word_semantic VALUES (4521, 585, 54);
INSERT INTO public.word_semantic VALUES (4522, 585, 55);
INSERT INTO public.word_semantic VALUES (4523, 585, 52);
INSERT INTO public.word_semantic VALUES (4526, 586, 54);
INSERT INTO public.word_semantic VALUES (4527, 586, 55);
INSERT INTO public.word_semantic VALUES (4528, 586, 52);
INSERT INTO public.word_semantic VALUES (4531, 587, 54);
INSERT INTO public.word_semantic VALUES (4532, 587, 55);
INSERT INTO public.word_semantic VALUES (4533, 587, 52);
INSERT INTO public.word_semantic VALUES (4536, 588, 54);
INSERT INTO public.word_semantic VALUES (4537, 588, 55);
INSERT INTO public.word_semantic VALUES (4538, 588, 52);
INSERT INTO public.word_semantic VALUES (4541, 589, 54);
INSERT INTO public.word_semantic VALUES (4542, 589, 55);
INSERT INTO public.word_semantic VALUES (4543, 589, 52);
INSERT INTO public.word_semantic VALUES (4546, 590, 54);
INSERT INTO public.word_semantic VALUES (4547, 590, 55);
INSERT INTO public.word_semantic VALUES (4548, 590, 52);
INSERT INTO public.word_semantic VALUES (4551, 591, 54);
INSERT INTO public.word_semantic VALUES (4552, 591, 56);
INSERT INTO public.word_semantic VALUES (4553, 591, 52);
INSERT INTO public.word_semantic VALUES (4556, 592, 54);
INSERT INTO public.word_semantic VALUES (4557, 592, 56);
INSERT INTO public.word_semantic VALUES (4558, 592, 52);
INSERT INTO public.word_semantic VALUES (4561, 593, 54);
INSERT INTO public.word_semantic VALUES (4562, 593, 56);
INSERT INTO public.word_semantic VALUES (4563, 593, 52);
INSERT INTO public.word_semantic VALUES (4566, 594, 54);
INSERT INTO public.word_semantic VALUES (4567, 594, 56);
INSERT INTO public.word_semantic VALUES (4568, 594, 52);
INSERT INTO public.word_semantic VALUES (4570, 595, 59);
INSERT INTO public.word_semantic VALUES (4571, 595, 52);
INSERT INTO public.word_semantic VALUES (4573, 596, 59);
INSERT INTO public.word_semantic VALUES (4574, 596, 52);
INSERT INTO public.word_semantic VALUES (4576, 597, 59);
INSERT INTO public.word_semantic VALUES (4577, 597, 52);
INSERT INTO public.word_semantic VALUES (4579, 598, 59);
INSERT INTO public.word_semantic VALUES (4580, 598, 52);
INSERT INTO public.word_semantic VALUES (4582, 599, 59);
INSERT INTO public.word_semantic VALUES (4583, 599, 52);
INSERT INTO public.word_semantic VALUES (4585, 600, 59);
INSERT INTO public.word_semantic VALUES (4586, 600, 52);
INSERT INTO public.word_semantic VALUES (4588, 601, 59);
INSERT INTO public.word_semantic VALUES (4589, 601, 52);
INSERT INTO public.word_semantic VALUES (4591, 602, 59);
INSERT INTO public.word_semantic VALUES (4592, 602, 52);
INSERT INTO public.word_semantic VALUES (4594, 603, 60);
INSERT INTO public.word_semantic VALUES (4595, 603, 52);
INSERT INTO public.word_semantic VALUES (4597, 604, 60);
INSERT INTO public.word_semantic VALUES (4598, 604, 52);
INSERT INTO public.word_semantic VALUES (4600, 605, 60);
INSERT INTO public.word_semantic VALUES (4601, 605, 52);
INSERT INTO public.word_semantic VALUES (4603, 606, 60);
INSERT INTO public.word_semantic VALUES (4604, 606, 52);
INSERT INTO public.word_semantic VALUES (4606, 607, 60);
INSERT INTO public.word_semantic VALUES (4607, 607, 52);
INSERT INTO public.word_semantic VALUES (4609, 608, 60);
INSERT INTO public.word_semantic VALUES (4610, 608, 52);
INSERT INTO public.word_semantic VALUES (4612, 609, 60);
INSERT INTO public.word_semantic VALUES (4613, 609, 52);
INSERT INTO public.word_semantic VALUES (4615, 610, 60);
INSERT INTO public.word_semantic VALUES (4616, 610, 52);
INSERT INTO public.word_semantic VALUES (4618, 611, 61);
INSERT INTO public.word_semantic VALUES (4619, 611, 52);
INSERT INTO public.word_semantic VALUES (4621, 612, 61);
INSERT INTO public.word_semantic VALUES (4622, 612, 52);
INSERT INTO public.word_semantic VALUES (4624, 613, 61);
INSERT INTO public.word_semantic VALUES (4625, 613, 52);
INSERT INTO public.word_semantic VALUES (4627, 614, 61);
INSERT INTO public.word_semantic VALUES (4628, 614, 52);
INSERT INTO public.word_semantic VALUES (4630, 615, 61);
INSERT INTO public.word_semantic VALUES (4631, 615, 52);
INSERT INTO public.word_semantic VALUES (4633, 616, 61);
INSERT INTO public.word_semantic VALUES (4634, 616, 52);
INSERT INTO public.word_semantic VALUES (4636, 617, 61);
INSERT INTO public.word_semantic VALUES (4637, 617, 52);
INSERT INTO public.word_semantic VALUES (4639, 618, 61);
INSERT INTO public.word_semantic VALUES (4640, 618, 52);
INSERT INTO public.word_semantic VALUES (4642, 619, 62);
INSERT INTO public.word_semantic VALUES (4643, 619, 52);
INSERT INTO public.word_semantic VALUES (4645, 620, 62);
INSERT INTO public.word_semantic VALUES (4646, 620, 52);
INSERT INTO public.word_semantic VALUES (4648, 621, 62);
INSERT INTO public.word_semantic VALUES (4649, 621, 52);
INSERT INTO public.word_semantic VALUES (4651, 622, 62);
INSERT INTO public.word_semantic VALUES (4652, 622, 52);
INSERT INTO public.word_semantic VALUES (4654, 623, 62);
INSERT INTO public.word_semantic VALUES (4655, 623, 52);
INSERT INTO public.word_semantic VALUES (4657, 624, 62);
INSERT INTO public.word_semantic VALUES (4658, 624, 52);
INSERT INTO public.word_semantic VALUES (4660, 625, 62);
INSERT INTO public.word_semantic VALUES (4661, 625, 52);
INSERT INTO public.word_semantic VALUES (4663, 626, 62);
INSERT INTO public.word_semantic VALUES (4664, 626, 52);
INSERT INTO public.word_semantic VALUES (4666, 627, 63);
INSERT INTO public.word_semantic VALUES (4667, 627, 52);
INSERT INTO public.word_semantic VALUES (4669, 628, 63);
INSERT INTO public.word_semantic VALUES (4670, 628, 52);
INSERT INTO public.word_semantic VALUES (4672, 629, 63);
INSERT INTO public.word_semantic VALUES (4673, 629, 52);
INSERT INTO public.word_semantic VALUES (4675, 630, 63);
INSERT INTO public.word_semantic VALUES (4676, 630, 52);
INSERT INTO public.word_semantic VALUES (4678, 631, 63);
INSERT INTO public.word_semantic VALUES (4679, 631, 52);
INSERT INTO public.word_semantic VALUES (4681, 632, 63);
INSERT INTO public.word_semantic VALUES (4682, 632, 52);
INSERT INTO public.word_semantic VALUES (4684, 633, 63);
INSERT INTO public.word_semantic VALUES (4685, 633, 52);
INSERT INTO public.word_semantic VALUES (4687, 634, 63);
INSERT INTO public.word_semantic VALUES (4688, 634, 52);
INSERT INTO public.word_semantic VALUES (4690, 635, 64);
INSERT INTO public.word_semantic VALUES (4691, 635, 52);
INSERT INTO public.word_semantic VALUES (4693, 636, 64);
INSERT INTO public.word_semantic VALUES (4694, 636, 52);
INSERT INTO public.word_semantic VALUES (4696, 637, 64);
INSERT INTO public.word_semantic VALUES (4697, 637, 52);
INSERT INTO public.word_semantic VALUES (4699, 638, 64);
INSERT INTO public.word_semantic VALUES (4700, 638, 52);
INSERT INTO public.word_semantic VALUES (4702, 639, 64);
INSERT INTO public.word_semantic VALUES (4703, 639, 52);
INSERT INTO public.word_semantic VALUES (4705, 640, 64);
INSERT INTO public.word_semantic VALUES (4706, 640, 52);
INSERT INTO public.word_semantic VALUES (4708, 641, 64);
INSERT INTO public.word_semantic VALUES (4709, 641, 52);
INSERT INTO public.word_semantic VALUES (4711, 642, 64);
INSERT INTO public.word_semantic VALUES (4712, 642, 52);
INSERT INTO public.word_semantic VALUES (4714, 643, 65);
INSERT INTO public.word_semantic VALUES (4715, 643, 52);
INSERT INTO public.word_semantic VALUES (4717, 644, 65);
INSERT INTO public.word_semantic VALUES (4718, 644, 52);
INSERT INTO public.word_semantic VALUES (4720, 645, 65);
INSERT INTO public.word_semantic VALUES (4721, 645, 52);
INSERT INTO public.word_semantic VALUES (4723, 646, 65);
INSERT INTO public.word_semantic VALUES (4724, 646, 52);
INSERT INTO public.word_semantic VALUES (4726, 647, 65);
INSERT INTO public.word_semantic VALUES (4727, 647, 52);
INSERT INTO public.word_semantic VALUES (4729, 648, 65);
INSERT INTO public.word_semantic VALUES (4730, 648, 52);
INSERT INTO public.word_semantic VALUES (4732, 649, 65);
INSERT INTO public.word_semantic VALUES (4733, 649, 52);
INSERT INTO public.word_semantic VALUES (4735, 650, 65);
INSERT INTO public.word_semantic VALUES (4736, 650, 52);
INSERT INTO public.word_semantic VALUES (4738, 651, 66);
INSERT INTO public.word_semantic VALUES (4739, 651, 52);
INSERT INTO public.word_semantic VALUES (4741, 652, 66);
INSERT INTO public.word_semantic VALUES (4742, 652, 52);
INSERT INTO public.word_semantic VALUES (4744, 653, 66);
INSERT INTO public.word_semantic VALUES (4745, 653, 52);
INSERT INTO public.word_semantic VALUES (4747, 654, 66);
INSERT INTO public.word_semantic VALUES (4748, 654, 52);
INSERT INTO public.word_semantic VALUES (4750, 655, 66);
INSERT INTO public.word_semantic VALUES (4751, 655, 52);
INSERT INTO public.word_semantic VALUES (4753, 656, 66);
INSERT INTO public.word_semantic VALUES (4754, 656, 52);
INSERT INTO public.word_semantic VALUES (4756, 657, 66);
INSERT INTO public.word_semantic VALUES (4757, 657, 52);


--
-- TOC entry 3467 (class 0 OID 0)
-- Dependencies: 227
-- Name: generated_phrase_speech_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.generated_phrase_speech_id_seq', 302, true);


--
-- TOC entry 3468 (class 0 OID 0)
-- Dependencies: 216
-- Name: grammar_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grammar_tag_id_seq', 14, true);


--
-- TOC entry 3469 (class 0 OID 0)
-- Dependencies: 210
-- Name: non_terminal_symbol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.non_terminal_symbol_id_seq', 2, true);


--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 212
-- Name: production_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_id_seq', 5, true);


--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 218
-- Name: semantic_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.semantic_tag_id_seq', 69, true);


--
-- TOC entry 3472 (class 0 OID 0)
-- Dependencies: 222
-- Name: word_grammar_compatibility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.word_grammar_compatibility_id_seq', 2209, true);


--
-- TOC entry 3473 (class 0 OID 0)
-- Dependencies: 224
-- Name: word_grammar_requirements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.word_grammar_requirements_id_seq', 686, true);


--
-- TOC entry 3474 (class 0 OID 0)
-- Dependencies: 214
-- Name: word_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.word_id_seq', 683, true);


--
-- TOC entry 3475 (class 0 OID 0)
-- Dependencies: 220
-- Name: word_semantic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.word_semantic_id_seq', 4835, true);


--
-- TOC entry 3238 (class 2606 OID 16391)
-- Name: _sqlx_migrations _sqlx_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._sqlx_migrations
    ADD CONSTRAINT _sqlx_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3276 (class 2606 OID 16517)
-- Name: generated_phrase generated_phrase_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_phrase
    ADD CONSTRAINT generated_phrase_pkey PRIMARY KEY (id);


--
-- TOC entry 3280 (class 2606 OID 16537)
-- Name: generated_phrase_speech generated_phrase_speech_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_phrase_speech
    ADD CONSTRAINT generated_phrase_speech_pkey PRIMARY KEY (id);


--
-- TOC entry 3253 (class 2606 OID 16437)
-- Name: grammar_tag grammar_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grammar_tag
    ADD CONSTRAINT grammar_tag_name_key UNIQUE (name);


--
-- TOC entry 3255 (class 2606 OID 16435)
-- Name: grammar_tag grammar_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grammar_tag
    ADD CONSTRAINT grammar_tag_pkey PRIMARY KEY (id);


--
-- TOC entry 3240 (class 2606 OID 16400)
-- Name: non_terminal_symbol non_terminal_symbol_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.non_terminal_symbol
    ADD CONSTRAINT non_terminal_symbol_name_key UNIQUE (name);


--
-- TOC entry 3242 (class 2606 OID 16398)
-- Name: non_terminal_symbol non_terminal_symbol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.non_terminal_symbol
    ADD CONSTRAINT non_terminal_symbol_pkey PRIMARY KEY (id);


--
-- TOC entry 3246 (class 2606 OID 16410)
-- Name: production production_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production
    ADD CONSTRAINT production_pkey PRIMARY KEY (id);


--
-- TOC entry 3257 (class 2606 OID 16447)
-- Name: semantic_tag semantic_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semantic_tag
    ADD CONSTRAINT semantic_tag_name_key UNIQUE (name);


--
-- TOC entry 3259 (class 2606 OID 16445)
-- Name: semantic_tag semantic_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.semantic_tag
    ADD CONSTRAINT semantic_tag_pkey PRIMARY KEY (id);


--
-- TOC entry 3249 (class 2606 OID 16427)
-- Name: word word_content_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word
    ADD CONSTRAINT word_content_key UNIQUE (content);


--
-- TOC entry 3269 (class 2606 OID 16474)
-- Name: word_grammar_compatibility word_grammar_compatibility_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_compatibility
    ADD CONSTRAINT word_grammar_compatibility_pkey PRIMARY KEY (id);


--
-- TOC entry 3274 (class 2606 OID 16494)
-- Name: word_grammar_requirements word_grammar_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_requirements
    ADD CONSTRAINT word_grammar_requirements_pkey PRIMARY KEY (id);


--
-- TOC entry 3251 (class 2606 OID 16425)
-- Name: word word_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word
    ADD CONSTRAINT word_pkey PRIMARY KEY (id);


--
-- TOC entry 3264 (class 2606 OID 16454)
-- Name: word_semantic word_semantic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_semantic
    ADD CONSTRAINT word_semantic_pkey PRIMARY KEY (id);


--
-- TOC entry 3277 (class 1259 OID 16519)
-- Name: idx_generated_phrase_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_generated_phrase_lookup ON public.generated_phrase USING btree (content);


--
-- TOC entry 3281 (class 1259 OID 16544)
-- Name: idx_generated_phrase_speech_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_generated_phrase_speech_lookup ON public.generated_phrase_speech USING btree (generated_phrase, lang, gender);


--
-- TOC entry 3282 (class 1259 OID 16543)
-- Name: idx_generated_phrase_speech_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_generated_phrase_speech_uniqueness ON public.generated_phrase_speech USING btree (generated_phrase, lang, gender);


--
-- TOC entry 3278 (class 1259 OID 16518)
-- Name: idx_generated_phrase_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_generated_phrase_uniqueness ON public.generated_phrase USING btree (content);


--
-- TOC entry 3243 (class 1259 OID 16416)
-- Name: idx_production_non_terminal_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_production_non_terminal_symbol ON public.production USING btree (non_terminal_symbol);


--
-- TOC entry 3244 (class 1259 OID 16417)
-- Name: idx_production_nts_amount; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_production_nts_amount ON public.production USING btree (nts_amount);


--
-- TOC entry 3247 (class 1259 OID 16428)
-- Name: idx_word_content; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_word_content ON public.word USING btree (content varchar_pattern_ops);


--
-- TOC entry 3265 (class 1259 OID 16486)
-- Name: idx_word_grammar_compatibility_grammar_tag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_word_grammar_compatibility_grammar_tag ON public.word_grammar_compatibility USING btree (grammar_tag);


--
-- TOC entry 3266 (class 1259 OID 16487)
-- Name: idx_word_grammar_compatibility_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_word_grammar_compatibility_uniqueness ON public.word_grammar_compatibility USING btree (word, grammar_tag);


--
-- TOC entry 3267 (class 1259 OID 16485)
-- Name: idx_word_grammar_compatibility_word; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_word_grammar_compatibility_word ON public.word_grammar_compatibility USING btree (word);


--
-- TOC entry 3270 (class 1259 OID 16506)
-- Name: idx_word_grammar_requirements_grammar_tag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_word_grammar_requirements_grammar_tag ON public.word_grammar_requirements USING btree (grammar_tag);


--
-- TOC entry 3271 (class 1259 OID 16507)
-- Name: idx_word_grammar_requirements_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_word_grammar_requirements_uniqueness ON public.word_grammar_requirements USING btree (word, grammar_tag);


--
-- TOC entry 3272 (class 1259 OID 16505)
-- Name: idx_word_grammar_requirements_word; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_word_grammar_requirements_word ON public.word_grammar_requirements USING btree (word);


--
-- TOC entry 3260 (class 1259 OID 16466)
-- Name: idx_word_semantic_semantic_tag; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_word_semantic_semantic_tag ON public.word_semantic USING btree (semantic_tag);


--
-- TOC entry 3261 (class 1259 OID 16467)
-- Name: idx_word_semantic_uniqueness; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_word_semantic_uniqueness ON public.word_semantic USING btree (word, semantic_tag);


--
-- TOC entry 3262 (class 1259 OID 16465)
-- Name: idx_word_semantic_word; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_word_semantic_word ON public.word_semantic USING btree (word);


--
-- TOC entry 3290 (class 2606 OID 16538)
-- Name: generated_phrase_speech generated_phrase_speech_generated_phrase_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generated_phrase_speech
    ADD CONSTRAINT generated_phrase_speech_generated_phrase_fkey FOREIGN KEY (generated_phrase) REFERENCES public.generated_phrase(id);


--
-- TOC entry 3283 (class 2606 OID 16411)
-- Name: production production_non_terminal_symbol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production
    ADD CONSTRAINT production_non_terminal_symbol_fkey FOREIGN KEY (non_terminal_symbol) REFERENCES public.non_terminal_symbol(id);


--
-- TOC entry 3287 (class 2606 OID 16480)
-- Name: word_grammar_compatibility word_grammar_compatibility_grammar_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_compatibility
    ADD CONSTRAINT word_grammar_compatibility_grammar_tag_fkey FOREIGN KEY (grammar_tag) REFERENCES public.grammar_tag(id);


--
-- TOC entry 3286 (class 2606 OID 16475)
-- Name: word_grammar_compatibility word_grammar_compatibility_word_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_compatibility
    ADD CONSTRAINT word_grammar_compatibility_word_fkey FOREIGN KEY (word) REFERENCES public.word(id);


--
-- TOC entry 3289 (class 2606 OID 16500)
-- Name: word_grammar_requirements word_grammar_requirements_grammar_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_requirements
    ADD CONSTRAINT word_grammar_requirements_grammar_tag_fkey FOREIGN KEY (grammar_tag) REFERENCES public.grammar_tag(id);


--
-- TOC entry 3288 (class 2606 OID 16495)
-- Name: word_grammar_requirements word_grammar_requirements_word_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_grammar_requirements
    ADD CONSTRAINT word_grammar_requirements_word_fkey FOREIGN KEY (word) REFERENCES public.word(id);


--
-- TOC entry 3285 (class 2606 OID 16460)
-- Name: word_semantic word_semantic_semantic_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_semantic
    ADD CONSTRAINT word_semantic_semantic_tag_fkey FOREIGN KEY (semantic_tag) REFERENCES public.semantic_tag(id);


--
-- TOC entry 3284 (class 2606 OID 16455)
-- Name: word_semantic word_semantic_word_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.word_semantic
    ADD CONSTRAINT word_semantic_word_fkey FOREIGN KEY (word) REFERENCES public.word(id);


-- Completed on 2022-03-16 21:52:38 CET

--
-- PostgreSQL database dump complete
--

